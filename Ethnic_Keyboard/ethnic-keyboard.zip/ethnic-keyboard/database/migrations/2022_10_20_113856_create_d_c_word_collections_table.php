<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDCWordCollectionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('d_c_word_collections', function (Blueprint $table) {
            $table->id();
            $table->string('audio');
            $table->string('audio_duration')->nullable();
            $table->longText('audio_blob')->nullable();
            $table->text('bangla')->nullable();
            $table->text('english')->nullable();
            $table->text('transcription')->nullable();
            $table->text('comment')->nullable();
            $table->bigInteger('validator_id')->unsigned()->nullable();
            $table->foreign('validator_id')->references('id')->on('speakers')->onDelete('cascade');
            $table->tinyInteger('status')->nullable()->comment('0=Pending, 1=Approved, 2=Correction');
            $table->tinyInteger('validation_status')->nullable()->comment('0=Not Agree,1=Agree');
            $table->tinyInteger('topic_status')->nullable()->comment('1=partial_collection,2=voice_collection,3=validated,4=approved,5=not_validate,6=reject');
            $table->foreignId('d_c_word_id')->constrained('d_c_words');
            $table->foreignId('word_id')->constrained('words');
            $table->dateTime('approved_date')->nullable();
            $table->integer('approved_by')->nullable();
            $table->integer('created_by');
            $table->integer('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('d_c_word_collections');
    }
}

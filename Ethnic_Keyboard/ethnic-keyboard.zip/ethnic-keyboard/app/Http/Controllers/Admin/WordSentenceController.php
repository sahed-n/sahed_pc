<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DataCollection;
use App\Models\DCWord;
use App\Models\DCWordCollection;
use App\Models\Word;
use App\Models\Topic_word;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use File;

class WordSentenceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($topicID){
        $topic_word='';
        $wordSentences = Word::with('topicsWord')
            ->where('topic_word_id', $topicID)
            ->orderBy('id', 'asc')
            ->get();

        if ($wordSentences->isEmpty()){
            $topic_word=Topic_word::where('id', $topicID)->first();
        }
        $firstItem = Arr::first($wordSentences, function ($value, $key) {
            return $value;
        });

        return view('admin.word_sentence.index', compact('wordSentences', 'firstItem', 'topic_word'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($topicID)
    {
        $topic_word = Topic_word::where('id', $topicID)->first();

        return view('admin.word_sentence.create', compact('topic_word'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            "sentence.*"  => "required|string",
            // "english.*"  => "required|string",
        ]);

        if ($validator->passes()){
            foreach ($request->get('sentence') as $key=> $sentenceItem){
                $sentence = new Word();
                $sentence->topic_word_id= $request->topic_word_id;
                $sentence->sentence= $sentenceItem;
                $sentence->english= $request['english'][$key];
                $sentence->created_by = auth()->id();
                $sentence->updated_by = 0;
                $sentence->save();
            }

            return redirect()->route('admin.word_sentence.index', $request->topic_word_id)
                ->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে তৈরি করা হয়েছে৷'));

        }else{
            return redirect()->back()->withErrors($validator);// ['error'=>$validator->errors()->all()];
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {


    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $wordSentence = Word::with('topicsWord')->findOrFail($id);

        return  view('admin.word_sentence.edit', compact('wordSentence'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            "sentence"  => "required|string",
            // "english"  => "required|string",
        ]);

        $wordSentence = Word::findorFail($id);
        $wordSentence->topic_word_id= $request->topic_word_id;
        $wordSentence->sentence= $request->sentence;
        $wordSentence->english= $request->english;
        $wordSentence->update();
        return redirect()->route('admin.word_sentence.index', $request->topic_word_id)
            ->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে আপডেট করা হয়েছে।'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $dcWordSentence =DCWordCollection::where('word_id', $id)->get();
        if (!$dcWordSentence->isEmpty()){
            foreach ($dcWordSentence as $dcWordSentenceItem){
                $dcWord = DCWord::where('id', $dcWordSentenceItem->d_c_word_id)->first();
                if (!empty($dcWord)){
                    $dataCollection = DataCollection::where('id', $dcWord->data_collection_id)->first();
                    $audioPath = public_path($dcWordSentenceItem->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $dcWordSentenceItem->delete();
                    $dcWord->delete();
                    $dataCollection->delete();
                }
            }
        }
        $word =Word::findOrFail($id);
        $word->delete();

        return redirect()->back()->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে মুছে ফেলা হয়েছে।'));
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreSentenceRequest;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DCWordCollection;
use App\Models\Directed;
use App\Models\Topic;
use App\Models\Topic_word;
use App\Models\Word;
use App\Models\DCWord;
use App\Models\DirectedLanguage;
use App\Models\DirectedTaskAssign;
use App\Models\District;
use App\Models\Group;
use App\Models\GroupCollectors;
use App\Models\Speaker;
use App\Models\Spontaneous;
use App\Models\SpontaneousLanguage;
use App\Models\SpontaneousTaskAssign;
use App\Models\TaskAssign;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\Village;
use App\Models\Language;
use FFMpeg\Format\Video\X264;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Lame\Lame;
use Lame\Settings\Encoding\Preset;
use Lame\Settings\Settings;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use phpDocumentor\Reflection\Types\Null_;
use File;
use function PHPUnit\Framework\isEmpty;
use Illuminate\Support\Facades;
use Illuminate\Support\Facades\Validator;
use App\Models\Notification;


class DataCollectionController extends Controller
{

    public function showDataCollectionWithTrim($type, $id, Request $request)
    {
        if ($type == 'directed') {
            $audio = DCDirectedSentence::with(['dcDirected' => function ($q) {
                $q->with(['collection.language', 'collection.district', 'collection.collector', 'collection.speaker', 'collection.taskAssign' => function ($e) {
                    $e->with('group');
                }, 'topic']);
            }, 'directed'])
                ->findOrFail($id);
        }
        if ($type == 'spontaneous') {
            $audio = DCSpontaneous::with(['collection' => function ($e) {
                $e->with([
                    'collector', 'speaker',
                    'taskAssign' => function ($q) {
                        $q->with('group');
                    }
                ]);
            }, 'spontaneous'])
                ->findOrFail($id);
        }
        if($type == 'word'){
            $audio = DCWordCollection::with(['dcWord' => function ($q) {
                $q->with(['collection.language', 'collection.district', 'collection.collector', 'collection.speaker', 'collection.taskAssign' => function ($e) {
                    $e->with('group');
                }, 'topicWord']);
            }, 'word'])
                ->findOrFail($id);
        }

        $trims = [];
        /* $directedAudios = AudioTrim::where('d_c_directed_sentences_id',  $request->id)
             ->latest()->get();
         if ($directedAudios->isNotEmpty()) {
             foreach ($directedAudios as $directedAudio) {
                 array_push($trims, $directedAudio);
             }
         }*/
        $spontinoursAudios = AudioTrim::where('d_c_spontaneouses_id', $request->id)->get();
        $spontinoursAudios= $spontinoursAudios->sortBy('start_time');
        if ($spontinoursAudios->isNotEmpty()) {
            foreach ($spontinoursAudios as $spontinoursAudio) {
                array_push($trims, $spontinoursAudio);
            }
        }

        $trims = array_filter($trims);

        return view('admin.data_collection.show', compact('type', 'audio', 'trims'));
    }


    public function pendingCollectionList(Request $request)
    {
        /*$dataCollections = DataCollection::query();*/

       /* if ($request->search != null) {
            $dataCollections = $dataCollections
                ->where('name', 'like', '%' . $request->search . '%')
            ->orWhere('phone', 'like', '%' . $request->search . '%')
            ->orWhere('address', 'like', '%' . $request->search . '%')
            ->orWhere('age', 'like', '%' . $request->search . '%');

        }*/

        $directeds = DCDirectedSentence::where('status', 0)
            ->with(['dcDirected' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();
        $spontaneouses = AudioTrim::where('status', 1)->with(['dcSpontaneous' => function ($d) {
            $d->select('id', 'spontaneous_id', 'audio','status','data_collection_id', 'validation_status', 'english',
                'transcription', 'bangla', 'approved_by', 'approved_date');
            $d->with('collection.speaker', 'collection.language', 'collection.district', 'spontaneous');
        }])->latest()->get();
        $word = DCWordCollection::where('status', 0)
            ->with(['dcWord' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topicWord');
            }, 'word'])->latest()->get();


        $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        $dataCollections = $word->mergeRecursive($dataCollections)->all();

        $currentPage = LengthAwarePaginator::resolveCurrentPage();
        $itemCollection = collect($dataCollections);
        $perPage = 10;
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
        $dataCollections= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);
        $dataCollections->setPath($request->url());

        return view('admin.data_collection.pendingList', compact('dataCollections'));
    }


    public function audioList()
    {
        $directeds = DCDirectedSentence::where('approved_by', null)->with(['dcDirected' => function ($d) {
            $d->with('collection.language', 'collection.district', 'topic');
        }, 'directed'])->latest()->get();
        $spontaneouses = DCSpontaneous::where('approved_by', null)->with('collection.language', 'collection.district', 'spontaneous')->latest()->get();
        $dataCollections = $spontaneouses->mergeRecursive($directeds)->all();

        return response()->json($dataCollections);
    }

    public function userPending()
    {

        $directeds = DCDirectedSentence::select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
            'validation_status', 'english', 'comment', 'transcription', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 0)->where('created_by', auth()->id())
            ->with(['dcDirected' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();
        $spontaneouses = AudioTrim::where('status', 1)->with(['dcSpontaneous' => function ($d) {
            $d->select('id', 'spontaneous_id', 'audio','status','data_collection_id', 'validation_status', 'english',
                'transcription', 'bangla', 'approved_by', 'approved_date');
            $d->with('collection.speaker', 'collection.language', 'collection.district', 'spontaneous');
        }])->whereHas('dcSpontaneous', function ($q) {
            $q->where('created_by', auth()->id());
        })->latest()->get();

        $word = DCWordCollection::select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
            'validation_status', 'english', 'transcription', 'comment', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 0)->where('created_by', auth()->id())
            ->with(['dcWord' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topicWord');
            }, 'word'])->latest()->get();

        $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        $dataCollections = $word->mergeRecursive($dataCollections)->all();

        return view('admin.data_collection.userPendingList', compact('dataCollections'));
    }
    public function userApproval()
    {
        $directeds = DCDirectedSentence::select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
            'validation_status', 'english', 'comment', 'transcription', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 1)->where('created_by', auth()->id())
            ->with(['dcDirected' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();
        $spontaneouses = AudioTrim::where('status', 3)->with(['dcSpontaneous' => function ($d) {
            $d->select('id', 'spontaneous_id', 'audio','status','data_collection_id', 'validation_status', 'english',
                'transcription', 'bangla', 'approved_by', 'approved_date');
            $d->with('collection.speaker', 'collection.language', 'collection.district', 'spontaneous');
        }])->whereHas('dcSpontaneous', function ($q) {
            $q->where('created_by', auth()->id());
        })->latest()->get();

        $word = DCWordCollection::select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
            'validation_status', 'english', 'transcription', 'comment', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 1)->where('created_by', auth()->id())
            ->with(['dcWord' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topicWord');
            }, 'word'])->latest()->get();

        $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        $dataCollections = $word->mergeRecursive($dataCollections)->all();

        return view('admin.data_collection.userApprovalList', compact('dataCollections'));
    }

    public function approvedCollectionList(){
        $directeds = DCDirectedSentence::select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
            'validation_status', 'english', 'comment', 'transcription', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 1)
            ->with(['dcDirected' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();
        $spontaneouses = AudioTrim::where('status', 3)->with(['dcSpontaneous' => function ($d) {
            $d->select('id', 'spontaneous_id', 'audio','status','data_collection_id', 'validation_status', 'english',
                'transcription', 'bangla', 'approved_by', 'approved_date');
            $d->with('collection.speaker', 'collection.language', 'collection.district', 'spontaneous');
        }])->latest()->get();

        $word = DCWordCollection::select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
            'validation_status', 'english', 'transcription', 'comment', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 1)
            ->with(['dcWord' => function ($d) {
                $d->with('collection.speaker', 'collection.language', 'collection.district', 'topicWord');
            }, 'word'])->latest()->get();

        $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        $dataCollections = $word->mergeRecursive($dataCollections)->all();

        return view('admin.data_collection.approvedList', compact('dataCollections'));
    }

    public function index(Request $request)
    {
        if (Auth::user()->user_type == 4) {

            $dataCollections = DataCollection::where('created_by', auth()->id())
                ->with('language', 'district', 'collector', 'speaker')
                ->groupBy(['language_id', 'collector_id', 'speaker_id', 'district_id'])
                ->latest()
                ->get();
            $languages = DataCollection::where('created_by', auth()->id())
                ->with('language')->groupBy('language_id')->get();
            $districts = DataCollection::where('created_by', auth()->id())
                ->with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::where('created_by', auth()->id())
                ->with('collector')->groupBy('collector_id')->get();
            $speakers = DataCollection::where('created_by', auth()->id())
                ->with('speaker')->groupBy('speaker_id')->get();

            if ($request->language_id != '' || $request->district_id != '' || $request->speaker_id != '') {

                $query = DataCollection::query();

                if (isset($request->language_id)) {
                    $query->whereIn('language_id', [$request->language_id])
                        ->whereIn('collector_id', [auth()->id()]);
                }
                if (isset($request->district_id)) {
                    $query->whereIn('district_id', [$request->district_id])
                        ->whereIn('collector_id', [auth()->id()]);
                }
                if (isset($request->speaker_id)) {
                    $query->whereIn('speaker_id', [$request->speaker_id]);
                }
                $dataCollections = $query;
                $dataCollections = $dataCollections->with('language', 'district', 'collector', 'speaker')
                    ->groupBy(['language_id', 'collector_id', 'speaker_id', 'district_id'])
                    ->latest()
                    ->get();
            }
        } else {

            $dataCollections = DataCollection::with('language', 'district', 'collector', 'speaker')
                ->groupBy(['language_id', 'collector_id', 'speaker_id', 'district_id'])
                ->latest()
                ->get();
            $languages = DataCollection::with('language')->groupBy('language_id')->get();
            $districts = DataCollection::with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::with('collector')->groupBy('collector_id')->get();
            $speakers = DataCollection::with('speaker')->groupBy('speaker_id')->get();

            if ($request->language_id != '' || $request->district_id != '' || $request->collector_id != '' || $request->speaker_id != '') {

                $query = DataCollection::query();

                if (isset($request->language_id)) {
                    $query->whereIn('language_id', [$request->language_id]);
                }
                if (isset($request->district_id)) {
                    $query->whereIn('district_id', [$request->district_id]);
                }
                if (isset($request->collector_id)) {
                    $query->whereIn('collector_id', [$request->collector_id]);
                }
                if (isset($request->speaker_id)) {
                    $query->whereIn('speaker_id', [$request->speaker_id]);
                }
                $dataCollections = $query;
                $dataCollections = $dataCollections->with('language', 'district', 'collector', 'speaker')
                    ->groupBy(['language_id', 'collector_id', 'speaker_id', 'district_id'])
                    ->latest()
                    ->get();
            }
        }
        $selected_id = [];
        $selected_id['language_id'] = $request->language_id;
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;
        $selected_id['speaker_id'] = $request->speaker_id;



        return view('admin.data_collection.index', compact('dataCollections', 'languages', 'districts',
                'collectors', 'speakers', 'selected_id')
        );
    }


    public function dataCollectionCorrectionList(){

        if ((Auth::user()->user_type == 4)) {

            $directeds = DCDirectedSentence::where('created_by', auth()->id())->where('status', 2)->with(['dcDirected' => function ($d) {
                $d->with('collection.collector', 'collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();
            $spontaneouses = DCSpontaneous::where('created_by', auth()->id())->where('status', 2)
                ->with('collection.collector', 'collection.speaker', 'collection.language', 'collection.district', 'spontaneous')
                ->latest()
                ->get();
            /*  return */
            $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        }


        return view('admin.data_collection.correctionList', compact('dataCollections'));
    }
    public function dataCollectionCorrectionForAdminList(){

        $directeds = DCDirectedSentence::select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
            'validation_status', 'english', 'comment', 'transcription', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 2)->where('created_by', auth()->id())
            ->with(['dcDirected' => function ($d) {
                $d->with('collection.collector', 'collection.speaker', 'collection.language', 'collection.district', 'topic');
            }, 'directed'])->latest()->get();

        $spontaneouses = AudioTrim::where('status', 2)->with(['dcSpontaneous' => function ($d) {
            $d->select('id', 'spontaneous_id', 'audio','status','data_collection_id', 'validation_status', 'english',
                'transcription', 'bangla', 'approved_by', 'approved_date');
            $d->with('collection.collector', 'collection.speaker', 'collection.language', 'collection.district', 'spontaneous');
        }])->whereHas('dcSpontaneous', function ($q) {
            $q->where('created_by', auth()->id());
        })->latest()->get();

        $word = DCWordCollection::select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
            'validation_status', 'english', 'transcription', 'comment', 'bangla', 'approved_by', 'approved_date')
            ->where('status', 2)->where('created_by', auth()->id())
            ->with(['dcWord' => function ($d) {
                $d->with('collection.collector', 'collection.speaker', 'collection.language', 'collection.district', 'topicWord');
            }, 'word'])->latest()->get();

        // directeds spontaneouses word merge
        $dataCollections = $directeds->mergeRecursive($spontaneouses)->all();
        $dataCollections = $word->mergeRecursive($dataCollections)->all();
        // return $dataCollections;

        return view('admin.user_wise_data_collection.CorrectionList', compact('dataCollections'));
    }


    protected function dcSpont($request, $dataCollection, $audioUrl, $spo_id, $audio_file){

        $dcSpont = new DCSpontaneous();
        $ffprobe    = \FFMpeg\FFProbe::create();
        $dcSpont->data_collection_id = $dataCollection;
        if ($request->hasFile('audio')) {

            $dcSpont->audio = $request->hasFile('audio') ? $audioUrl : '';
            $dcSpont->audio_blob = null;
            $duration = $ffprobe->format($audioUrl)->get('duration');
            $length = $duration / 60;
            $dcSpont->audio_duration  = $length;
        } elseif ($request->audio_blob == !null) {

            $dcSpont->audio      = $audioUrl;
            $dcSpont->audio_blob = null;
            $duration = $ffprobe->format($audioUrl)->get('duration');
            $length = $duration / 60;
            $dcSpont->audio_duration  = $length;
        }
        $dcSpont->spontaneous_id = $spo_id;
        $dcSpont->bangla = $request->bangla;
        $dcSpont->english  = $request->english;
        $dcSpont->transcription  = $request->transcription;
        $dcSpont->approved_date = Carbon::today()->toDateTimeString();
        $dcSpont->created_by = Auth::id();
        $dcSpont->updated_by = Auth::id();
        $dcSpont->save();
        return $dcSpont;
    }

    protected function dcDirectSentence($request, $dcDirect, $audioUrl, $directed_id, $audio_file){

        $dcDirectSentence = new DCDirectedSentence();
        $ffprobe    = \FFMpeg\FFProbe::create();
        if ($request->hasFile('audio')) {

            $dcDirectSentence->audio = $request->hasFile('audio') ? $audioUrl : '';
            $dcDirectSentence->audio_blob = null;
            $duration = $ffprobe->format($audioUrl)->get('duration');
            $length = $duration / 60;
            $dcDirectSentence->audio_duration  = $length;
        } elseif ($request->audio_blob == !null) {

            $dcDirectSentence->audio      = $audioUrl;
            $dcDirectSentence->audio_blob = null;
            $duration = $ffprobe->format($audioUrl)->get('duration');
            $length = $duration / 60;
            $dcDirectSentence->audio_duration  = $length;
        }
        $dcDirectSentence->d_c_directed_id  = $dcDirect->id;
        // $dcDirectSentence->english  = $request->english;
        $dcDirectSentence->transcription  = $request->transcription;
        $dcDirectSentence->modified_sentence  = $request->modified_sentence;
        $dcDirectSentence->directed_id   = $directed_id;
        $dcDirectSentence->topic_status   = 2;
        $dcDirectSentence->approved_date   = Carbon::today()->toDateTimeString();
        $dcDirectSentence->created_by   = Auth::id();
        $dcDirectSentence->updated_by   = 0;
        $dcDirectSentence->updated_at   = NULL;
        $dcDirectSentence->save();
        return $dcDirectSentence;
    }

    protected function dataCollection($request, $speaker){
        // return $request->all();
        $dataCollection = new DataCollection();
        $dataCollection->type_id = $request->type_id == 'directeds' ? 1 : 2;
        $dataCollection->language_id = $request->language_id;
        $dataCollection->district_id = $request->district_id;
        $dataCollection->task_assign_id = $request->task_assign_id;
        $dataCollection->collector_id  = Auth::id();
        $dataCollection->speaker_id  = $speaker;
        $dataCollection->created_by  = Auth::id();
        $dataCollection->updated_by  = Auth::id();
        $dataCollection->save();
        return  $dataCollection;
    }

    protected function dcDirect($dataCollectionID, $topicID){

        $dcDirect = new DCDirected();
        $dcDirect->data_collection_id = $dataCollectionID;
        $dcDirect->topic_id = $topicID;
        $dcDirect->created_by = Auth::id();
        $dcDirect->updated_by = 0;
        $dcDirect->save();
        return $dcDirect;
    }

    public function show($id){

        $spontaneous = DCSpontaneous::with(['collection.language', 'collection.district', 'collection' => function ($e) {
            $e->with([
                'collector', 'speaker',
                'taskAssign' => function ($q) {
                    $q->with('group');
                }
            ]);
        }, 'spontaneous'])
            ->where('id', $id)->first();
        return view('admin.data_collection.show', compact('spontaneous'));
    }

    public function showDirected($id){
        $directed = DCDirectedSentence::with(['dcDirected' => function ($q) {
            $q->with(['collection.language', 'collection.district', 'collection.collector', 'collection.speaker', 'collection.taskAssign' => function ($e) {
                $e->with('group');
            }, 'topic']);
        }, 'directed'])
            ->where('id', $id)->first();
        return view('admin.data_collection.showDirected', compact('directed'));
    }

    public function edit($id){
        $spontaneousAudio = DCSpontaneous::with(['collection' => function ($e) {
            $e->with([
                'collector', 'speaker',
                'taskAssign' => function ($q) {
                    $q->with('group');
                }
            ]);
        }, 'spontaneous'])
            ->where('id', $id)->first();
        return view('admin.data_collection.edit', compact('spontaneousAudio'));
    }


    public function editDirected($TaskID, $topicID){
        $directedLanguages = DirectedTaskAssign::where('task_assign_id', $TaskID)
            ->where('topic_id', $topicID)
            ->with('collector', 'taskAssign.speakers', 'taskAssign.language', 'taskAssign.district', 'topic.directeds')
            ->first();
        $taskBySentences = $directedLanguages->topic->directeds->paginate(1);
        $sentenceList = $directedLanguages->topic->directeds;

        return view('admin.data_collection.editDirected', compact('sentenceList', 'taskBySentences', 'directedLanguages'));
    }


    public function editSpontaneous($id){
        $dcSpontaneous = DCSpontaneous::with(['collection' => function ($e) {
            $e->with([
                'language', 'district', 'collector', 'speaker',
                'taskAssign' => function ($q) {
                    $q->with('group');
                }
            ]);
        }, 'spontaneous'])
            ->where('id', $id)->first();
        return view('admin.data_collection.editSpontaneous', compact('dcSpontaneous'));
    }

    public function update(Request $request, $id){
        $dcSpontaneous = DCSpontaneous::findOrFail($id);
        $dcSpontaneous->approved_date = Carbon::today()->toDateTimeString();
        $dcSpontaneous->approved_by = $request->approved_by;
        $dcSpontaneous->update();

        return redirect()->route('admin.data_collections.index')->with('success', __('messages.স্বতঃস্ফূর্ত সংগৃহীত ডাটাটি সফলভাবে অনুমোদিত হয়েছে।'));
    }

    public function updateDirected(Request $request, $id){
        if ($id== 0){
            return response()->json(['msg' => __('এখনও  অডিও কালেকশন হয়নি ।')]);
        }
        $dcDirectedSentence = DCDirectedSentence::findOrFail($id);
        $dcDirectedSentence->english = $request->english;
        $dcDirectedSentence->transcription = $request->transcription;
        $dcDirectedSentence->modified_sentence = $request->modified_sentence;
        $dcDirectedSentence->update();
        return response()->json(['msg' =>__('নির্দেশিত বাক্য সফলভাবে আপডেট করা হয়েছে।')]);
    }

    public function updateSpontaneous(Request $request, $id){

        $request->validate([
            'bangla'      => 'required',
            'english'    => 'required',
            'transcription'    => 'required',
        ]);
        $dcSpontaneous = DCSpontaneous::findOrFail($id);
        $dcSpontaneous->bangla = $request->bangla;
        $dcSpontaneous->english = $request->english;
        $dcSpontaneous->transcription = $request->transcription;
        $dcSpontaneous->update();

        return redirect()->back()->with('success', 'Spontaneous Collection has been Updated Successfully');
    }

    public function destroy($id){
        AudioTrim::where('d_c_spontaneouses_id', $id)->delete();
        $dcSpontaneous = DCSpontaneous::findOrFail($id);
        $audioPath = public_path($dcSpontaneous->audio);
        if (File::exists($audioPath)) {
            File::delete($audioPath);
        }
        $dcSpontaneous->delete();
        $dataCollection = DataCollection::findOrFail($dcSpontaneous->data_collection_id);
        $dataCollection->delete();

        return redirect()->back()->with('success', __('messages.স্বতঃস্ফূর্ত সংগৃহীত ডাটাটি সফলভাবে মুছে ফেলা হয়েছে'));
    }

    public function destroyDirected($id){

        AudioTrim::where('d_c_directed_sentences_id', $id)->delete();
        $dcDirectedSentence = DCDirectedSentence::findOrFail($id);
        $audioPath = public_path($dcDirectedSentence->audio);
        if (File::exists($audioPath)) {
            File::delete($audioPath);
        }
        $dcDirectedSentence->delete();
        $dcDirected = DCDirected::findOrFail($dcDirectedSentence->d_c_directed_id);
        $dcDirected->delete();
        $dataCollection = DataCollection::findOrFail($dcDirected->data_collection_id);
        $dataCollection->delete();

        return redirect()->back()->with('success', __('messages.নির্দেশিত সংগৃহীত ডাটাটি সফলভাবে মুছে ফেলা হয়েছে'));
    }
    public function destroyWord($id){

        $dcWordCollection = DCWordCollection::findOrFail($id);
        $audioPath = public_path($dcWordCollection->audio);
        if (File::exists($audioPath)) {
            File::delete($audioPath);
        }
        $dcWordCollection->delete();
        $dcWord = DCWord::findOrFail($dcWordCollection->d_c_word_id);
        $dcWord->delete();
        $dataCollection = DataCollection::findOrFail($dcWord->data_collection_id);
        $dataCollection->delete();

        return redirect()->back()->with('success', __('সংগৃহীত ডাটাটি সফলভাবে মুছে ফেলা হয়েছে'));
    }

   /* public function directedSendToApprove($id){
        $directedAudio = DCDirectedSentence::with(['dcDirected' => function ($q) {
            $q->with(['collection.district', 'collection.language', 'collection.collector', 'collection.speaker', 'collection.taskAssign' => function ($e) {
                $e->with('group');
            }, 'topic']);
        }, 'directed'])
            ->where('id', $id)->first();
        return view('admin.data_approval.directed_sendToApprove', compact('directedAudio'));
    }*/

  /*  public function sentToDataApproved(Request $request, $id){
        if ($id) {
            DCDirectedSentence::where('id', $id)
                ->update(['approved_date' => Carbon::now(), 'approved_by' => auth()->id(), 'status' => '1', 'topic_status' => '4']);
        }

        return redirect()->route('admin.directed.languages.sentence.list', ['task_assign_id' => $request->task_assign_id, 'topic_id' => $request->topic_id])
            ->with('success', 'Data Collection has been Approved');
    }*/

    public function topicWiseDirectedApprove(Request $request){
        DCDirectedSentence::where('id', $request->d_c_directed_sentence_id)
            ->update(['approved_date' => Carbon::now(), 'approved_by' => auth()->id(), 'status' => '1', 'topic_status' => '4']);
        return response()->json(['msg' => __('নির্দেশিত সফলভাবে অনুমোদিত হয়েছে')]);
    }


    public function directedDataRevert($id){
        $directedAudio = DCDirectedSentence::with(['dcDirected' => function ($q) {
            $q->with(['collection.district', 'collection.language', 'collection.collector', 'collection.speaker', 'collection.taskAssign' => function ($e) {
                $e->with('group');
            }, 'topic']);
        }, 'directed'])
            ->where('id', $id)->first();
        return view('admin.data_approval.directed_revert', compact('directedAudio'));
    }

    public function directedRevert($id){

        $revert = DCDirectedSentence::findOrFail($id);

        return response()->json([
            'revert' => $revert,
        ], 200);
    }
    public function directedSendToRevert(Request $request){

        $trimID = $request->trimID;
        $collectorID = $request->input('collector_id');

        $audio = DCDirectedSentence::findOrFail($trimID);
        $audio->status = 2;
        $audio->comment = $request->comment;
        $audio->update();
        // Sent to user Notification

        $n_title = 'Data Reverted';
        $n_body  = 'Your Collection data is reverted';

        Notification::create([

            'user_id'     => $collectorID,
            'title'       => $n_title,
            'body'        => $n_body,
            'status'      => 0,
            'created_by'  => Auth::user()->id
        ]);


        return redirect()->route('admin.directed.languages.sentence.list', ['task_assign_id' => $request->task_assign_id, 'topic_id' => $request->topic_id])
            ->with('success', 'Data has been Commented & reverted successfully ');
    }
    public function directedDataValidationRevert($id){

        $revert = DCDirectedSentence::findOrFail($id);

        return response()->json([
            'revert' => $revert,
        ], 200);
    }
    public function wordDataValidationRevert($id){

        $revert = DCWordCollection::findOrFail($id);

        return response()->json([
            'revert' => $revert,
        ], 200);
    }


    public function directedToRevertData(Request $request){

        $collectorID = $request->collector_id;
        $dcDirectedSentenceID = $request->dc_directed_sentence_id;

        $dcDirectedSentence = DCDirectedSentence::findOrFail($dcDirectedSentenceID);
        $dcDirectedSentence->status = 2;
        $dcDirectedSentence->validation_status = 0;
        $dcDirectedSentence->comment = $request->comment;
        $dcDirectedSentence->update();
        // Sent to user Notification

        $directedRevertUrl= route('admin.data_collection.redirected.topic.revert',
            ['task_assign_id' => $request->task_assign_id, 'topic_id' => $request->topic_id, 'directed_id' => $dcDirectedSentence->directed_id]);

        $topic = Topic::findOrFail($request->topic_id);
        $directed = Directed::findOrFail($dcDirectedSentence->directed_id);

        // create time of
        $title = 'Directed Data Reverted of '.$topic->name;
        $message = 'Your Directed data Collection is reverted.'."<br>";
        $message .= 'Topic: '.$topic->name.' and sentence: '.$directed->sentence."<br>";
        $message = $message.'Correction messages is '.$request->comment.'.';
        $message = $message . "<br><br><a href='$directedRevertUrl' class='btn btn-sm bg-success' target='_blank'>নির্দেশিত</a>";


        Notification::create([
            'user_id'     => $collectorID,
            'title'       => $title,
            'body'        => $message,
            'status'      => 0,
            'created_by'  => Auth::user()->id
        ]);
        return redirect()->back()->with('success', 'নির্দেশিত বাক্যটি রিভার্ট করা হয়েছে ');
    }

    public function wordToRevertData(Request $request){
        // return $request->all();
        $collectorID = $request->collector_id;
        $dcWordCollectionID = $request->dc_word_collection_id;

        $dcWordCollection = DCWordCollection::findOrFail($dcWordCollectionID);
        $dcWordCollection->status = 2;
        $dcWordCollection->validation_status = 0;
        $dcWordCollection->comment = $request->comment;
        $dcWordCollection->update();

        // Sent to user Notification
        $topicWord= Word::with('topicsWord')->findOrFail($dcWordCollection->word_id);
        $wordRevertUrl= route('admin.data_collection.redirected.word.revert',
            ['task_assign_id' => $request->task_assign_id, 'topic_word_id' => $topicWord->topic_word_id, 'word_id' => $dcWordCollection->word_id]);

        // create time of
        $title = 'Word Data Reverted of '.$topicWord->topicsWord->name;
        $message = 'Your Word data collection is reverted.'."<br>";
        $message .= 'Topic: '.$topicWord->topicsWord->name.' and sentence: '.$topicWord->sentence."<br>";
        $message = $message.'Correction messages is '.$request->comment.'.';
        $message = $message . "<br><br><a href='$wordRevertUrl' class='btn btn-sm bg-success' target='_blank'>শব্দ ও ব্যাকরণ</a>";


        Notification::create([
            'user_id'     => $collectorID,
            'title'       => $title,
            'body'        => $message,
            'status'      => 0,
            'created_by'  => Auth::user()->id
        ]);

        return redirect()->back()->with('success', __('শব্দ ও ব্যাকরণ বাক্যটি রিভার্ট করা হয়েছে'));
    }


    public function directedToRevert($id){

        $revert = DCDirectedSentence::findOrFail($id);

        return response()->json([
            'revert' => $revert,
        ], 200);
    }

    public function getDataCollectionList($lanID=null, $distID=null, $collectorID=null, $speakerID=null){
        if ($lanID == null || $distID == null || $collectorID == null || $speakerID == null) {
            return abort(404);
        }
        $dataCollections = DataCollection::where('language_id', $lanID)->where('district_id', $distID)
            ->where('collector_id', $collectorID)
            ->where('speaker_id', $speakerID)
            ->with(['language', 'district', 'collector', 'speaker', 'dcDirected.dcSentence.directed','dcSpontaneous.spontaneous',
                'dcDirected.dcSentence'=>function($q){
                    $q->select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                },
                'dcSpontaneous'=>function($q1){
                    $q1->select('id', 'spontaneous_id', 'audio','status','data_collection_id',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                },'dcWord.dcWordCollection'=>function($q2){
                    $q2->select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                }])
            ->latest()
            ->get();
        $diecteds = $dataCollections->unique('dcDirected.dcSentence.directed_id');
        $spontaneous = $dataCollections->unique('dcSpontaneous.spontaneous_id');
        $words = $dataCollections->unique('dcWord.dcWordCollection.word_id');
        $dataCollections = $diecteds->merge($spontaneous);
        $dataCollections = $dataCollections->merge($words);

        $dataCollections = $dataCollections->sortByDesc('created_at');

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        return view('admin.data_collection.collectionList', compact('dataCollections', 'firstItem'));
    }



    public function getTopicWiseDataCollection($TaskID, $topicID){

        $directedLanguages = DirectedTaskAssign::where('user_id', auth()->id())
            ->where('task_assign_id', $TaskID)
            ->where('topic_id', $topicID)
            ->with('collector', 'taskAssign.speakers', 'taskAssign.language', 'taskAssign.district', 'topic.directeds')
            ->first();
        $districts = District::pluck('name', 'id');
        $sentence = $directedLanguages->topic->directeds->paginate(1);
        $languageBySpeakers = DB::table('language_districts')
            ->join('speakers', 'language_districts.id', '=', 'speakers.language_district_id')
            ->join('districts', 'language_districts.district_id', '=', 'districts.id')
            ->where('language_id', $directedLanguages->taskAssign->language->id)
            ->select('language_districts.*', 'speakers.id as speaker_id', 'speakers.name as speaker_name', 'districts.name as district_name')
            ->get();
        $langSpeaker=$languageBySpeakers->pluck('id');
        $speakers = Speaker::whereIn('language_district_id', $langSpeaker)->with('district')->get();
        $speakers = $speakers->pluck('district.name');

        $data = [
            "task_assign_id" => $directedLanguages->task_assign_id,
            "district_id"    => $directedLanguages->taskAssign->district_id,
            "language_id"    => $directedLanguages->taskAssign->language_id,
        ];

        foreach ($sentence as $sentenceItem) {
            $directedID = $sentenceItem->id;
            $directedAudios = DataCollection::where('task_assign_id', $TaskID)
                ->where('type_id', 1)
                ->with('speaker', 'dcDirected.dcSentence.directed')
                ->whereHas('dcDirected', function ($q) use ($topicID) {
                    $q->where('topic_id', $topicID);
                })
                ->whereHas('dcDirected.dcSentence', function ($q1) use ($directedID) {
                    $q1->where('directed_id', $directedID);
                })
                ->get();
            $directedAudios = $directedAudios->unique('dcDirected.dcSentence.directed_id');
        }

        $directedCollections = DataCollection::where('task_assign_id', $TaskID)
            ->where('type_id', 1)
            ->with('dcDirected.dcSentence.directed')
            ->whereHas('dcDirected', function ($q) use ($topicID) {
                $q->where('topic_id', $topicID);
            })
            ->get();
        $directedCollections = $directedCollections->unique('dcDirected.dcSentence.directed_id');

        $sentenceList = $directedLanguages->topic->directeds;

        return view('admin.data_collection.data_collect_directed', compact('sentenceList', 'districts', 'sentence', 'directedAudios',
            'directedCollections', 'directedLanguages', 'data', 'languageBySpeakers', 'speakers'));
    }


    public function getTopicWiseValidation($TaskID, $topicID){
        $directedLanguages = DirectedTaskAssign::where('task_assign_id', $TaskID)
            ->where('topic_id', $topicID)
            ->with('taskAssign.validators', 'taskAssign.speakers', 'taskAssign.language', 'taskAssign.district', 'topic.directeds')
            ->first();
        //        dd($directedLanguages->toArray());
        $districts = District::pluck('name', 'id');
        $sentences = $directedLanguages->topic->directeds->paginate(1);

        $directedAudios = DataCollection::where('task_assign_id', $TaskID)
            ->where('type_id', 1)
            ->with('speaker', 'collector', 'dcDirected.dcSentence.validator', 'dcDirected.dcSentence.directed')
            ->whereHas('dcDirected', function ($q) use ($topicID) {
                $q->where('topic_id', $topicID);
            })
            ->paginate(1);

        //    dd($directedAudios->toArray());
        return view(
            'admin.data_collection.direct_validation',
            compact('districts', 'sentences', 'directedAudios', 'directedLanguages')
        );
    }

    public function topicWiseValidationStore(Request $request){
        DCDirectedSentence::where('id', $request->d_c_directed_sentence_id)
            ->update(['validator_id' => auth()->id(), 'validation_status' => $request->validation_status, 'topic_status' => '3']);

        return response()->json(['msg' => __('নির্দেশিত বাক্য সফলভাবে ভ্যালিডেট হয়েছে')]);
    }

    public function trimParentAudio ($type, $dc_sentence_id){
        if ($type == 'directed') {
            $audio = DCDirectedSentence::where('id',$dc_sentence_id)->with(['directed', 'dcDirected.collection.taskAssign'])->first();
        } elseif ($type == 'spontaneous') {
            $audio = DCSpontaneous::where('id', $dc_sentence_id)->with(['spontaneous', 'collection'])->first();
        }

        if (Facades\Session::has('trim_previous_url')) {
            Facades\Session::forget('trim_previous_url');
        }
        Facades\Session::put('trim_previous_url', url()->previous());

        return view('admin.data_collection.parent-trim', [
            'audio'     => $audio,
            'type'      => $type
        ]);
    }


    public function getWordWiseDataCollection($TaskID, $topicID){

        $spontaneous =  SpontaneousTaskAssign::where('user_id', auth()->id())
            ->where('task_assign_id', $TaskID)
            ->where('spontaneous_id', $topicID)
            ->with('collector', 'taskAssign.speakers', 'taskAssign.language', 'taskAssign.district', 'spontaneous')
            ->first();

        $districts = District::pluck('name', 'id');

        $data = [
            "task_assign_id" => $spontaneous->task_assign_id,
            "spontaneous_id" => $spontaneous->spontaneous_id,
            "language_id"    => $spontaneous->taskAssign->language_id,
            "district_id"    => $spontaneous->taskAssign->district_id,
        ];

        $spontaneousAudio = DataCollection::where('task_assign_id', $TaskID)
            ->where('type_id', 2)->with('speaker', 'dcSpontaneous')
            ->whereHas('dcSpontaneous', function ($q) use ($topicID) {
                $q->where('spontaneous_id', $topicID);
            })
            ->first();

        $languageBySpeakers = DB::table('language_districts')
            ->join('speakers', 'language_districts.id', '=', 'speakers.language_district_id')
            ->join('districts', 'language_districts.district_id', '=', 'districts.id')
            ->where('language_id', $spontaneous->taskAssign->language->id)
            ->select('language_districts.*', 'speakers.id as speaker_id', 'speakers.name as speaker_name', 'districts.name as district_name')
            ->get();
        $langSpeaker=$languageBySpeakers->pluck('id');

        $speakers = Speaker::whereIn('language_district_id', $langSpeaker)
            ->with('district')
            ->get();
        $speakers = $speakers->pluck('district.name');

        return view('admin.data_collection.data_collect_spontaneous', compact('spontaneousAudio', 'data', 'spontaneous', 'districts',
            'languageBySpeakers','speakers'));
    }


    public function getWordWiseValidation($TaskID, $topicID){
        if (Auth::user()->hasRole('Linguist') || Auth::user()->hasRole('Validator')) {
            $spontaneous =  SpontaneousTaskAssign::where('task_assign_id', $TaskID)
                ->where('spontaneous_id', $topicID)
                ->with('taskAssign.validators', 'taskAssign.language', 'taskAssign.district', 'spontaneous')->first();
            //            dd($spontaneous->toArray());
        }

        $districts = District::pluck('name', 'id');

        $spontaneousAudio = DataCollection::where('task_assign_id', $TaskID)
            ->where('type_id', 2)->with('speaker', 'collector', 'dcSpontaneous.validator')
            ->whereHas('dcSpontaneous', function ($q) use ($topicID) {
                $q->where('spontaneous_id', $topicID);
            })
            ->first();
        //         dd($spontaneousAudio->toArray());

        return view('admin.data_collection.spont_validation', compact('spontaneousAudio', 'spontaneous', 'districts'));
    }

    public function wordWiseValidationStore(Request $request){

        AudioTrim::where('id', $request->audio_trim_id)
            ->update(['validator_id' => auth()->id(), 'validation_status' => $request->validation_status]);

        return response()->json(['msg' => __('স্বতঃস্ফূর্ত ওয়ার্ড সফলভাবে ভ্যালিডেট হয়েছে')]);
    }

    public function wordWiseApprove(Request $request){

        AudioTrim::where('id', $request->audio_trim_id)
            ->update(['approved_by' => auth()->id(), 'status' => '3']);

        return redirect()->back()->with('success', __('স্বতঃস্ফূর্ত ওয়ার্ড সফলভাবে অনুমোদিত হয়েছে'));
    }


    public function submitSentence(StoreSentenceRequest $request){

        DB::beginTransaction();
        try {

            $sentence_id = $request->sentence_id;
            $type        = $request->type_id;
            $dc_spontaneous_id = $request->dc_spontaneous_id;

            if ($sentence_id == !null) {
                $this->updateSubmitSentence($type, $sentence_id, $request);
            } elseif ($dc_spontaneous_id == !null) {

                $this->updateSubmitSentence($type, $dc_spontaneous_id, $request);
            } else {
                if ($request->audio_blob == !null) {

                    $audio_re_file = $request->audio_blob;
                    $audio_file = str_replace('data:audio/wav;base64,', '', $audio_re_file);

                    $dataCollection = $this->dataCollection($request, $request->speaker_id);

                    if ($request->type_id == 'directeds') {
                        $dcDirect = $this->dcDirect($dataCollection->id,  $request->topic_id);
                        $this->dcDirectSentence($request, $dcDirect, session()->get('compressPath'), $request->directed_id, $audio_file);
                    } else {
                        $this->dcSpont($request, $dataCollection->id, session()->get('compressPath'), $request->spontaneous_id, $audio_file);
                    }
                } else {

                    $dataCollection = $this->dataCollection($request, $request->speaker_id);

                    foreach ($request->file('audio') as $key => $item) {

                        $audio_src  = file_get_contents( $item);
                        $audio_file = base64_encode($audio_src);

                        if($request->hasFile('audio')){
                            $audioName  =   time().'_'.unique_code(10).'.'.$item->getClientOriginalExtension();
                            $directory  =   'uploads/data-collections/';
                            $audioUrl   =   $directory.$audioName;
                            $item->move($directory, $audioName);
                        }

                        if ($request->type_id == 'directeds') {
                            $dcDirect = $this->dcDirect($dataCollection->id, $request->topic_id);
                            $this->dcDirectSentence($request, $dcDirect, $audioUrl, $request->directed_id,$audio_file);
                        } else {
                            $this->dcSpont($request, $dataCollection->id, $audioUrl, $request->spontaneous_id , $audio_file);
                        }
                    }
                }
            }
            DB::commit();

            return response()->json(['msg' => 'আপনার ডাটাটি সফলভাবে সংগ্রহ হয়েছে।', 'speaker_id'    => $request->speaker_id]);

        } catch (\Exception $th) {
            DB::rollBack();
            return response()->json(['error' => 'কিছু ভুল হয়েছে। আবার চেষ্টা করুন।'.$th->getMessage()]);
        }
    }


    public function updateSubmitSentence($type, $id, $request){

        if ($type == 'directeds') {

            $sentence = DCDirectedSentence::find($id);
            $sentence->transcription = $request->transcription;
            $sentence->modified_sentence = $request->modified_sentence;
            $sentence->updated_at= null;
            $sentence->save();

            if ($request->audio_blob == !null) {
                $audioPath = public_path($sentence->audio);
                if (File::exists($audioPath)) {
                    unlink($audioPath);
                }

                $ffprobe    = \FFMpeg\FFProbe::create();
                $sentence->audio = session()->get('compressPath');
                $sentence->audio_blob = null;
                $duration = $ffprobe->format(session()->get('compressPath'))->get('duration');
                $length=$duration/60;
                $sentence->audio_duration  = $length;
                $sentence->updated_at= null;
                $sentence->updated_at= null;
                $sentence->save();
            } else {

                if ($request->file('audio') == !null) {
                    $audioPath = public_path($sentence->audio);
                    if (File::exists($audioPath)) {
                        unlink($audioPath);
                    }
                    foreach ($request->file('audio') as $key => $audio_data) {

                        $audioName  =   time().'_'.unique_code(10).'.'.$audio_data->getClientOriginalExtension();
                        $directory  =   'uploads/data-collections/';
                        $audioUrl   =   $directory.$audioName;
                        $audio_data->move($directory, $audioName);

                        $ffprobe    = \FFMpeg\FFProbe::create();
                        $sentence->audio = $audioUrl;
                        $sentence->audio_blob = null;
                        $duration=$ffprobe->format($audioUrl)->get('duration');
                        $length=$duration/60;
                        $sentence->audio_duration  = $length;
                        $sentence->updated_at= null;
                        $sentence->save();
                    }
                }
            }
        } else {
            $spontaneousAudio = DCSpontaneous::findOrFail($id);

            if ($request->audio_blob == !null) {

                $audioPath = public_path($spontaneousAudio->audio);
                if (File::exists($audioPath)) {
                    unlink($audioPath);
                }
                $ffprobe    = \FFMpeg\FFProbe::create();
                $spontaneousAudio->audio = session()->get('compressPath');
                $spontaneousAudio->audio_blob = null;
                $duration = $ffprobe->format(session()->get('compressPath'))->get('duration');
                $length=$duration/60;
                $spontaneousAudio->audio_duration  = $length;
                $spontaneousAudio->bangla = $request->bangla;
                $spontaneousAudio->english = $request->english;
                $spontaneousAudio->transcription = $request->transcription;
                $spontaneousAudio->save();
            } else {

                if ($request->file('audio') == !null) {
                    $audioPath = public_path($spontaneousAudio->audio);
                    if (File::exists($audioPath)) {
                        unlink($audioPath);
                    }
                    foreach ($request->file('audio') as $key => $audio_data) {
                        $audioName  =   time().'_'.unique_code(10).'.'.$audio_data->getClientOriginalExtension();
                        $directory  =   'uploads/data-collections/';
                        $audioUrl   =   $directory.$audioName;
                        $audio_data->move($directory, $audioName);

                        $ffprobe    = \FFMpeg\FFProbe::create();
                        $spontaneousAudio->audio = $audioUrl;
                        $spontaneousAudio->audio_blob = null;
                        $duration = $ffprobe->format($audioUrl)->get('duration');
                        $length=$duration/60;
                        $spontaneousAudio->audio_duration  = $length;
                        $spontaneousAudio->bangla = $request->bangla;
                        $spontaneousAudio->english = $request->english;
                        $spontaneousAudio->transcription = $request->transcription;
                        $spontaneousAudio->save();
                        return response()->json(['success' => 'সফলভাবে আপডেট হয়েছে।']);
                    }
                }
            }
        }
    }

    public function sendToApprove(Request $request){

        DCDirectedSentence::where('id', $request->d_c_directed_sentence_id)
            ->update([/*'approved_date' => Carbon::now(), 'approved_by' => auth()->id(),*/ 'status' => $request->status, 'validation_status' => NULL]);

        return redirect()->back()->with('success', __('Directed Sentence Send to Approve Successfully'));
    }

    public function uploadAudio(Request $request){

        $user=Auth::user()->name;
        $decoded_file = $request->getContent();  //Decoded audio file
        $audio_parts  = explode(";base64,", $decoded_file);
        $audio_type   = explode("audio/wav", $audio_parts[0]);
        $audio_base64 = base64_decode($audio_parts[1]);
        $audio_directory = 'uploads/data-collections/original/';
        $file_name_no_ext =  'record_'.time().'_'.unique_code(10);
        $file_name = $file_name_no_ext . '.mp3';
        $record = file_put_contents($audio_directory . $file_name, $audio_base64);

        //compress audio start
        $compress_audio_directory = 'uploads/data-collections/';
        if (!file_exists($compress_audio_directory)) {
            mkdir($compress_audio_directory, 0777, true);
        }
        $compress_file_name_no_ext = 'compress_record_'.time().'_'.unique_code(10);
        $compress_file_name = $compress_file_name_no_ext . '.mp3';

        $inputAudio = $audio_directory . $file_name;
        $outputAudio = $compress_audio_directory . $file_name;
        exec("ffmpeg -i $inputAudio -ab 64 $outputAudio");

        /* $originalPath = public_path($inputAudio);
         if(File::exists($originalPath)) {
             File::delete($originalPath);
         }*/
        /*if (file_exists($inputAudio)) {
           @unlink($inputAudio);
        }*/

        $this->compressPath = $outputAudio;
        $this->x ='22';
        session()->put('compressPath', $outputAudio);
        return response('success');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DataCollection;
use App\Models\Word;
use App\Models\WordLanguage;
use App\Models\WordTaskAssign;
use App\Models\Language;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class WordLanguageController extends Controller
{
    public function getWordLanguageList($id){
        $wordLanguages=WordLanguage::with('topicsWord', 'language')->where('language_id', $id)->get();

        $firstItem = Arr::first($wordLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.word_language.index', compact('wordLanguages', 'firstItem'));
    }

    public function getWordTopicList($id){
        $wordLanguages=WordLanguage::with('topicsWord', 'language')->where('language_id', $id)->get();

        $firstItem = Arr::first($wordLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.word_language.topicList', compact('wordLanguages', 'firstItem'));
    }

    public function getTopicByWordCollection($taskAssignID, $topicID){
           $wordTaskByTopic=WordTaskAssign::where('task_assign_id', $taskAssignID)->where('topic_word_id', $topicID)
            ->with('taskAssign.language', 'taskAssign.district', 'topicWord.words',
                'taskAssign.collections.dcWord.dcWordCollection')
            ->first();
        $wordCollections =$wordTaskByTopic->topicWord->words;
        $collectorID=$wordTaskByTopic->taskAssign->user_id;

        return view('admin.word_language.wordList', compact('wordCollections', 'wordTaskByTopic', 'collectorID'));

    }

    public function topicBywordList($topicID , $languageID){

        $words= Word::with('topicsWord')->where('topic_word_id', $topicID)->get();


        $firstItem = Arr::first($words, function ($value, $key) {
            return $value;
        });
        $language=WordLanguage::with( 'language')
            ->where('topic_word_id', $topicID)
            ->where('language_id', $languageID)
            ->first();

        return view('admin.word_language.sentences', compact('words', 'firstItem', 'language'));
    }
}

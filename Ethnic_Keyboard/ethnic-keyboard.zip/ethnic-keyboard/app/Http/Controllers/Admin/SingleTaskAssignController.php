<?php

namespace App\Http\Controllers\Admin;

use App\Models\SubLanguage;
use App\Models\Topic;
use App\Models\User;
use App\Models\Group;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\Village;
use App\Models\District;
use App\Models\Language;
use App\Models\TaskAssign;
use App\Models\Notification;
use Illuminate\Http\Request;
use App\Models\DataCollector;
use App\Models\LanguageDistrict;
use App\Models\SingleTaskAssign;
use App\Traits\SendNotification;
use App\Models\DirectedTaskAssign;
use App\Models\WordTaskAssign;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\SpontaneousTaskAssign;
use App\Models\DirectedSingleTaskAssign;
use App\Models\SpontaneousSingleTaskAssign;
use App\Http\Requests\StoreSingleTaskAssignRequest;
use Illuminate\Support\Facades\Validator;

class SingleTaskAssignController extends Controller
{
    use SendNotification;
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $languages = Language::pluck('name', 'id');
        $collectors= User::where('user_type', 4)->pluck('name', 'id');
//        dd($collectors);
        return view('admin.single_task_assign.create', compact('languages', 'collectors'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSingleTaskAssignRequest /*Request*/ $request)
    {

        DB::beginTransaction();
        try {
            $singleTaskAssign = new TaskAssign();
            $singleTaskAssign->user_id =$request->user_id;
            $singleTaskAssign->language_id =$request->language_id;
            $singleTaskAssign->sub_language_id =$request->sub_language_id;
            $singleTaskAssign->district_id =$request->district;
            $singleTaskAssign->upazila_id =$request->upazila;
            $singleTaskAssign->union_id =$request->union;
            $singleTaskAssign->village =$request->village;
            $singleTaskAssign->start_date =$request->start_date;
            $singleTaskAssign->end_date =$request->end_date;
            $singleTaskAssign->created_by =auth()->id();
            $singleTaskAssign->updated_by =0;
            $singleTaskAssign->save();

            foreach ($request->input('topic_id') as $k=> $topicItem){
                $directed = new DirectedTaskAssign();
                $directed->task_assign_id = $singleTaskAssign->id;
                $directed->topic_id= $topicItem;
                $directed->user_id= $request->user_id;
                $directed->save();
            }

            foreach ($request->input('topic_word_id') as $k=> $topicItem){
                $word = new WordTaskAssign();
                $word->task_assign_id = $singleTaskAssign->id;
                $word->topic_word_id= $topicItem;
                $word->user_id= $request->user_id;
                $word->save();
            }

            foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
                $spontaneous = new SpontaneousTaskAssign();
                $spontaneous->task_assign_id = $singleTaskAssign->id;
                $spontaneous->spontaneous_id= $spontaneousItem;
                $spontaneous->user_id= $request->user_id;
                $spontaneous->save();
            }

            // // Store User Token
            $user = User::find($request->user_id);
            $language = Language::find($request->language_id);
            $district = District::find($request->district);

            $directedUrl = route('admin.directed.language.tasks.list', $singleTaskAssign->id);
            $wordUrl = route('admin.word.language.tasks.list', $singleTaskAssign->id);
            $spontaneousUrl = route('admin.spontaneous.language.tasks.list', $singleTaskAssign->id);

            // create time of
            $title = 'New Task Assign of '.$language->name.' in '.$district->name;
            $message = 'You have been assigned a new task in '.$language->name.' language of '.$district->name.' district.';
            $message = $message . "<br><br><a href='$directedUrl' class='btn btn-sm bg-success'>নির্দেশিত</a><br><br><a class='btn btn-sm bg-success' href='$wordUrl'>শব্দ ও ব্যাকরণ</a><br><br><a class='btn btn-sm bg-success' href='$spontaneousUrl'>স্বতঃস্ফূর্ত</a>";

            // $user->fcm_token = $request->user_token;
            // $user->save();
            // Sending Notification
            Notification::create([
                'user_id'     => $request->user_id,
                'title'       => $title,
                'body'        => $message,
                'status'      => 0,
                'created_by'  => Auth::user()->id
            ]);

            DB::commit();

            return response()->json(['msg' => __('টাস্ক অ্যাসাইন সফলভাবে অর্পণ করা হয়েছে।')]);

        } catch (\Exception $th) {
            DB::rollback();
            /*dd($th->getMessage());*/
            return redirect()->back()->with('error', $th->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(TaskAssign $singleTaskAssign)
    {
        $collectors= DB::table('users')
            ->join('task_assigns', 'users.id', '=', 'task_assigns.user_id')
            ->where('user_id', $singleTaskAssign->user_id)
            ->select('users.*')
            ->pluck('name', 'id');

        $districts = DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $singleTaskAssign->language_id)
            ->select('districts.*')
            ->pluck('name', 'id');

        $languages = Language::pluck('name', 'id');

         $subLanguages = SubLanguage::where([
            ['language_id', '=', $singleTaskAssign->language_id],
        ])->pluck('sub_name', 'id');

        $upazilas = Upazila::where([
            ['district_id', '=', $singleTaskAssign->district_id],
        ])->pluck('name', 'id');

        $unions = Union::where([
            ['upazila_id', '=', $singleTaskAssign->upazila_id],
        ])->pluck('name', 'id');
        /*$wordSelected = WordTaskAssign::with('topicWord')->where([
            ['task_assign_id', '=', $singleTaskAssign->id],
        ])->pluck('topic_word_id');*/

        $wordSelected = WordTaskAssign::where([['task_assign_id', '=', $singleTaskAssign->id]])->get();
        $wordSelected= $wordSelected->pluck('topicWord.id','topic_word_id')->toArray();
        $directedSelected = DirectedTaskAssign::where([['task_assign_id', '=', $singleTaskAssign->id],])->get();
        $directedSelected = $directedSelected->pluck('topic.id','topic_id')->toArray();
        $spontaneousSelected = SpontaneousTaskAssign::where([['task_assign_id', '=', $singleTaskAssign->id],])->get();
        $spontaneousSelected = $spontaneousSelected->pluck('spontaneous.id','spontaneous_id')->toArray();

        $words= DB::table('topic_words')
            ->join('word_languages', 'topic_words.id', '=', 'word_languages.topic_word_id')
            ->where('language_id', $singleTaskAssign->language_id)
            ->select('topic_words.*')
            ->pluck('name', 'id');
        $directeds= DB::table('topics')
            ->join('directed_languages', 'topics.id', '=', 'directed_languages.topic_id')
            ->where('language_id', $singleTaskAssign->language_id)
            ->select('topics.*')
            ->pluck('name', 'id');
        $spontaneouses= DB::table('spontaneouses')
            ->join('spontaneous_languages', 'spontaneouses.id', '=', 'spontaneous_languages.spontaneous_id')
            ->where('language_id', $singleTaskAssign->language_id)
            ->select('spontaneouses.*')
            ->pluck('word', 'id');


        return view('admin.single_task_assign.edit',
            compact('singleTaskAssign', 'collectors', 'districts', 'languages',
                'upazilas', 'unions','words', 'directeds', 'spontaneouses', 'subLanguages','wordSelected', 'directedSelected', 'spontaneousSelected'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(StoreSingleTaskAssignRequest $request, TaskAssign $singleTaskAssign)
    {
        DB::beginTransaction();
        try {

            $singleTaskAssign->user_id =$request->user_id;
            $singleTaskAssign->language_id =$request->language_id;
            $singleTaskAssign->sub_language_id =$request->sub_language_id;
            $singleTaskAssign->district_id =$request->district;
            $singleTaskAssign->upazila_id =$request->upazila;
            $singleTaskAssign->union_id =$request->union;
            $singleTaskAssign->village =$request->village;
            $singleTaskAssign->start_date =$request->start_date;
            $singleTaskAssign->end_date =$request->end_date;
            $singleTaskAssign->updated_by =auth()->id();
            $singleTaskAssign->update();

            $wordArray =[];
            $directedArray =[];
            $spontaneousArray =[];

            $wordSingleTaskAssignIDs = WordTaskAssign::where('task_assign_id',$singleTaskAssign->id)->get();
            if ($wordSingleTaskAssignIDs){
                foreach ($wordSingleTaskAssignIDs as $data){
                    $wordArray[]= $data->topic_word_id;
                }
            }

            $directedSingleTaskAssignIDs = DirectedTaskAssign::where('task_assign_id',$singleTaskAssign->id)->get();
            if ($directedSingleTaskAssignIDs){
                foreach ($directedSingleTaskAssignIDs as $data){
                    $directedArray[]= $data->topic_id;
                }
            }

            $SpontaneousSingleTaskAssignIDs = SpontaneousTaskAssign::where('task_assign_id',$singleTaskAssign->id)->get();
            if ($SpontaneousSingleTaskAssignIDs){
                foreach ($SpontaneousSingleTaskAssignIDs as $value){
                    $spontaneousArray[]= $value->spontaneous_id;
                }
            }

            foreach ($request->input('topic_word_id') as $k1=> $wordItem){
                $wordData = array(
                    'task_assign_id'=>$singleTaskAssign->id,
                    'topic_word_id'=>$wordItem,
                    'user_id'=>$request->user_id,
                );
                WordTaskAssign::updateOrCreate([
                    'task_assign_id'=>$singleTaskAssign->id,
                    'topic_word_id'=>$wordItem,
                    'user_id'=>$request->user_id,
                ], $wordData);
            }
            foreach ($request->input('topic_id') as $k2=> $topicItem){
                $directedData = array(
                    'task_assign_id'=>$singleTaskAssign->id,
                    'topic_id'=>$topicItem,
                    'user_id'=>$request->user_id,
                );
                DirectedTaskAssign::updateOrCreate([
                    'task_assign_id'=>$singleTaskAssign->id,
                    'topic_id'=>$topicItem,
                    'user_id'=>$request->user_id,
                ], $directedData);
            }

            foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
                $spontaneousData = array(
                    'task_assign_id'=>$singleTaskAssign->id,
                    'spontaneous_id'=>$spontaneousItem,
                    'user_id'=>$request->user_id,
                );
                SpontaneousTaskAssign::updateOrCreate([
                    'task_assign_id'=>$singleTaskAssign->id,
                    'spontaneous_id'=>$spontaneousItem,
                    'user_id'=>$request->user_id,
                ], $spontaneousData);
            }

            foreach ($wordArray as $wordTopic){
                if (!in_array($wordTopic, $request->topic_word_id)){
                    WordTaskAssign::where('task_assign_id',$singleTaskAssign->id)->where('topic_word_id', $wordTopic)->delete();
                }
            }

            foreach ($directedArray as $directedTopic){
                if (!in_array($directedTopic, $request->topic_id)){
                    DirectedTaskAssign::where('task_assign_id',$singleTaskAssign->id)->where('topic_id', $directedTopic)->delete();
                }
            }
            foreach ($spontaneousArray as $spontaneous){
                if (!in_array($spontaneous, $request->spontaneous_id)){
                    SpontaneousTaskAssign::where('task_assign_id',$singleTaskAssign->id)->where('spontaneous_id', $spontaneous)->delete();
                }
            }
            DB::commit();

            return redirect()->back()->with('success', __('টাস্ক অ্যাসাইন সফলভাবে আপডেট করা হয়েছে।'));
        } catch (\Exception $th) {
            DB::rollback();
            return redirect()->back()->with('error', __('Something went wrong').' '.$th->getMessage());
            //return redirect()->back()->with('error', 'Something went wrong, Please try again!');

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

    }



    public function getDistrict(Request $request){
        // $districts= LanguageDistrict::where('language_id', $request->language_id)->with('district')->get();

        $districts= DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $request->language_id)
            ->select('districts.*')
            ->pluck('bn_name', 'id');


        return response()->json($districts);
    }


}

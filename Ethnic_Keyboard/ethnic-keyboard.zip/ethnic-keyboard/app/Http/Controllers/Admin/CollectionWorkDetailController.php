<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\TaskAssign;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Spatie\Activitylog\Models\Activity;

class CollectionWorkDetailController extends Controller
{
    public function index(Request $request){
        $query = DataCollection::query();
        //$dataCollections=$query;
        if (Auth::user()->hasRole(['Data Collector'])){
            $dataCollections = $query->where('created_by', auth()->id());
            $languages = DataCollection::where('created_by', auth()->id())->with('language')->groupBy('language_id')->get();
            $districts = DataCollection::where('created_by', auth()->id())->with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::where('created_by', auth()->id())->with('collector')->groupBy('collector_id')->get();
        }
        if (Auth::user()->hasRole(['Admin', 'Manager'])){
            $languages = DataCollection::with('language')->groupBy('language_id')->get();
            $districts = DataCollection::with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::with('collector')->groupBy('collector_id')->get();
        }

        $languageID= $request->language_id;
        $districtID= $request->district_id;
        $collectorID= $request->collector_id;

        if($languageID != '' || $districtID != '' ||$collectorID != ''){
            $direcTopicCollections =$this->directeTopicLists($languageID, $districtID, $collectorID);
            $wordCollections = $this->wordTopicLists($languageID, $districtID, $collectorID);
            $sponWordCollections = $this->sponWordLists($languageID, $districtID, $collectorID);

            $dataCollections = $direcTopicCollections->merge($sponWordCollections);
            $dataCollections = $dataCollections->merge($wordCollections);
            $i = 1;
            foreach ($dataCollections as $dataCollection) {
                $dataCollection->serial_no = $i;
                $i++;
            }
            $dataCollections = $dataCollections->paginate(10);
            $dataCollections->appends(['language_id' => $languageID, 'district_id' => $districtID, 'collector_id' => $collectorID]);


        }else{

            $direcTopicCollections =$this->directeTopicLists();
            $wordCollections = $this->wordTopicLists();
            $sponWordCollections = $this->sponWordLists();

            $dataCollections = $direcTopicCollections->merge($sponWordCollections);
            $dataCollections = $dataCollections->merge($wordCollections);
            $i = 1;
            foreach ($dataCollections as $dataCollection) {
                $dataCollection->serial_no = $i;
                $i++;
            }
            $dataCollections = $dataCollections->paginate(10);
        }

        $selected_id = [];
        $selected_id['language_id'] = $request->language_id;
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;

        return view('admin.collection_work_detail.index',
            compact('dataCollections', 'languages', 'districts', 'collectors', 'selected_id'));
    }


    private function directeTopicLists($languageID = null, $districtID = null, $collectorID = null){

        if($languageID != '' || $districtID != '' ||$collectorID != ''){
            return $test=  DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_directeds', 'data_collections.id', '=', 'd_c_directeds.data_collection_id')
                ->join('topics', 'd_c_directeds.topic_id', '=', 'topics.id')
                ->where('data_collections.type_id', 1)
                ->where(function ($query) use ($languageID, $districtID, $collectorID) {
                    if ($languageID != '') {
                        $query->where('data_collections.language_id', $languageID);
                    }
                    if ($districtID != '') {
                        $query->where('data_collections.district_id', $districtID);
                    }
                    if ($collectorID != '') {
                        $query->where('data_collections.collector_id', $collectorID);
                    }
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_directeds.topic_id')
                ->get( ['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_directeds.topic_id', 'topics.name as topic_name',]);

        }else{
            return  DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_directeds', 'data_collections.id', '=', 'd_c_directeds.data_collection_id')
                ->join('topics', 'd_c_directeds.topic_id', '=', 'topics.id')
                ->where('data_collections.type_id', 1)
                ->where(function ($query) {
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_directeds.topic_id')
                ->get( ['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_directeds.topic_id', 'topics.name as topic_name',]);
        }

    }


    private function wordTopicLists($languageID = null, $districtID = null, $collectorID = null){
        if ($languageID != '' || $districtID != '' || $collectorID != '') {
            return   DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_words', 'data_collections.id', '=', 'd_c_words.data_collection_id')
                ->join('topic_words', 'd_c_words.topic_word_id', '=', 'topic_words.id')
                ->where('data_collections.type_id', 0)
                ->where(function ($query) use ($languageID, $districtID, $collectorID) {
                    if ($languageID != '') {
                        $query->where('data_collections.language_id', $languageID);
                    }
                    if ($districtID != '') {
                        $query->where('data_collections.district_id', $districtID);
                    }
                    if ($collectorID != '') {
                        $query->where('data_collections.collector_id', $collectorID);
                    }
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_words.topic_word_id')
                ->get(['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_words.topic_word_id', 'topic_words.name as topic_word_name',]);
        } else {
            return   DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_words', 'data_collections.id', '=', 'd_c_words.data_collection_id')
                ->join('topic_words', 'd_c_words.topic_word_id', '=', 'topic_words.id')
                ->where('data_collections.type_id', 0)
                ->where(function ($query) {
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_words.topic_word_id')
                ->get(['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_words.topic_word_id', 'topic_words.name as topic_word_name',]);
        }


    }

    private function sponWordLists($languageID = null, $districtID = null, $collectorID = null){
        if ($languageID != '' || $districtID != '' || $collectorID != '') {
            return   DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_spontaneouses', 'data_collections.id', '=', 'd_c_spontaneouses.data_collection_id')
                ->join('spontaneouses', 'd_c_spontaneouses.spontaneous_id', '=', 'spontaneouses.id')
                ->where('data_collections.type_id', 2)
                ->where(function ($query) use ($languageID, $districtID, $collectorID) {
                    if ($languageID != '') {
                        $query->where('data_collections.language_id', $languageID);
                    }
                    if ($districtID != '') {
                        $query->where('data_collections.district_id', $districtID);
                    }
                    if ($collectorID != '') {
                        $query->where('data_collections.collector_id', $collectorID);
                    }
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_spontaneouses.spontaneous_id')
                ->get(['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_spontaneouses.spontaneous_id', 'spontaneouses.word as spontaneous_name',]);
        } else {
            return   DB::table('data_collections')
                ->join('languages', 'data_collections.language_id', '=', 'languages.id')
                ->join('districts', 'data_collections.district_id', '=', 'districts.id')
                ->join('users', 'data_collections.collector_id', '=', 'users.id')
                ->join('d_c_spontaneouses', 'data_collections.id', '=', 'd_c_spontaneouses.data_collection_id')
                ->join('spontaneouses', 'd_c_spontaneouses.spontaneous_id', '=', 'spontaneouses.id')
                ->where('data_collections.type_id', 2)
                ->where(function ($query) {
                    if (Auth::user()->hasRole(['Data Collector'])){
                        $query->where('data_collections.created_by', auth()->id());
                    }
                })
                ->groupBy('data_collections.task_assign_id', 'd_c_spontaneouses.spontaneous_id')
                ->get(['data_collections.*', 'languages.name as language_name', 'districts.name as district_name', 'users.name as collector_name',
                    'd_c_spontaneouses.spontaneous_id', 'spontaneouses.word as spontaneous_name',]);
        }
    }


    public function show($type,$id)
    {
        $dataCollection = DataCollection::with('language', 'district',
            'collector', 'speaker', 'taskAssign.group',
            'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous')
            ->findOrFail($id);

        $trims = [];
        $spontinoursAudios = AudioTrim::where('d_c_spontaneouses_id', @$dataCollection->dcSpontaneous->id)->get();
        $spontinoursAudios = $spontinoursAudios->sortBy('start_time');
        if ($spontinoursAudios->isNotEmpty()) {
            foreach ($spontinoursAudios as $spontinoursAudio) {
                array_push($trims, $spontinoursAudio);
            }
        }

        $trims = array_filter($trims);

        return view('admin.collection_work_detail.show', compact('dataCollection', 'type', 'trims'));
    }


    /*public function todayCollection(Request $request)
    {
        $query = DataCollection::query();
        $dataCollections=$query;

        if (Auth::user()->user_type == 4){
            $dataCollections = $query->where('created_by', auth()->id());
            $languages = DataCollection::where('created_by', auth()->id())->with('language')->groupBy('language_id')->get();
            $districts = DataCollection::where('created_by', auth()->id())->with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::where('created_by', auth()->id())->with('collector')->groupBy('collector_id')->get();
            $speakers = DataCollection::where('created_by', auth()->id())->with('speaker')->groupBy('speaker_id')->get();
            $dataCollections=$dataCollections->whereDate('created_at', Carbon::today()->toDateString())
                ->with('language:id,name', 'district:id,name',
                    'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                    'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous')
                ->orderBy('id', 'desc')
                ->get();
        }
        if (Auth::user()->user_type == 1){
            $dataCollections= $query->whereHas('taskAssign', function ($query) {
                $query->orWhere('created_by', auth()->id());
            });
            $dataCollections=$dataCollections->whereDate('created_at', Carbon::today()->toDateString())
                ->with('language:id,name', 'district:id,name',
                    'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                    'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous')
                ->orderBy('id', 'desc')
                ->get();
        }
        if (Auth::user()->hasRole(['Admin', 'Manager'])) {
            $languages = DataCollection::with('language')->groupBy('language_id')->get();
            $districts = DataCollection::with('district')->groupBy('district_id')->get();
            $collectors = DataCollection::with('collector')->groupBy('collector_id')->get();
            $speakers = DataCollection::with('speaker')->groupBy('speaker_id')->get();
            $dataCollections=DataCollection::whereDate('created_at', Carbon::today()->toDateString())
                ->with('language:id,name', 'district:id,name',
                    'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                    'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous')
                ->orderBy('id', 'desc')
                ->get();
        }


        $direcTopicCollections = $dataCollections->where('type_id', 1)->unique(function ($item) {
            return $item['task_assign_id'].$item['dcDirected']['topic_id'];
        });
        $sponWordCollections = $dataCollections->where('type_id', 2)->unique(function ($item) {
            return $item['task_assign_id'].$item['dcSpontaneous']['spontaneous_id'];
        });
        $wordCollections = $dataCollections->where('type_id', 0)->unique(function ($item) {
            return $item['task_assign_id'].$item['dcWord']['topic_word_id']??'';
        });

        $dataCollections = $direcTopicCollections->merge($sponWordCollections);
        $dataCollections = $dataCollections->merge($wordCollections);
        $dataCollections = $dataCollections->sortByDesc('created_at');
//        dd($dataCollections->toArray());


        if($request->language_id != '' || $request->district_id != '' ||$request->collector_id != '' ||$request->speaker_id != ''){
            $query = DataCollection::query();
            if (isset($request->language_id)) {
                $query->whereIn('language_id', [$request->language_id]);
            }
            if (isset($request->district_id)) {
                $query->whereIn('district_id', [$request->district_id]);
            }
            if (isset($request->collector_id)) {
                $query->whereIn('collector_id', [$request->collector_id]);
            }
            if (isset($request->speaker_id)) {
                $query->whereIn('speaker_id', [$request->speaker_id]);
            }
            $dataCollections = $query;
            if (Auth::user()->user_type == 4){
                $dataCollections = $query->where('created_by', auth()->id());
            }elseif (Auth::user()->user_type == 1){
                $dataCollections = $query->whereHas('taskAssign', function ($query) {
                    $query->orWhere('created_by', auth()->id());
                });

            }
            $dataCollections=$dataCollections->whereDate('created_at', Carbon::today()->toDateString())
                ->with('language:id,name', 'district:id,name',
                    'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date')
                ->orderBy('id', 'desc')
                ->get();

            $direcTopicCollections = $dataCollections->where('type_id', 1)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcDirected']['topic_id'];
            });
            $sponWordCollections = $dataCollections->where('type_id', 2)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcSpontaneous']['spontaneous_id'];
            });
            $wordCollections = $dataCollections->where('type_id', 0)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcWord']['topic_word_id']??'';
            });

            $dataCollections = $direcTopicCollections->merge($sponWordCollections);
            $dataCollections = $dataCollections->merge($wordCollections);
            $dataCollections = $dataCollections->sortByDesc('created_at');
        }

        $selected_id = [];
        $selected_id['language_id'] = $request->language_id;
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;
        $selected_id['speaker_id'] = $request->speaker_id;


        return view('admin.collection_work_detail.today_collection',
            compact('dataCollections', 'languages', 'districts', 'collectors', 'speakers', 'selected_id'));
    }*/


    public function collectionList($type, $taskAssingId, $topicId){

        $query = DataCollection::query();
        $dataCollections=$query;
        if ($type == 'today'){
            $dataCollections = $query->whereDate('created_at', Carbon::today()->toDateString());
        }
        $dataCollections=$dataCollections->where('task_assign_id', $taskAssingId)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcDirected.dcSentence.directed',
                'dcDirected.dcSentence'=>function($q){
                    $q->select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                }])
            ->whereHas('dcDirected', function ($query) use ($topicId) {
                $query->where('topic_id', $topicId);
            })
            ->latest()
            ->get();
        $dataCollections = $dataCollections->unique('dcDirected.dcSentence.directed_id');

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        return view('admin.collection_work_detail.collectionList', compact('dataCollections', 'firstItem', 'type'));
    }


    public function wordCollectionList($type, $taskAssingId, $topicWordId){
        $query = DataCollection::query();
        $dataCollections=$query;
        if ($type == 'today'){
            $dataCollections = $query->whereDate('created_at', Carbon::today()->toDateString());
        }
        $dataCollections=$dataCollections->where('task_assign_id', $taskAssingId)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcWord.dcWordCollection.word',
                'dcWord.dcWordCollection'=>function($q2){
                    $q2->select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                }])
            ->whereHas('dcWord', function ($query) use ($topicWordId) {
                $query->where('topic_word_id', $topicWordId);
            })
            ->latest()
            ->get();

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        return view('admin.collection_work_detail.wordCollectionList', compact('dataCollections', 'firstItem', 'type'));
    }

}

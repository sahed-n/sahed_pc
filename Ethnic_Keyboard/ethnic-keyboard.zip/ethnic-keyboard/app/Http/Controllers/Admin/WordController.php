<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreDirectedRequest;
use App\Imports\TopicsImport;
use App\Imports\wordWithSentence;
use App\Models\Word;
use App\Models\Language;
use App\Models\Topic_word;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;

// use App\Imports\TopicsImport;
// use App\Imports\DirectedsImport;
// use Maatwebsite\Excel\Facades\Excel;

class WordController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $wordTopics = Topic_word::orderBy('id', 'desc')->get();

        return view('admin.word.index', compact('wordTopics'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            "name.*"    => "required|string",
        ]);

        if ($validator->passes()){

            foreach ($request->get('name') as $key=> $topicItem){
                $topic = new Topic_word();
                $topic->name = $topicItem;
                $topic->created_by = auth()->id();
                $topic->updated_by = 0;
                $topic->save();
            }

            return redirect()->route('admin.words.index')
                ->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে তৈরি করা হয়েছে৷'));
        }else{
            return redirect()->back()->withErrors($validator);// ['error'=>$validator->errors()->all()];
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $topic_word = Topic_word::findOrFail($id);

        return response()->json([
            'topic_word' => $topic_word,
        ], 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Directed $directed)
    {
        $request->validate([
            'name'      => 'required|string',
            'sentence'  => 'required',
            'english' => 'required',
        ]);
    }

    public function wordUpdate(Request $request){

        $validator = Validator::make($request->all(), [
            "name"    => "required|string",
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator);
        }

        $topicID = $request->topic_word_id;
        $topic_word =  Topic_word::find($topicID);
        $topic_word->name = $request->name;
        $topic_word->updated_by = auth()->id();
        $topic_word->update();

        return redirect()->route('admin.words.index')->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে আপডেট করা হয়েছে।'));

    }



    public function destroy($id)
    {
        Word::where('topic_word_id', $id)->delete();
        $topic_word =Topic_word::findOrFail($id);
        $topic_word->delete();

        return redirect()->back()->with('success', __('messages.নির্দেশিত বাক্য সফলভাবে মুছে ফেলা হয়েছে।'));
    }


    public function wordWithSentenceImport(Request $request)
    {
        Excel::import(new wordWithSentence(), $request->file('file'));
        return redirect()->back()->with('success', __('শব্দ সফলভাবে আপলোড করা হয়েছে।'));

    }


}

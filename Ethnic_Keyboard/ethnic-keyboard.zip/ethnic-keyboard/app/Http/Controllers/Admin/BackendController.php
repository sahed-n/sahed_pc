<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DCWordCollection;
use App\Models\TaskAssign;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rule;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
use Session;
use File;
use Spatie\Activitylog\Models\Activity;
use Yajra\DataTables\Facades\DataTables;

class BackendController extends Controller
{


    public function languageByDirectedCollection(Request $request, $languageID){

        $districts = DataCollection::with('district')
            ->where('type_id', 1)
            ->where('language_id', $languageID)
            ->groupBy('district_id')
            ->get();
        $collectors = DataCollection::with('collector')
            ->where('type_id', 1)
            ->where('language_id', $languageID)
            ->groupBy('collector_id')
            ->get();

        $dataCollections=DataCollection::with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
            'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
            'dcWord.topicWord.words', 'dcWord.dcWordCollection')
            ->where('type_id', 1)
            ->where('language_id', $languageID)
            ->orderBy('id', 'desc')
            ->paginate(10);
        if( $request->district_id != '' ||$request->collector_id != ''){
            $query = DataCollection::query();
            $dataCollections=$query;
            if (isset($request->district_id)) {
                $query->whereIn('district_id', [$request->district_id]);
            }
            if (isset($request->collector_id)) {
                $query->whereIn('collector_id', [$request->collector_id]);
            }

            $dataCollections=$dataCollections->with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
                'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
                'dcWord.topicWord.words', 'dcWord.dcWordCollection')
                ->where('type_id', 1)
                ->where('language_id', $languageID)
                ->orderBy('id', 'desc')
                ->paginate(10);
        }

        $selected_id = [];
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });
        $type='directed';

        return view('admin.language_assign.languageByCollection',
            compact('dataCollections', 'districts', 'collectors', 'selected_id', 'firstItem','type'));

    }

    public function languageByWordCollection(Request $request, $languageID){

        $districts = DataCollection::with('district')->where('type_id', 0)->where('language_id', $languageID)->groupBy('district_id')->get();
        $collectors = DataCollection::with('collector')->where('type_id', 0)->where('language_id', $languageID)->groupBy('collector_id')->get();

        $dataCollections=DataCollection::with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
            'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
            'dcWord.topicWord.words', 'dcWord.dcWordCollection')
            ->where('type_id', 0)
            ->where('language_id', $languageID)
            ->orderBy('id', 'desc')
            ->paginate(10);
        if( $request->district_id != '' ||$request->collector_id != ''){
            $query = DataCollection::query();
            $dataCollections=$query;
            if (isset($request->district_id)) {
                $query->whereIn('district_id', [$request->district_id]);
            }
            if (isset($request->collector_id)) {
                $query->whereIn('collector_id', [$request->collector_id]);
            }

            $dataCollections=$dataCollections->with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
                'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
                'dcWord.topicWord.words', 'dcWord.dcWordCollection')
                ->where('type_id', 0)
                ->where('language_id', $languageID)
                ->orderBy('id', 'desc')
                ->paginate(10);
        }

        $selected_id = [];
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        $type='word';

        return view('admin.language_assign.languageByCollection',
            compact('dataCollections', 'districts', 'collectors', 'selected_id', 'firstItem','type'));

    }
    public function languageBySpontaneousCollection(Request $request, $languageID){

        $districts = DataCollection::with('district')
            ->where('type_id', 2)
            ->where('language_id', $languageID)
            ->groupBy('district_id')
            ->get();
        $collectors = DataCollection::with('collector')
            ->where('type_id', 2)
            ->where('language_id', $languageID)
            ->groupBy('collector_id')
            ->get();

        $dataCollections=DataCollection::with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
            'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
            'dcWord.topicWord.words', 'dcWord.dcWordCollection')
            ->where('type_id', 2)
            ->where('language_id', $languageID)
            ->orderBy('id', 'desc')
            ->paginate(10);
        if( $request->district_id != '' ||$request->collector_id != ''){
            $query = DataCollection::query();
            $dataCollections=$query;
            if (isset($request->district_id)) {
                $query->whereIn('district_id', [$request->district_id]);
            }
            if (isset($request->collector_id)) {
                $query->whereIn('collector_id', [$request->collector_id]);
            }

            $dataCollections=$dataCollections->with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
                'dcDirected.topic.directeds', 'dcDirected.dcSentence', 'dcSpontaneous.spontaneous','dcSpontaneous.trimAudios',
                'dcWord.topicWord.words', 'dcWord.dcWordCollection')
                ->where('type_id', 2)
                ->where('language_id', $languageID)
                ->orderBy('id', 'desc')
                ->paginate(10);
        }

        $selected_id = [];
        $selected_id['district_id'] = $request->district_id;
        $selected_id['collector_id'] = $request->collector_id;

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        $type='spontaneous';

        return view('admin.language_assign.languageByCollection',
            compact('dataCollections', 'districts', 'collectors', 'selected_id', 'firstItem','type'));

    }

    public function profile(){

        $user = Auth::user();

        return view('user.profile', compact('user'));
    }


    public function updateProfile(Request  $request){
        $user = Auth::user();

        $request->validate([
            'name'      => 'required|string',
            'email'     => ['required', Rule::unique('users')->ignore($user->id)],
            'phone'    => ['required','regex:/(01)[0-9]{9}/', 'min:11', 'max:11', Rule::unique('users')->ignore($user->id)],
        ]);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->phone = $request->phone;

        if(request()->hasFile('avatar') && request('avatar') != ''){
            $imagePath = public_path($user->avatar);

            if(File::exists($imagePath)) {
                File::delete($imagePath);
//                 unlink($imagePath);
            }
            $avatar_image = $request->avatar;
            $avatar_image_new_name = time() . $avatar_image->getClientOriginalName();
            $avatar_image->move('uploads/users', $avatar_image_new_name);
            $user->avatar = 'uploads/users/' . $avatar_image_new_name;
        }
        $user->update();

        return redirect()->back()->with('success', __('messages.প্রোফাইল সফলভাবে আপডেট করা হয়েছে।'));
    }

    public function updatePassword(Request  $request){

        $request->validate([
            'password' => 'required|min:8|confirmed',
            'password_confirmation'     => 'required',
        ]);

        $user = Auth::user();
        $user->password = Hash::make($request->password);
        $user->update();

        return redirect()->back()->with('success', __('messages.পাসওয়ার্ড সফলভাবে আপডেট করা হয়েছে।'));
    }




    public function getCollection($id){
        $collection=DataCollection::findOrFail($id);
        if ($collection->type_id == 1){
            $collection = DataCollection::with(['taskAssign.group', 'language', 'district', 'speaker','collector', 'dcDirected'=>function($q){
                $q->with('topic','dcSentence.directed')->get();
            } ])->findOrFail($id);
        }else{
            $collection = DataCollection::with(['taskAssign.group', 'language', 'district', 'speaker','collector', 'dcSpontaneous'=>function($q){
                $q->with('spontaneous')->get();
            } ])->findOrFail($id);
        }

        return  view('admin.data_collection.viewCollection', compact('collection'));
    }


    public function activity(Request $request){

        if ($request->ajax()) {
            $data = Activity::with('causer')->latest()->limit(5000)->get();
            return Datatables::of($data)->addIndexColumn()
               ->addColumn('created_at', function ($activity) {
                   return $activity->created_at->diffForHumans();
               })
                ->rawColumns(['created_at'])
                ->make(true);
        }
        return view('activity');
    }

    public function laravelLog(){
         //file_put_contents(storage_path('logs/laravel.log'),'');
         $logs = file_get_contents(storage_path('logs/laravel.log'));
         dd($logs);

        return view('laravelLog', compact('logs'));
    }


    public function wordTimeCorrection(){


       /* $wordTimeCorrection = DCWordCollection::select('id', 'audio_duration')
            ->where('created_by', 38)
            ->where('audio', 'like', '%trim_%')
            ->where('audio_blob', 'like', '%data:audio/mp3;base64%')
            ->get();

        foreach ($wordTimeCorrection as $word){
            $audio_duration = $word->audio_duration/60;
            dcWordCollection::where('id', $word->id)->update(['audio_duration' => $audio_duration]);
        }*/

        // how to table empty uing thinker


        return redirect()->route('admin.dashboard')->with('success', __('messages.সফলভাবে করা হয়েছে।'));
    }


    public function removeBlob(){

        $dcWordCollections = DCWordCollection::whereNotNull('updated_at')->get();
        foreach ($dcWordCollections as $dcWordCollection){
            DCWordCollection::where('id', $dcWordCollection->id)
                ->whereNotNull('updated_at')
                ->update(['audio_blob' => null]);
        }
        $dcWordCollectionsTwo = DCWordCollection::whereNull('updated_at')->get();
        foreach ($dcWordCollectionsTwo as $dcWordCollectionItem){
            DCWordCollection::where('id', $dcWordCollectionItem->id)
                ->whereNull('updated_at')
                ->update(['audio_blob' => null, 'updated_at' => null]);
        }


        $dcDirectedSentence = DCDirectedSentence::whereNotNull('updated_at')->get();
        foreach ($dcDirectedSentence as $sentence){
            DCDirectedSentence::where('id', $sentence->id)
                ->whereNotNull('updated_at')
                ->update(['audio_blob' => null]);
        }

        $dcDirectedSentenceTwo = DCDirectedSentence::whereNull('updated_at')->get();
        foreach ($dcDirectedSentenceTwo as $sentenceItem){
            DCDirectedSentence::where('id', $sentenceItem->id)
                ->whereNull('updated_at')
                ->update(['audio_blob' => null, 'updated_at' => null]);
        }

        $dcSpontaneous = DCSpontaneous::whereNotNull('updated_at')->get();
        foreach ($dcSpontaneous as $spontaneous){
            DCSpontaneous::where('id', $spontaneous->id)
                ->whereNotNull('updated_at')
                ->update(['audio_blob' => null]);
        }
        $dcSpontaneousTwo = DCSpontaneous::whereNull('updated_at')->get();
        foreach ($dcSpontaneousTwo as $spontaneousItem){
            DCSpontaneous::where('id', $spontaneousItem->id)
                ->whereNull('updated_at')
                ->update(['audio_blob' => null, 'updated_at' => null]);
        }

        return redirect()->route('admin.dashboard')->with('success', __('সফলভাবে রিমুভ করা হয়েছে।'));
    }



    public function collectionTime(){
        $user =Auth::user()->hasRole('Data Collector');
        if ($user){
            $directedAudioTimes=DB::table('d_c_directed_sentences')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'), 'data_collections.language_id', 'languages.name as language','data_collections.collector_id', 'users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
                ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id', 'data_collections.collector_id')
                ->where('data_collections.collector_id', auth()->id())
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($directedAudioTimes as $directedAudioTime){
                $directedAudioTime->sum_of_length = $directedAudioTime->sum_of_length * 60;
            }

            $wordAudioTimes=DB::table('d_c_word_collections')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'),'data_collections.language_id',  'languages.name as language', 'data_collections.collector_id','users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
                ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id', 'data_collections.collector_id')
                ->where('data_collections.collector_id', auth()->id())
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($wordAudioTimes as $wordAudioTime){
                $wordAudioTime->sum_of_length = $wordAudioTime->sum_of_length * 60;
            }


            $spontAudioTimes=DB::table('d_c_spontaneouses')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'), 'data_collections.language_id',  'languages.name as language', 'data_collections.collector_id','users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id','data_collections.collector_id')
                ->where('data_collections.collector_id', auth()->id())
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($spontAudioTimes as $spontAudioTime){
                $spontAudioTime->sum_of_length = $spontAudioTime->sum_of_length * 60;
            }

        }else{
            $directedAudioTimes=DB::table('d_c_directed_sentences')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'), 'data_collections.language_id', 'languages.name as language','data_collections.collector_id', 'users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
                ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id', 'data_collections.collector_id')
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($directedAudioTimes as $directedAudioTime){
                $directedAudioTime->sum_of_length = $directedAudioTime->sum_of_length * 60;
            }

            $wordAudioTimes=DB::table('d_c_word_collections')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'),'data_collections.language_id',  'languages.name as language', 'data_collections.collector_id','users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
                ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id', 'data_collections.collector_id')
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($wordAudioTimes as $wordAudioTime){
                $wordAudioTime->sum_of_length = $wordAudioTime->sum_of_length * 60;
            }


            $spontAudioTimes=DB::table('d_c_spontaneouses')
                ->select(DB::raw('SUM(audio_duration) AS sum_of_length'), 'data_collections.language_id',  'languages.name as language', 'data_collections.collector_id','users.name as collector',
                    'data_collections.type_id as type', 'data_collections.task_assign_id')
                ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->leftjoin('users', 'data_collections.collector_id', '=', 'users.id')
                ->groupBy('data_collections.language_id','data_collections.collector_id')
                ->get()->toArray();
            // sum_of_length minutes to second convert
            foreach ($spontAudioTimes as $spontAudioTime){
                $spontAudioTime->sum_of_length = $spontAudioTime->sum_of_length * 60;
            }
        }



        $collectionTimes = array_merge($directedAudioTimes, $spontAudioTimes, $wordAudioTimes);
        $collectionTimes = collect($collectionTimes)->groupBy(['task_assign_id', 'type'/*, 'language_id'*/])->toArray();
        /*$collectionTimes = collect($collectionTimes)->map(function ($item, $key) {
            return  collect($item)->groupBy('type')->toArray();
        })->toArray();*/

//        dd($collectionTimes);


        return view('admin.data_collection_log.collection-time', compact('collectionTimes'));
    }



    public function languageByTask($languageID){

        $languageByTasks = TaskAssign::with('directedTaskSentence', 'wordTaskSentence','spontaneousTaskTrims','validatedSpontaneousTrims', 'approvedSpontaneousTrims')
            ->withCount('directedCollections','wordCollections', 'spontaneousCollections',
            'directedTasks', 'WordTasks', 'spontaneousTasks', 'validatedDirected','validatedWord','approveddDirected', 'approvedWord')
            ->where('language_id', $languageID)->get();

        $directedTopicCount=$this->directedTopicCount($languageID);
        $wordTopicCount=$this->wordTopicCount($languageID);
        $totalDirectedAudio=$this->totalDirectedAudio($languageID);
        $totalWordAudio=$this->totalWordAudio($languageID);
        $totalSpontAudio=$this->totalSpontaneousAudio($languageID);
        //$totalSpontTrims=$this->totalSpontaneousTrims($languageID);
        $totalDirectedValidate=$this->totalDirectedValidate($languageID);
        $totalWordValidate=$this->totalWordValidate($languageID);
        //$totalSpontValidate=$this->totalSpontaneousValidate($languageID);
        $totalDirectedApprove=$this->totalDirectedApprove($languageID);
        $totalWordApprove=$this->totalWordApprove($languageID);
        //$totalSpontApprove=$this->totalSpontaneousApprove($languageID);


        $directeds_count = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->directedTaskSentence as $directedTaskSentence){
                $directeds_count += $directedTaskSentence->topic->directeds_count;
            }
        }

        $words_count = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->wordTaskSentence as $wordTaskSentence){
                $words_count += $wordTaskSentence->topicWord->words_count;
            }
        }

        $trim_count = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->spontaneousTaskTrims as $spontaneousTrim){
                $trim_count += $spontaneousTrim->trim_count;
            }
        }

        $validatedCount = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->validatedSpontaneousTrims as $validatedSpontaneousTrim){
                $validatedCount += $validatedSpontaneousTrim->validated_count;
            }
        }
        $approvedCount = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->approvedSpontaneousTrims as $approvedSpontaneousTrim){
                $approvedCount += $approvedSpontaneousTrim->approved_count;
            }
        }
        $languageByTasks=[
            'directedTasksCount' => $languageByTasks->sum('directed_tasks_count'),
            'directedsCount' => $directeds_count,
            'wordTasksCount' => $languageByTasks->sum('word_tasks_count'),
            'wordsCount' => $words_count,
            'spontaneousTasksCount' => $languageByTasks->sum('spontaneous_tasks_count'),
            'directedCollections' => $languageByTasks->sum('directed_collections_count'),
            'dcTopicCollectionCount' => $directedTopicCount,
            'wordTopicCollectionCount' => $wordTopicCount,
            'wordCollections' => $languageByTasks->sum('word_collections_count'),
            'spontaneousCollections' => $languageByTasks->sum('spontaneous_collections_count'),
            'validatedDirected' => $languageByTasks->sum('validated_directed_count'),
            'validatedWord' => $languageByTasks->sum('validated_word_count'),
            'validatedSpontaneous' => $validatedCount,
            'approveddDirected' => $languageByTasks->sum('approvedd_directed_count'),
            'approvedWord' => $languageByTasks->sum('approved_word_count'),
            'approvedSpontaneous' => $approvedCount,
            'language' => $languageByTasks[0]->language->name,
            'languageID' => $languageByTasks[0]->language->id,
            'trim_count' => $trim_count,
            'directedAudios' => $totalDirectedAudio->sum('sum_of_directed'),
            'wordAudios' => $totalWordAudio->sum('sum_of_word'),
            'spontaneousAudios' => $totalSpontAudio->sum('sum_of_spontaneous'),
            //'spontaneousTrims' => $totalSpontTrims->sum('sum_of_length'),
            'totalDirectedValidate' => $totalDirectedValidate->sum('sum_of_length'),
            'totalWordValidate' => $totalWordValidate->sum('sum_of_length'),
            //'totalSpontValidate' => $totalSpontValidate->sum('sum_of_length'),
            'totalDirectedApprove' =>$totalDirectedApprove->sum('sum_of_length'),
            'totalWordApprove' => $totalWordApprove->sum('sum_of_length'),
            //'totalSpontApprove' => $totalSpontApprove->sum('sum_of_length'),
        ];
       /* dd($languageByTasks);
        dd($languageByTasks->toArray());*/
        return view('admin.language_assign.languageByTask', compact('languageByTasks'));
    }

    public function getAudioDuration($audioFile){
        $media = FFMpeg::openUrl($audioFile);
        return $media->getDurationInSeconds();
        /*$durationInMinutes = $durationInSeconds / 60;
        return $durationInMinutes;*/
    }

    private function directedTopicCount($languageID){
       return  DB::table('d_c_directeds')
            ->select('data_collections.id', 'topic_id as topic',
                'data_collections.type_id as type', 'data_collections.task_assign_id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('topic_id','data_collections.task_assign_id')
            ->get()->count();
    }

    private function wordTopicCount($languageID){
        return DB::table('d_c_words')
            ->select('data_collections.id', 'topic_word_id as topic',
                'data_collections.type_id as type', 'data_collections.task_assign_id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('topic_word_id','data_collections.task_assign_id')
            ->get()->count();
    }


    private function totalDirectedAudio($languageID){
        return  DB::table('d_c_directed_sentences')
            ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_directed'), 'languages.name')
            ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('data_collections.language_id')
            ->get();
    }

    private function totalWordAudio($languageID){
        return DB::table('d_c_word_collections')
            ->select( DB::raw('SUM(audio_duration)*60 AS sum_of_word'), 'languages.name')
            ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('data_collections.language_id')
            ->get();
    }

    private function totalSpontaneousAudio($languageID){
        return DB::table('d_c_spontaneouses')
            ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_spontaneous'), 'languages.name', 'data_collections.type_id')
            ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->get();
    }

    private function totalSpontaneousTrims($languageID){
        $totalSpontTrims=DB::table('audio_trims')
            ->select('audio_trims.audio', 'languages.name')
            ->leftjoin('d_c_spontaneouses', 'audio_trims.d_c_spontaneouses_id', '=', 'd_c_spontaneouses.id')
            ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->get();
        foreach($totalSpontTrims as $key=>$audio) {
            $totalSpontTrims[$key]->sum_of_length = $this->getAudioDuration($audio->audio);
        }
        return $totalSpontTrims;
    }

    private function totalDirectedValidate($languageID){
        return DB::table('d_c_directed_sentences')
            ->select( 'languages.name',DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
            ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->whereNotNull('d_c_directed_sentences.validator_id')
            ->where('data_collections.language_id', $languageID)
            ->get();
    }
    private function totalWordValidate($languageID){
        return DB::table('d_c_word_collections')
            ->select('languages.name',DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
            ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->whereNotNull('d_c_word_collections.validator_id')
            ->where('data_collections.language_id', $languageID)
            ->get();
    }

    private function totalSpontaneousValidate($languageID){
        $totalSpontValidate= DB::table('audio_trims')
            ->select('audio_trims.audio', 'languages.name')
            ->leftjoin('d_c_spontaneouses', 'audio_trims.d_c_spontaneouses_id', '=', 'd_c_spontaneouses.id')
            ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->whereNotNull('audio_trims.validator_id')
            ->where('data_collections.language_id', $languageID)
            ->get();
        foreach($totalSpontValidate as $key=>$audio) {
            $totalSpontValidate[$key]->sum_of_length = $this->getAudioDuration($audio->audio);
        }
        return $totalSpontValidate;
    }

    private function totalDirectedApprove($languageID){
        return DB::table('d_c_directed_sentences')
            ->select('languages.name',DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
            ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('d_c_directed_sentences.status',1)
            ->where('data_collections.language_id', $languageID)
            ->get();
    }

    private function totalWordApprove($languageID){
        return DB::table('d_c_word_collections')
            ->select('languages.name',DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
            ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('d_c_word_collections.status',1)
            ->where('data_collections.language_id', $languageID)
            ->get();
    }

    private function totalSpontaneousApprove($languageID){
        $totalSpontApprove=DB::table('audio_trims')
            ->select('audio_trims.audio', 'languages.name')
            ->leftjoin('d_c_spontaneouses', 'audio_trims.d_c_spontaneouses_id', '=', 'd_c_spontaneouses.id')
            ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('audio_trims.status',3)
            ->where('data_collections.language_id', $languageID)
            ->get();

        foreach($totalSpontApprove as $key=>$audio) {
            $totalSpontApprove[$key]->sum_of_length = $this->getAudioDuration($audio->audio);
        }
        return $totalSpontApprove;
    }




}

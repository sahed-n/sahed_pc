<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Directed;
use App\Models\Spontaneous;
use App\Models\Word;
use Illuminate\Http\Request;

class DataSetController extends Controller
{

    public function directedDataSet(){

         $directedTopicsBySentences=Directed::with('topics:id,name')
            ->orderBy('topic_id', 'asc')
            ->get();
        return view('admin.data_set.directed-list', compact('directedTopicsBySentences'));
    }


    public function wordDataSet (){

        $wordTopicsBySentences=Word::with('topicsWord:id,name')
            ->orderBy('topic_word_id', 'asc')
            ->get();

        return view('admin.data_set.word-list', compact('wordTopicsBySentences'));
    }

    public function spontaneousDataSet (){

        $spontaneousTopics=Spontaneous::orderBy('id', 'asc')->get();

        return view('admin.data_set.spontaneous-list', compact('spontaneousTopics'));
    }
}

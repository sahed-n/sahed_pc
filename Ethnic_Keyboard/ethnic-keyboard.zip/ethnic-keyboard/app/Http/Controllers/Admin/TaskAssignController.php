<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTaskAssignRequest;
use App\Http\Requests\UpdateTaskAssignRequest;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\DCWord;
use App\Models\DCWordCollection;
use App\Models\Directed;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DirectedTaskAssign;
use App\Models\WordTaskAssign;
use App\Models\District;
use App\Models\Group;
use App\Models\Language;
use App\Models\SpontaneousTaskAssign;
use App\Models\SubLanguage;
use App\Models\TaskAssign;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\User;
use App\Models\Village;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use File;
use Illuminate\Support\Facades\Validator;

class TaskAssignController extends Controller
{

    public function taskAssignListByLanguage(){
        if(Auth::user()->hasRole(['Linguist','Validator' ,'Admin'])){
           /*  return */$taskAssignListByLanguages = TaskAssign::with(['language','district'])
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->get();

        }elseif(Auth::user()->hasRole(['Data Collector','Manager' /* ,'Admin'*/])){
           /* return */$taskAssignListByLanguages= TaskAssign::with(['language','district','directedTasks.topic','spontaneousTasks.spontaneous'])
                // ->where('user_id', auth()->id() )
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->get();
                // ->withCount('directedTasks')
                // ->count();
        }


        return view('admin.task_assign.taskAssignList', compact('taskAssignListByLanguages'));
    }

    public function index(){
         $taskAssigns= TaskAssign::with( 'topicWords','topics', 'spontaneouses')
            ->latest()
            ->get();

        return view('admin.task_assign.index', compact('taskAssigns'));
    }


    public function create()
    {
//        $districts = District::pluck('name', 'id');
        $groups = Group::pluck('name', 'id');
        $languages = Language::pluck('name', 'id');
        $collectors= User::where('user_type', 4)->pluck('name', 'id');

        return view('admin.task_assign.create', compact('groups', 'languages', 'collectors'));
    }


    public function store(StoreTaskAssignRequest $request)
    {

        DB::beginTransaction();
        try {

            foreach ($request->input('user_id') as $a =>$i){

                $taskAssign = new TaskAssign();
                $taskAssign->user_id = $i;
                $taskAssign->group_id =$request->group_id;
                $taskAssign->language_id =$request->language_id;
                $taskAssign->sub_language_id =$request->sub_language_id;
                $taskAssign->district_id =$request->district;
                $taskAssign->upazila_id =$request->upazila;
                $taskAssign->union_id =$request->union;
                $taskAssign->village =$request->village;
                $taskAssign->start_date =$request->start_date;
                $taskAssign->end_date =$request->end_date;
                $taskAssign->created_by =auth()->id();
                $taskAssign->updated_by =0;
                $taskAssign->save();


                foreach ($request->input('topic_word_id'.$i) as $k=> $topicWordItem){
                    $word = new WordTaskAssign();
                    $word->task_assign_id = $taskAssign->id;
                    $word->topic_word_id= $topicWordItem;
                    $word->user_id= $i;
                    $word->save();
                }
                foreach ($request->input('topic_id'.$i) as $key2=> $topicItem){
                    $directed = new DirectedTaskAssign();
                    $directed->task_assign_id = $taskAssign->id;
                    $directed->topic_id= $topicItem;
                    $directed->user_id= $i;
                    $directed->save();
                }
                foreach ($request->input('spontaneous_id'.$i) as $key=> $spontaneousItem){
                    $spontaneous = new SpontaneousTaskAssign();
                    $spontaneous->task_assign_id = $taskAssign->id;
                    $spontaneous->spontaneous_id= $spontaneousItem;
                    $spontaneous->user_id= $i;
                    $spontaneous->save();
                }

                // // Store User Token
                // $user = User::find($i);
                // $user->fcm_token = $request->user_token;
                // $user->save();
                // $this->Notification($n_title, $n_body);
                // Notification message
                $n_title = 'New Task Assign';
                $n_body  = 'You are assign for a new group task';
                Notification::create([
                    'user_id'     => $i,
                    'title'       => $n_title,
                    'body'        => $n_body,
                    'status'      => 0,
                    'created_by'  => Auth::user()->id
                ]);

            }

            DB::commit();
            return redirect()->route('admin.task_assigns.index')
                ->with('success', __('messages.গ্রুপ টাস্ক অ্যাসাইন সফলভাবে তৈরি করা হয়েছে।'));

        } catch (\Exception $e) {
            DB::rollBack();
           // throw new \Exception("error" .$e->getMessage());
            return redirect()->back()->with('error', 'নির্দেশিত, শব্দ ও স্বতঃস্ফূর্ত টাস্ক নির্বাচন করা হয়নি।'.$e->getMessage());
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        $groupTaskAssign = TaskAssign::findOrFail($id);
        $groups = DB::table('groups')
            ->join('group_collectors', 'groups.id', '=', 'group_collectors.group_id')
            ->where('group_id', $groupTaskAssign->group_id)
            ->select('groups.*')
            ->pluck('name', 'id');

        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $groupTaskAssign->group_id)
            ->where('user_id', $groupTaskAssign->user_id)
            ->select('users.*')
            ->pluck('name', 'id');

        $languages = Language::pluck('name', 'id');
        $subLanguages = SubLanguage::where([['language_id', '=', $groupTaskAssign->language_id],])->pluck('sub_name', 'id');

        $districts = DB::table('districts')
            ->join('language_districts', 'districts.id', '=', 'language_districts.district_id')
            ->where('language_id', $groupTaskAssign->language_id)
            ->select('districts.*')
            ->pluck('name', 'id');
        $upazilas = Upazila::where([['district_id', '=', $groupTaskAssign->district_id],])->pluck('name', 'id');
        $unions = Union::where([['upazila_id', '=', $groupTaskAssign->upazila_id],])->pluck('name', 'id');

        $wordSelected = WordTaskAssign::where([['task_assign_id', '=', $groupTaskAssign->id]])->get();
        $wordSelected= $wordSelected->pluck('topicWord.id','topic_word_id')->toArray();
        $directedSelected = DirectedTaskAssign::where([['task_assign_id', '=', $groupTaskAssign->id],])->get();
        $directedSelected = $directedSelected->pluck('topic.id','topic_id')->toArray();
        $spontaneousSelected = SpontaneousTaskAssign::where([['task_assign_id', '=', $groupTaskAssign->id],])->get();
        $spontaneousSelected = $spontaneousSelected->pluck('spontaneous.id','spontaneous_id')->toArray();

        $words= DB::table('topic_words')
            ->join('word_languages', 'topic_words.id', '=', 'word_languages.topic_word_id')
            ->where('language_id', $groupTaskAssign->language_id)
            ->select('topic_words.*')
            ->pluck('name', 'id');
        $directeds= DB::table('topics')
            ->join('directed_languages', 'topics.id', '=', 'directed_languages.topic_id')
            ->where('language_id', $groupTaskAssign->language_id)
            ->select('topics.*')
            ->pluck('name', 'id');
        $spontaneouses= DB::table('spontaneouses')
            ->join('spontaneous_languages', 'spontaneouses.id', '=', 'spontaneous_languages.spontaneous_id')
            ->where('language_id', $groupTaskAssign->language_id)
            ->select('spontaneouses.*')
            ->pluck('word', 'id');


        return view('admin.task_assign.edit',
            compact('groupTaskAssign', 'collectors','districts', 'groups', 'languages',
                'upazilas', 'unions', 'directeds','spontaneouses', 'subLanguages', 'words','directedSelected','spontaneousSelected','wordSelected'));
    }


    public function update(UpdateTaskAssignRequest $request, $id)
    {
        DB::beginTransaction();
        try {

            $groupTaskAssign = TaskAssign::findOrFail($id);
            $groupTaskAssign->user_id =$request->user_id;
            $groupTaskAssign->group_id =$request->group_id;
            $groupTaskAssign->language_id =$request->language_id;
            $groupTaskAssign->sub_language_id =$request->sub_language_id;
            $groupTaskAssign->district_id =$request->district;
            $groupTaskAssign->upazila_id =$request->upazila;
            $groupTaskAssign->union_id =$request->union;
            $groupTaskAssign->village =$request->village;
            $groupTaskAssign->start_date =$request->start_date;
            $groupTaskAssign->end_date =$request->end_date;
            $groupTaskAssign->updated_by =auth()->id();
            $groupTaskAssign->update();

            $wordArray =[];
            $directedArray =[];
            $spontaneousArray =[];

            $wordSingleTaskAssignIDs = WordTaskAssign::where('task_assign_id',$groupTaskAssign->id)->get();
            if ($wordSingleTaskAssignIDs){
                foreach ($wordSingleTaskAssignIDs as $data){
                    $wordArray[]= $data->topic_word_id;
                }
            }


            $directedSingleTaskAssignIDs = DirectedTaskAssign::where('task_assign_id',$groupTaskAssign->id)->get();
            if ($directedSingleTaskAssignIDs){
                foreach ($directedSingleTaskAssignIDs as $data){
                    $directedArray[]= $data->topic_id;
                }
            }

            $SpontaneousSingleTaskAssignIDs = SpontaneousTaskAssign::where('task_assign_id',$groupTaskAssign->id)->get();
            if ($SpontaneousSingleTaskAssignIDs){
                foreach ($SpontaneousSingleTaskAssignIDs as $value){
                    $spontaneousArray[]= $value->spontaneous_id;
                }
            }
            foreach ($request->input('topic_word_id') as $k=> $wordItem){
                $wordData = array(
                    'task_assign_id'=>$groupTaskAssign->id,
                    'topic_word_id'=>$wordItem,
                    'user_id'=>$request->user_id,
                );
                WordTaskAssign::updateOrCreate([
                    'task_assign_id'=>$groupTaskAssign->id,
                    'topic_word_id'=>$wordItem,
                    'user_id'=>$request->user_id,
                ],$wordData);
            }

            foreach ($request->input('topic_id') as $k=> $topicItem){
                $topicWordData = array(
                    'task_assign_id'=>$groupTaskAssign->id,
                    'topic_id'=>$topicItem,
                    'user_id'=>$request->user_id,
                );
                DirectedTaskAssign::updateOrCreate([
                    'task_assign_id'=>$groupTaskAssign->id,
                    'topic_id'=>$topicItem,
                    'user_id'=>$request->user_id,
                ],$topicWordData);
            }

            foreach ($request->input('spontaneous_id') as $key=> $spontaneousItem){
                $spontaneousData = array(
                    'task_assign_id'=>$groupTaskAssign->id,
                    'spontaneous_id'=>$spontaneousItem,
                    'user_id'=>$request->user_id,
                );
                SpontaneousTaskAssign::updateOrCreate([
                    'task_assign_id'=>$groupTaskAssign->id,
                    'spontaneous_id'=>$spontaneousItem,
                    'user_id'=>$request->user_id,
                ],$spontaneousData);
            }

            foreach ($wordArray as $wordTopic){
                if (!in_array($wordTopic, $request->topic_id)){
                    WordTaskAssign::where('task_assign_id',$groupTaskAssign->id)->where('topic_word_id', $wordTopic)->delete();
                }
            }

            foreach ($directedArray as $directedTopic){
                if (!in_array($directedTopic, $request->topic_id)){
                    DirectedTaskAssign::where('task_assign_id',$groupTaskAssign->id)->where('topic_id', $directedTopic)->delete();
                }
            }
            foreach ($spontaneousArray as $spontaneous){
                if (!in_array($spontaneous, $request->spontaneous_id)){
                    SpontaneousTaskAssign::where('task_assign_id',$groupTaskAssign->id)->where('spontaneous_id', $spontaneous)->delete();
                }
            }

            DB::commit();
            return redirect()->back()->with('success', __('টাস্ক অ্যাসাইন সফলভাবে আপডেট করা হয়েছে।'));
        } catch (\Exception $th) {
            DB::rollback();
            return redirect()->back()->with('error', __('Something went wrong').' '.$th->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $taskAssign = TaskAssign::findOrFail($id);

        $dataCollections =DataCollection::where('task_assign_id', $id)->get();
        if (!$dataCollections->isEmpty()){
            foreach ($dataCollections as $dataCollection){
                $dcDirected = DCDirected::where('data_collection_id', $dataCollection->id)->first();
                $dcWord = DCWord::where('data_collection_id', $dataCollection->id)->first();

                if (!empty($dcDirected)){
                    $dcDirectedSentence = DCDirectedSentence::where('d_c_directed_id', $dcDirected->id)->first();
                    $audioPath = public_path($dcDirectedSentence->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $dcDirectedSentence->delete();
                    $dcDirected->delete();
                    $dataCollection->delete();

                }elseif (!empty($dcWord)){
                    $dcWordSentence = DCWordCollection::where('d_c_word_id', $dcWord->id)->first();

                    $audioPath = public_path($dcWordSentence->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $dcWordSentence->delete();
                    $dcWord->delete();
                    $dataCollection->delete();
                }else{
                    $dcSpontaneous= DCSpontaneous::where('data_collection_id', $dataCollection->id)->first();
                    $audioPath = public_path($dcSpontaneous->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $autdioTrims= AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneous->id)->get();
                    foreach ($autdioTrims as $trimID){
                        $audioPathTrim = public_path($trimID->audio);
                        if(File::exists($audioPathTrim)) {
                            File::delete($audioPathTrim);
                        }
                        $trimID->delete();
                    }
                    $dcSpontaneous->delete();
                    $dataCollection->delete();
                }
            }
        }
        DirectedTaskAssign::where('task_assign_id', $id)->delete();
        SpontaneousTaskAssign::where('task_assign_id', $id )->delete();
        WordTaskAssign::where('task_assign_id', $id)->delete();
        $taskAssign->delete();

        return redirect()->back()->with('success', __('messages.টাস্ক অ্যাসাইন সফলভাবে মুছে ফেলা হয়েছে।'));
    }

    public function deleteCollection($taskAssignID){
        $dataCollections =DataCollection::where('task_assign_id', $taskAssignID)->get();
        if (!$dataCollections->isEmpty()){
            foreach ($dataCollections as $dataCollection){
                $dcDirected = DCDirected::where('data_collection_id', $dataCollection->id)->first();
                $dcWord = DCWord::where('data_collection_id', $dataCollection->id)->first();
                if (!empty($dcDirected)){
                    $dcDirectedSentence = DCDirectedSentence::where('d_c_directed_id', $dcDirected->id)->first();
                    $audioPath = public_path($dcDirectedSentence->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $dcDirectedSentence->delete();
                    $dcDirected->delete();
                    $dataCollection->delete();

                }elseif (!empty($dcWord)){
                    $dcWordSentence = DCWordCollection::where('d_c_word_id', $dcWord->id)->first();

                    $audioPath = public_path($dcWordSentence->audio);

                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $dcWordSentence->delete();
                    $dcWord->delete();
                    $dataCollection->delete();
                }else{
                    $dcSpontaneous= DCSpontaneous::where('data_collection_id', $dataCollection->id)->first();
                    $audioPath = public_path($dcSpontaneous->audio);
                    if(File::exists($audioPath)) {
                        File::delete($audioPath);
                    }
                    $autdioTrims= AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneous->id)->get();
                    foreach ($autdioTrims as $trimID){
                        $audioPathTrim = public_path($trimID->audio);
                        if(File::exists($audioPathTrim)) {
                            File::delete($audioPathTrim);
                        }
                        $trimID->delete();
                    }
                    $dcSpontaneous->delete();
                    $dataCollection->delete();
                }
            }
        }
        return redirect()->back()->with('success', __('সংগৃহীত ডাটা সফলভাবে মুছে ফেলা হয়েছে।'));
    }

    public function getCollector(Request $request){
        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $request->group_id)
            ->select('users.*')
            ->pluck('name', 'id');
//        return $collectors;
        return $data= view('admin.task_assign.renderGroup',compact('collectors'))->render();
    }

    public function getGroupByCollector(Request $request){
        /*return Group::with(['assign','member'=>function($a){$a->with(['collectors']);}])
         //->whereHas('group',function ($a)use ($request){};))
            ->findOrFail($request->group_id);*/

        $collectors= DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $request->group_id)
            ->select('users.*')
            ->pluck('name', 'id');
        return $data= view('admin.task_assign.renderCollectorWordDirectedSpont', compact('collectors'))->render();
    }

    public function getTaskUser(Request $request){
        $collectors = DB::table('users')
            ->join('group_collectors', 'users.id', '=', 'group_collectors.user_id')
            ->where('group_id', $request->group_id)
            ->select('users.*')
            ->pluck('name', 'id');
//        dd($collectors);
        return response()->json($collectors);
    }
    public function getWordTopic(Request $request){
        $topicWords= DB::table('topic_words')
            ->join('word_languages', 'topic_words.id', '=', 'word_languages.topic_word_id')
            ->where('language_id', $request->language_id)
            ->select('topic_words.*')
            ->pluck('name', 'id');
        return $data= view('admin.task_assign.render-word', compact('topicWords'))->render();
    }

    public function getDirectedTopic(Request $request){
        $directeds= DB::table('topics')
            ->join('directed_languages', 'topics.id', '=', 'directed_languages.topic_id')
            ->where('language_id', $request->language_id)
            ->select('topics.*')
            ->pluck('name', 'id');
        return $data= view('admin.task_assign.render-topic', compact('directeds'))->render();
    }

    public function getSpontaneous(Request $request){
        $spontaneouses= DB::table('spontaneouses')
            ->join('spontaneous_languages', 'spontaneouses.id', '=', 'spontaneous_languages.spontaneous_id')
            ->where('language_id', $request->language_id)
            ->select('spontaneouses.*')
            ->pluck('word', 'id');
        return $data= view('admin.task_assign.render-spontaneous', compact('spontaneouses'))->render();
    }

    public function getLanguageByWordDirectedSpont(Request $request){
        $topicWords= DB::table('topic_words')
            ->join('word_languages', 'topic_words.id', '=', 'word_languages.topic_word_id')
            ->where('language_id', $request->language_id)
            ->select('topic_words.*')
            ->pluck('name', 'id');
        $directeds= DB::table('topics')
            ->join('directed_languages', 'topics.id', '=', 'directed_languages.topic_id')
            ->where('language_id', $request->language_id)
            ->select('topics.*')
            ->pluck('name', 'id');
        $spontaneouses= DB::table('spontaneouses')
            ->join('spontaneous_languages', 'spontaneouses.id', '=', 'spontaneous_languages.spontaneous_id')
            ->where('language_id', $request->language_id)
            ->select('spontaneouses.*')
            ->pluck('word', 'id');
//        dd($topicWords->toArray(),$directeds->toArray(),$spontaneouses->toArray());
        return $data= view('admin.single_task_assign.render-word-directed-spont', compact('topicWords', 'directeds','spontaneouses'))->render();
    }


    public function getUpazila(Request $request){

        $upazilas = Upazila::where('district_id', $request->district_id)->pluck('name', 'id');

        return response()->json($upazilas);

    }


    public function getUnion(Request $request){

        $unions = Union::where('upazila_id', $request->upazila_id)->pluck('name', 'id');

        return response()->json($unions);

    }

    public function getVillage(Request $request){
        $villages= Village::where('union_id', $request->union_id)->pluck('name', 'id');

        return response()->json($villages);
    }


    public function getDirectedByLanguage(){

    }

    public function getWordTaskByLanguage($id){

        $wordTaskLanguages=WordTaskAssign::where('task_assign_id', $id)
         ->with('taskAssign.collections.dcWord.dcWordCollection.word.topicsWord' ,'taskAssign.wordTasks.topicWord')
         ->with(['taskAssign.wordTasks.topicWord'=>function ($query){
             $query->withCount('words');
         },])
          ->get();

          // sum of audio duration by task assign id
             $sumAudioDuration= DB::table('data_collections')
             ->join('d_c_words', 'data_collections.id', '=', 'd_c_words.data_collection_id')
             ->join('d_c_word_collections', 'd_c_words.id', '=', 'd_c_word_collections.d_c_word_id')
             ->where('data_collections.task_assign_id', $id)
             ->sum('d_c_word_collections.audio_duration');
 //        dd($sumAudioDuration);

             $total=$sumAudioDuration;

             $collected_time= number_format((float)$total, 2, '.', '');
             // minutes to second convert
                $collected_time= $collected_time*60;

            $taskAssignByLanguage= TaskAssign::with(['wordTasks.topicWord'=>function ($query){
                 $query->withCount('words');

             }, 'spontaneousTasks.spontaneous','language.subLanguages',
                 'district','upazila', 'union', 'collections.speaker', 'collections.dcSpontaneous.spontaneous','collections.dcWord.dcWordCollection.word.topicsWord',
                  'collections.dcDirected.dcSentence.directed.topics'])
                 ->where('user_id', auth()->id() )
                 ->withCount('wordTasks', 'directedTasks', 'spontaneousTasks')
                 ->latest()
                 ->get();

         $firstItem = Arr::first($wordTaskLanguages, function ($value, $key) {
             return $value;
         });

         return view('admin.task_assign.wordList', compact('wordTaskLanguages','taskAssignByLanguage','sumAudioDuration','collected_time', 'firstItem'));
     }

    public function getDirectedTaskByLanguage($id){

       $directedTaskLanguages=DirectedTaskAssign::where('task_assign_id', $id)
        ->with('taskAssign.collections.dcDirected.dcSentence.directed.topics' ,'taskAssign.directedTasks.topic')
        ->with(['taskAssign.directedTasks.topic'=>function ($query){
            $query->withCount('directeds');
        },])
           /* ->with(['taskAssign.collections'=>function($q){
                $q->with('dcDirected', function ($q){
                    $q->withSum('dcSentence', 'audio_duration');
                });
            }])*/

         ->get();

         // sum of audio duration by task assign id
            $sumAudioDuration= DB::table('data_collections')
            ->join('d_c_directeds', 'data_collections.id', '=', 'd_c_directeds.data_collection_id')
            ->join('d_c_directed_sentences', 'd_c_directeds.id', '=', 'd_c_directed_sentences.d_c_directed_id')
            ->where('data_collections.task_assign_id', $id)
            ->sum('d_c_directed_sentences.audio_duration');
//        dd($sumAudioDuration);
            $sumSpontTrimAudioDuration= DB::table('data_collections')
            ->join('d_c_spontaneouses', 'data_collections.id', '=', 'd_c_spontaneouses.data_collection_id')
            // ->join('audio_trims', 'd_c_spontaneouses.id', '=', 'audio_trims.d_c_spontaneouses_id')
            ->where('data_collections.task_assign_id', $id)
            ->sum('d_c_spontaneouses.audio_duration');
            $total=$sumAudioDuration+$sumSpontTrimAudioDuration;

            $collected_time= number_format((float)$sumAudioDuration, 2, '.', '');
            $collected_time= $collected_time*60;


            // $collected_time= number_format((float)$total, 2, '.', '');
           $taskAssignByLanguage= TaskAssign::with(['directedTasks.topic'=>function ($query){
                $query->withCount('directeds');

            }, 'spontaneousTasks.spontaneous','language.subLanguages',
                'district','upazila', 'union', 'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'])
                ->where('user_id', auth()->id() )
                ->withCount( 'directedTasks', 'spontaneousTasks')
                ->latest()
                ->get();

        $firstItem = Arr::first($directedTaskLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.task_assign.directedList', compact('directedTaskLanguages','taskAssignByLanguage','sumAudioDuration','collected_time', 'firstItem'));
    }

    public function getSpontaneousTaskByLanguage($id){
        $spontaneousTaskLanguages=SpontaneousTaskAssign::with('taskAssign.language', 'taskAssign.district', 'spontaneous')
        ->where('task_assign_id', $id)
        ->get();
        // sum of audio duration by task assign id
        $sumAudioDuration= DB::table('data_collections')
        ->join('d_c_directeds', 'data_collections.id', '=', 'd_c_directeds.data_collection_id')
        ->join('d_c_directed_sentences', 'd_c_directeds.id', '=', 'd_c_directed_sentences.d_c_directed_id')
        ->where('data_collections.task_assign_id', $id)
        ->sum('d_c_directed_sentences.audio_duration');
        //        dd($sumAudioDuration);
        $sumSpontTrimAudioDuration= DB::table('data_collections')
        ->join('d_c_spontaneouses', 'data_collections.id', '=', 'd_c_spontaneouses.data_collection_id')
        // ->join('audio_trims', 'd_c_spontaneouses.id', '=', 'audio_trims.d_c_spontaneouses_id')
        ->where('data_collections.task_assign_id', $id)
        ->sum('d_c_spontaneouses.audio_duration');

        $total=$sumAudioDuration+$sumSpontTrimAudioDuration;


        $collected_time= number_format((float) $sumSpontTrimAudioDuration, 2, '.', '');
        $collected_time= $collected_time*60;
        // $collected_time= number_format((float)$total, 2, '.', '');
        $firstItem = Arr::first($spontaneousTaskLanguages, function ($value, $key) {
            return $value;
        });

        return view('admin.task_assign.spontaneousList', compact('sumSpontTrimAudioDuration','spontaneousTaskLanguages','sumAudioDuration','collected_time','firstItem'));
    }

    public function getTaskAssignByLanguageToday(){
        $TaskAssignByLanguageToday= TaskAssign::with(['directedTasks.topic'=>function ($query){
            $query->withCount('directeds');
        },  'spontaneousTasks.spontaneous','language',
            'district','upazila', 'union', 'collections.speaker', 'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics'])
            ->withCount( 'directedTasks', 'spontaneousTasks')
            // ->groupBy('language_id')
            ->latest()
            // ->limit(6)
            ->get();

            return view('admin.task_assign.task_assign_by_language_list',compact('TaskAssignByLanguageToday'));
    }
}

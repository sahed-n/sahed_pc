<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Http\Requests\StoreAboutRequest;
use App\Http\Requests\UpdateAboutRequest;

class AboutController extends Controller
{

    public function create()
    {
        $about = About::first();
        return  view('admin.content.about', compact('about'));
    }


    public function store(StoreAboutRequest $request)
    {
        About::updateOrCreate(
            [ 'id'       => 1 ],
            ['description' => $request->description]
        );
        return redirect()->back()->with('success', 'About has been  updated successfully');
    }
}

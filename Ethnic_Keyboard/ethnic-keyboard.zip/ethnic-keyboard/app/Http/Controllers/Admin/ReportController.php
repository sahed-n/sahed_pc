<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DataCollection;
use App\Models\Language;
use Illuminate\Http\Request;

class ReportController extends Controller
{


    public function index(Request $request){
        $languages = DataCollection::with('language')->groupBy('language_id')->get();

        $selected_id = [];
        $selected_id['language_id'] = $request->language_id;

        return view('admin.report.index', compact('languages', 'selected_id'));
    }


    public function reportRender(Request $request){
        $language = $request->language_id;
        if (!$language) {
            return [];
        }

        $directedCollections=DataCollection::with('language:id,name', 'speaker:id,name', 'district:id,name','taskAssign:id',
            'dcDirected.topic', 'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous',
            'dcWord.topicWord' ,'dcWord.dcWordCollection.word', 'dcSpontaneous.trimAudios',)
            ->has('taskAssign')
            ->when($language, function ($query) use ($language) {
                return $query->whereHas('language', function ($query) use ($language) {
                    return $query->where('id', 'like', '%' . $language . '%');
                });
            })
            ->where('type_id', 1)
            ->orderBy('task_assign_id', 'asc')
            ->get();
        $wordCollections=DataCollection::with('language:id,name', 'speaker:id,name', 'district:id,name','taskAssign:id',
            'dcDirected.topic', 'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous',
            'dcWord.topicWord' ,'dcWord.dcWordCollection.word', 'dcSpontaneous.trimAudios',)
            ->has('taskAssign')
            ->when($language, function ($query) use ($language) {
                return $query->whereHas('language', function ($query) use ($language) {
                    return $query->where('id', 'like', '%' . $language . '%');
                });
            })
            ->where('type_id', 0)
            ->orderBy('task_assign_id', 'asc')
            ->get();

        $spontaneousCollections=DataCollection::with('language:id,name', 'speaker:id,name', 'district:id,name','taskAssign:id',
            'dcDirected.topic', 'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous',
            'dcWord.topicWord' ,'dcWord.dcWordCollection.word', 'dcSpontaneous.trimAudios',)
            ->has('taskAssign')
            ->when($language, function ($query) use ($language) {
                return $query->whereHas('language', function ($query) use ($language) {
                    return $query->where('id', 'like', '%' . $language . '%');
                });
            })
            ->where('type_id', 2)
            ->orderBy('task_assign_id', 'asc')
            ->get();
    $dataCollections = $directedCollections->merge($wordCollections)->merge($spontaneousCollections);

        $results=[];
        $n=1;
        if ($dataCollections->count() == 0){
            return $results=[];
        }

        foreach ($dataCollections as $key=> $dataCollection){
            $type='';
            if ($dataCollection->type_id == 0){
                $type = __('শব্দ ও ব্যাকরণ');
            }elseif ($dataCollection->type_id == 1){
                $type = __('নির্দেশিত');
            }elseif ($dataCollection->type_id == 2){
                $type = __('স্বতঃস্ফূর্ত');
            }

            $directedEnglish = null;
            if ($dataCollection->dcDirected && $dataCollection->dcDirected->dcSentence) {
                $directedEnglish = $dataCollection->dcDirected->dcSentence->english
                    ?? $dataCollection->dcDirected->dcSentence->directed->english;
            }

            $wordEnglish = null;
            if ($dataCollection->dcWord && $dataCollection->dcWord->dcWordCollection) {
                $wordEnglish = $dataCollection->dcWord->dcWordCollection->english
                    ?? $dataCollection->dcWord->dcWordCollection->word->english;
            }


            $results[]=[
                'serial_no'=>$n++,
                'district'=>$dataCollection->district->name,
                'speaker'=>$dataCollection->speaker->name,
                'type'=>$type,
                'collector' =>$dataCollection->collector->name,
                'topic' =>$dataCollection->dcDirected->topic->name??$dataCollection->dcWord->topicWord->name??$dataCollection->dcSpontaneous->spontaneous->word,
                'sentence' =>$dataCollection->dcDirected->dcSentence->directed->sentence??$dataCollection->dcWord->dcWordCollection->word->sentence??'',
                'ipa' =>$dataCollection->dcDirected->dcSentence->transcription??$dataCollection->dcWord->dcWordCollection->transcription??'',
                'english' =>$directedEnglish ??$wordEnglish??'',
                'task_assign_id' =>$dataCollection->task_assign_id,
                'topic_id' =>$dataCollection->dcDirected->topic_id??$dataCollection->dcWord->topic_word_id??$dataCollection->dcSpontaneous->spontaneous_id,
                'collection_id' =>$dataCollection->id,
            ];
        }
         $languageName = Language::where('id', $request->language_id)->first('name');

        return $data= view('admin.report.report-render', compact('results', 'languageName'))->render();
    }
}

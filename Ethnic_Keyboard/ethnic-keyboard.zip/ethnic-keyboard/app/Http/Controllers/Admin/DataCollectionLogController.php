<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DirectedTaskAssign;
use App\Models\TaskAssign;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

class DataCollectionLogController extends Controller
{
    public function index(Request $request)
    {
        $dataCollections=[];
        $collectionStatus=[];
        $taskBycollections = TaskAssign::with([
            'directedTasks.topic'=>function($q){
                $q->withCount('directeds');
            },
            'spontaneousTasks'=>function($q){
                $q->withCount('spontaneous');
            },
            'WordTasks.topicWord'=>function($q){
                $q->withCount('words');
            },
        ])
            ->latest()->get();

        foreach ($taskBycollections as $taskBycollection){
            foreach($taskBycollection->directedTasks as $directedTaskTopic){

                $directedApprovedCounts = DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                    ->where('type_id', 1)
                    ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                        $q->where('topic_id', $directedTaskTopic->topic_id);})
                    ->whereHas('dcDirected.dcSentence', function ($q1) {
                        $q1->where('status', 1);
                        $q1->whereNotNull('validator_id');})
                    ->orderBy('id', 'DESC')
                    ->count();
                if($directedApprovedCounts == $directedTaskTopic->topic->directeds_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                        ->where('type_id', 1)
                        ->with('dcDirected.topic:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                            $q->where('topic_id', $directedTaskTopic->topic_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Approved');
                }

                $directedValidatedCounts = DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                    ->where('type_id', 1)
                    ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                        $q->where('topic_id', $directedTaskTopic->topic_id);})
                    ->whereHas('dcDirected.dcSentence', function ($q1) {
                        $q1->whereNotNull('validator_id');})
                    ->orderBy('id', 'DESC')
                    ->count();
                if($directedValidatedCounts == $directedTaskTopic->topic->directeds_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                        ->where('type_id', 1)
                        ->with('dcDirected.topic:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                            $q->where('topic_id', $directedTaskTopic->topic_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Validate');
                }

                $directedCollectionCounts = DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                    ->where('type_id', 1)
                    ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                        $q->where('topic_id', $directedTaskTopic->topic_id);})
                    ->count();

                if($directedCollectionCounts == $directedTaskTopic->topic->directeds_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $directedTaskTopic->task_assign_id)
                        ->where('type_id', 1)
                        ->with('dcDirected.topic:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcDirected', function ($q) use($directedTaskTopic){
                            $q->where('topic_id', $directedTaskTopic->topic_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Collected');
                }
            }
            foreach($taskBycollection->WordTasks as $wordTaskTopic){

                $wordApprovedCounts = DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                    ->where('type_id', 0)
                    ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                        $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                    ->whereHas('dcWord.dcWordCollection', function ($q1) {
                        $q1->where('status', 1);
                        $q1->whereNotNull('validator_id');})
                    ->orderBy('id', 'DESC')
                    ->count();
                if($wordApprovedCounts == $wordTaskTopic->topicWord->words_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                        ->where('type_id', 0)
                        ->with('dcWord.topicWord:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                            $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Approved');
                }

                $wordValidatedCounts = DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                    ->where('type_id', 0)
                    ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                        $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                    ->whereHas('dcWord.dcWordCollection', function ($q1) {
                        $q1->whereNotNull('validator_id');})
                    ->orderBy('id', 'DESC')
                    ->count();
                if($wordValidatedCounts == $wordTaskTopic->topicWord->words_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                        ->where('type_id', 1)
                        ->with('dcWord.topicWord:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                            $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Validate');
                }

                $wordCollectionCounts = DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                    ->where('type_id', 0)
                    ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                        $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                    ->count();

                if($wordCollectionCounts == $wordTaskTopic->topicWord->words_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $wordTaskTopic->task_assign_id)
                        ->where('type_id', 0)
                        ->with('dcWord.topicWord:id,name','language:id,name', 'collector:id,name',)
                        ->whereHas('dcWord', function ($q) use($wordTaskTopic){
                            $q->where('topic_word_id', $wordTaskTopic->topic_word_id);})
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Collected');
                }
            }

            foreach ($taskBycollection->spontaneousTasks as $spontaneousTask){

                $spontaneousCollectionCounts = DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                    ->where('type_id', 2)
                    ->with('dcSpontaneous')
                    ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                        $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                    })
                    ->count();
                if($spontaneousCollectionCounts == $spontaneousTask->spontaneous_count){
                    $dataCollections[]= DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                        ->where('type_id', 2)
                        ->with('dcSpontaneous.spontaneous','language:id,name', 'collector:id,name')
                        ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                            $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                        })
                        ->orderBy('id', 'DESC')
                        ->first();
                    $collectionStatus[]=__('Collected');
                }

                $spontaneousCollection = DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                    ->where('type_id', 2)
//                    ->with('dcSpontaneous')
                    ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                        $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                    })
                    ->first();

                $dcSpontaneousID=$spontaneousCollection->dcSpontaneous->id ?? '';

                if ($dcSpontaneousID != ''){

                    $trimCount=AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneousID)
                        ->whereNotNull('created_at')
                        ->count();
                    $validatedCount=AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneousID)
                        ->whereNotNull('validator_id')
                        ->count();
                    $trimmedCount=AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneousID)
                        ->whereNotNull('updated_at')
                        ->count();
                    $approvedCount=AudioTrim::where('d_c_spontaneouses_id', $dcSpontaneousID)
                        ->where('status', 3)
                        ->whereNotNull('validator_id')
                        ->count();

                    if($trimCount>0){
                        if($trimCount == $approvedCount){
                            $dataCollections[]= DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                                ->where('type_id', 2)
                                ->with('dcSpontaneous.audioTrim','language:id,name', 'collector:id,name')
                                ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                                    $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                                })
                                ->orderBy('id', 'DESC')
                                ->first();
                            $collectionStatus[]=__('Approved');
                        }

                        if($trimCount == $validatedCount){
                            $dataCollections[]= DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                                ->where('type_id', 2)
                                ->with('dcSpontaneous.audioTrim','language:id,name', 'collector:id,name')
                                ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                                    $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                                })
                                ->orderBy('id', 'DESC')
                                ->first();
                            $collectionStatus[]=__('Validate');
                        }
                        if($trimCount == $trimmedCount){
                            $dataCollections[]= DataCollection::where('task_assign_id', $spontaneousTask->task_assign_id)
                                ->where('type_id', 2)
                                ->with('dcSpontaneous.audioTrim','language:id,name', 'collector:id,name')
                                ->whereHas('dcSpontaneous', function ($q) use($spontaneousTask){
                                    $q->where('spontaneous_id', $spontaneousTask->spontaneous_id);
                                })
                                ->orderBy('id', 'DESC')
                                ->first();
                            $collectionStatus[]=__('Trimmed');
                        }
                    }
                }
            }
        }
        return view('admin.data_collection_log.index', compact('dataCollections', 'collectionStatus'));
    }


    public function directedCollectionList($taskAssingId, $topicId){

        $query = DataCollection::query();
        $dataCollections=$query;
        $dataCollections=$dataCollections->where('task_assign_id', $taskAssingId)
            ->with('language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcDirected.dcSentence.directed', 'dcSpontaneous.spontaneous')
            ->whereHas('dcDirected', function ($query) use ($topicId) {
                $query->where('topic_id', $topicId);
            })
            ->latest()
            ->get();

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        return view('admin.data_collection_log.directed-collection-list', compact('dataCollections', 'firstItem'));
    }

    public function wordCollectionList($taskAssingId, $topicWordId){
        $query = DataCollection::query();
        $dataCollections=$query;
        $dataCollections=$dataCollections->where('task_assign_id', $taskAssingId)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcWord.dcWordCollection.word',
                'dcWord.dcWordCollection'=>function($q2){
                    $q2->select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                }])
            ->whereHas('dcWord', function ($query) use ($topicWordId) {
                $query->where('topic_word_id', $topicWordId);
            })
            ->latest()
            ->get();

        $firstItem = Arr::first($dataCollections, function ($value, $key) {
            return $value;
        });

        return view('admin.data_collection_log.word-collection-list', compact('dataCollections', 'firstItem'));
    }





    public function trimCollectionList($id){
        $dataCollection = DataCollection::with('language', 'district',
            'collector', 'speaker', 'taskAssign.group',
             'dcSpontaneous.spontaneous')
            ->findOrFail($id);

        /*$audioTrims=AudioTrim::where('d_c_spontaneouses_id', $id)
            ->orderBy('id', 'desc')
            ->get();*/

        return view('admin.data_collection_log.spontaneous-collection-list', compact('dataCollection'));
    }
}

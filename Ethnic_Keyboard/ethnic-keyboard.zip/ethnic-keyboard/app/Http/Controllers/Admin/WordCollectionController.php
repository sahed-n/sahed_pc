<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreWordRequest;
use App\Models\DirectedTaskAssign;
use Illuminate\Http\Request;
use App\Models\DataCollection;
use App\Models\DCWord;
use App\Models\DCWordCollection;
use App\Models\Word;
use App\Models\WordLanguage;
use App\Models\WordTaskAssign;
use App\Models\District;
use App\Models\Group;
use App\Models\GroupCollectors;
use App\Models\Speaker;
use App\Models\TaskAssign;
use App\Models\Union;
use App\Models\Upazila;
use App\Models\Village;
use App\Models\Language;
use Illuminate\Support\Facades\DB;
use Lame\Lame;
use Lame\Settings\Encoding\Preset;
use Lame\Settings\Settings;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use phpDocumentor\Reflection\Types\Null_;
use File;
use function PHPUnit\Framework\isEmpty;
use Illuminate\Support\Facades;
use Illuminate\Support\Facades\Validator;
use App\Models\Notification;
use Illuminate\Support\Facades\Redirect;

class WordCollectionController extends Controller
{
    public function getTopicWiseWordCollection($TaskID, $topicID){
        $wordLanguages =WordTaskAssign::where('user_id', auth()->id())
            ->where('task_assign_id', $TaskID)
            ->where('topic_word_id', $topicID)
            ->with('collector','taskAssign.speakers','taskAssign.language','taskAssign.district', 'topicWord.words')
            ->first();
        $districts = District::pluck('name', 'id');
        $word = $wordLanguages->topicWord->words->paginate(1);
        $languageBySpeakers= DB::table('language_districts')
            ->join('speakers', 'language_districts.id', '=', 'speakers.language_district_id')
            ->join('districts', 'language_districts.district_id', '=' , 'districts.id')
            ->where('language_id',$wordLanguages->taskAssign->language->id)
            ->select('language_districts.*','speakers.id as speaker_id','speakers.name as speaker_name','districts.name as district_name')
            ->get();
        $langSpeaker=$languageBySpeakers->pluck('id');
        $speakers = Speaker::whereIn('language_district_id', $langSpeaker)->with('district')->get();
        $speakers = $speakers->pluck('district.name');
        $data = [
            "task_assign_id" => $wordLanguages->task_assign_id,
            "district_id"    => $wordLanguages->taskAssign->district_id,
            "language_id"    => $wordLanguages->taskAssign->language_id,
        ];

        foreach($word as $wordItem){
            $wordID= $wordItem->id;
            $wordAudios=DataCollection::where('task_assign_id', $TaskID)
                ->where('type_id',0)
                ->with('speaker','dcWord.dcWordCollection.word')
                ->whereHas('dcWord', function($q) use($topicID){
                    $q->where('topic_word_id', $topicID);
                })
                ->whereHas('dcWord.dcWordCollection', function($q1) use($wordID){
                    $q1->where('word_id',$wordID);
                })
                ->get();
        }
        // $sentenceWiseList=$directedAudios->topic->collection->dcDirect->audio;
        $wordCollections=DataCollection::where('task_assign_id', $TaskID)
            ->where('type_id',0)
            ->with('dcWord.dcWordCollection.word')
            ->whereHas('dcWord', function($q) use($topicID){
                $q->where('topic_word_id', $topicID);
            })
            ->get();

        $wordList = $wordLanguages->topicWord->words;

        return view('admin.word_collection.word_collect',compact('wordList','districts','word','wordAudios','wordCollections',
            'wordLanguages', 'data','languageBySpeakers', 'speakers'));
    }

    protected function dcWord ($dataCollectionID, $topicID){
        $dcWord = new DCWord();
        $dcWord->data_collection_id = $dataCollectionID;
        $dcWord->topic_word_id = $topicID;
        $dcWord->created_by = Auth::id();
        $dcWord->updated_by = 0;
        $dcWord->save();
        return $dcWord;
    }
    protected function dcWordCollection ($request , $dcWord, $audioUrl, $word_id, $audio_file){

        $dcWordCollection = new DCWordCollection();
        $ffprobe    = \FFMpeg\FFProbe::create();
        if ($request->hasFile('audio')) {

            $dcWordCollection->audio = $request->hasFile('audio') ? $audioUrl : '';
            $dcWordCollection->audio_blob = null;
            $duration=$ffprobe->format($audioUrl)->get('duration');
            $length=$duration/60;
            $dcWordCollection->audio_duration  = $length;


        }elseif ($request->audio_blob == !null) {

            $dcWordCollection->audio      = $audioUrl;
            $dcWordCollection->audio_blob = null;
            $duration=$ffprobe->format($audioUrl)->get('duration');
            $length=$duration/60;
            $dcWordCollection->audio_duration  = $length;

        }
        $dcWordCollection->d_c_word_id  = $dcWord->id;
        $dcWordCollection->transcription  = $request->transcription;
        $dcWordCollection->modified_sentence  = $request->modified_sentence;
        $dcWordCollection->word_id   = $word_id;
        $dcWordCollection->topic_status   = 2;
        $dcWordCollection->approved_date   = Carbon::today()->toDateTimeString();
        $dcWordCollection->created_by   = Auth::id();
        $dcWordCollection->updated_by   = 0;
        $dcWordCollection->updated_at   = NULL;
        $dcWordCollection->save();
        return $dcWordCollection;
    }
    protected function dataCollection ($request, $speaker){

        $dataCollection = new DataCollection();
        $dataCollection->type_id = $request->type_id;
        $dataCollection->language_id = $request->language_id;
        $dataCollection->district_id = $request->district_id;
        $dataCollection->task_assign_id = $request->task_assign_id;
        $dataCollection->collector_id  = Auth::id();
        $dataCollection->speaker_id  = $speaker;
        $dataCollection->created_by  = Auth::id();
        $dataCollection->updated_by  = Auth::id();
        $dataCollection->save();
        return  $dataCollection;
    }

    public function submitWord(StoreWordRequest $request)
    {
        DB::beginTransaction();
        try {

            if ($request->dc_word_collection_id){
                $this->updateWordCollection( $request->type_id, $request->dc_word_collection_id, $request);
            }else{
                if ($request->audio_blob == !null) {

                    $decoded_file = $request->audio_blob;  //Decoded audio file
                    $audio_parts  = explode(";base64,", $decoded_file);
                    $audio_type   = explode("audio/wav", $audio_parts[0]);
                    $audio_base64 = base64_decode($audio_parts[1]);
                    $audio_directory = 'uploads/data-collections/';
                    $file_name_no_ext = 'record_'.time().'_'.unique_code(10);
                    $file_name = $file_name_no_ext.'.mp3';
                    $record = file_put_contents($audio_directory.$file_name, $audio_base64);
                    $wav_audio_url = $audio_directory.$file_name;
                    $audio_re_file = $request->audio_blob;
                    $audio_file = str_replace('data:audio/wav;base64,', '', $audio_re_file);
                    $newfile_name = 'record_'.time().'.mp3';
                    $audio_url = $audio_directory.$file_name_no_ext.'.mp3';

                    $dataCollection = $this->dataCollection($request, $request->speaker_id);

                    if ($request->type_id ==0) {
                        $dcWord = $this->dcWord($dataCollection->id,  $request->topic_word_id);
                        $this->dcWordCollection($request, $dcWord, $audio_url, $request->word_id, $audio_file);
                    }
                } else{

                    $dataCollection = $this->dataCollection($request, $request->speaker_id);

                    foreach ($request->file('audio') as $key => $item) {
                        $audio_src  = file_get_contents( $item);
                        $audio_file = base64_encode($audio_src);

                        if($request->hasFile('audio')){
                            $audioName  =   time().'_'.unique_code(10).'.'.$item->getClientOriginalExtension();
                            $directory  =   'uploads/data-collections/';
                            $audioUrl   =   $directory.$audioName;
                            $item->move($directory, $audioName);
                        }
                        if ($request->type_id == 0) {
                            $dcWord = $this->dcWord($dataCollection->id, $request->topic_word_id);
                            $this->dcWordCollection($request, $dcWord, $audioUrl, $request->word_id,$audio_file);

                        }
                    }

                }
            }

            //  }
            DB::commit();

            return response()->json([
                'msg' => 'আপনার ডাটাটি সফলভাবে সংগ্রহ হয়েছে।',
                'speaker_id'    => $request->speaker_id
            ]);

        }catch (\Exception $th) {
            DB::rollBack();
            //   throw new \Exception("error" .$th->getMessage());
            return response()->json(['msg' => 'কিছু ভুল হয়েছে। আবার চেষ্টা করুন।'.$th->getMessage()]);
        }


    }
    public function updateWordCollection($type, $id, $request)
    {
        if ($type == 0) {
            $word = DCWordCollection::find($id);
            $word->transcription = $request->transcription;
            $word->modified_sentence  = $request->modified_sentence;
            $word->updated_at= NULL;
            $word->save();


            if ($request->audio_blob == !null) {

                $audioPath = public_path($word->audio);
                if (File::exists($audioPath)) {
                    unlink($audioPath);
                }

                $decoded_file = $request->audio_blob;  //Decoded audio file
                $audio_parts  = explode(";base64,", $decoded_file);
                $audio_type   = explode("audio/wav", $audio_parts[0]);
                $audio_base64 = base64_decode($audio_parts[1]);
                $audio_directory = 'uploads/data-collections/';
                $file_name_no_ext = 'record_'.time().'_'.unique_code(10);
                $file_name = $file_name_no_ext.'.mp3';
                $record = file_put_contents($audio_directory.$file_name, $audio_base64);
                $wav_audio_url = $audio_directory.$file_name;
                $audio_re_file = $request->audio_blob;
                $audio_file = str_replace('data:audio/wav;base64,', '', $audio_re_file);
                $newfile_name = 'record_'.time().'.mp3';
                $audio_url = $audio_directory.$file_name_no_ext.'.mp3';

                $ffprobe    = \FFMpeg\FFProbe::create();
                $word->audio = $audio_url;
                $word->audio_blob = null;
                $duration=$ffprobe->format($audio_url)->get('duration');
                $length=$duration/60;
                $word->audio_duration  = $length;
                /*$word->transcription = $request->transcription;
                $word->modified_sentence  = $request->modified_sentence;*/
                $word->updated_at= NULL;
                $word->save();

            }else{

                if ($request->file('audio') == !null) {

                    $audioPath = public_path($word->audio);
                    if (File::exists($audioPath)) {
                        unlink($audioPath);
                    }

                    foreach ($request->file('audio') as $key => $audio_data) {

                        $audioName  =   time().'_'.unique_code(10).'.'.$audio_data->getClientOriginalExtension();
                        $directory  =   'uploads/data-collections/';
                        $audioUrl   =   $directory.$audioName;
                        $audio_data->move($directory, $audioName);

                        $ffprobe    = \FFMpeg\FFProbe::create();
                        $word->audio = $audioUrl;
                        $word->audio_blob = null;
                        $duration=$ffprobe->format($audioUrl)->get('duration');
                         $length=$duration/60;
                        $word->audio_duration  = $length;
                        /*$word->transcription = $request->transcription;
                        $word->modified_sentence  = $request->modified_sentence;*/
                        $word->updated_at= NULL;
                        $word->save();
                    }
                }

            }

        }

    }
    public function sendToWordApprove(Request $request){

        DCWordCollection::where('id', $request->d_c_word_collection_id)
            ->update(['approved_date' => Carbon::now(), 'approved_by' => auth()->id(), 'status' => $request->status]);

        return redirect()->back()->with('success', __('Word Send to Approve Successfully'));
    }
    public function trimOriginalWordAudio ($type, $dc_word_id){
        if ($type == 0) {
            $audio = DCWordCollection::where('id',$dc_word_id)->with(['word', 'dcWord.collection.taskAssign'])->first();
        }
        if (Facades\Session::has('trim_previous_url')) {
            Facades\Session::forget('trim_previous_url');
        }
        Facades\Session::put('trim_previous_url', url()->previous());

        return view('admin.word_collection.word-trim', [
            'audio'     => $audio,
            'type'      => $type
        ]);
    }
    public function replaceWordTrimAudio (Request $request){

        if ($request->type == 0) {
            $decoded_file = $request->trim_value;  //Decoded audio file
            $audio_parts  = explode(";base64,", $decoded_file);
            $audio_type   = explode("audio/mp3", $audio_parts[0]);
            $audio_base64 = base64_decode($audio_parts[1]);
            $audio_directory = 'uploads/data-collections/';
            $file_name = 'trim_'.time().'_'.unique_code(10).'.mp3'; // Rename the file
            $record = file_put_contents($audio_directory.$file_name, $audio_base64); //save file in the disk
            $trimAudioUrl = $audio_directory.$file_name;
            $ffprobe    = \FFMpeg\FFProbe::create();

            $dcWordCollection = DCWordCollection::where('id', $request->audio_id)->with(['word', 'dcWord'])->first();
            if (file_exists($dcWordCollection->audio)) {
                unlink($dcWordCollection->audio);
            }
            $dcWordCollection->audio  = $trimAudioUrl;
            $dcWordCollection->audio_blob     = null;
            $duration=$ffprobe->format($trimAudioUrl)->get('duration');
            $length =$duration/60;
            $dcWordCollection->audio_duration  = $length;
            $dcWordCollection->updated_at = Carbon::now();
            $dcWordCollection->save();
        }

        return Redirect::to(session()->get('trim_previous_url'))->with('message', 'Word Audio replaced successfully.');

    }

    public function topicWiseWordValidationStore(Request $request)
    {
        $dcWordCollection =DCWordCollection::findOrFail($request->d_c_word_collection_id);
        $dcWordCollection->validator_id = auth()->id();
        $dcWordCollection->validation_status = $request->validation_status;
        $dcWordCollection->topic_status = 3;
        $dcWordCollection->save();
        return response()->json(['msg' => __('শব্দ ও ব্যাকরণ সফলভাবে ভ্যালিডেট হয়েছে')]);
    }
    public function topicWiseWordApprove(Request $request){
        DCWordCollection::where('id', $request->d_c_word_collection_id)
            ->update(['approved_date' => Carbon::now(), 'approved_by' => auth()->id(), 'status' => '1', 'topic_status' => '4']);

        return response()->json(['msg' => __('শব্দ ও ব্যাকরণ সফলভাবে অনুমোদিত হয়েছে')]);
    }


    public function editWord($TaskID, $wordTopicID){
        $wordByTasks = WordTaskAssign::where('task_assign_id', $TaskID)
            ->where('topic_word_id', $wordTopicID)
            ->with('collector', 'taskAssign.speakers', 'taskAssign.language', 'taskAssign.district', 'topicWord.words')
            ->first();
        $taskBySentences = $wordByTasks->topicWord->words->paginate(1);
        $sentenceList = $wordByTasks->topicWord->words;

        return view('admin.word_collection.editWord', compact('sentenceList', 'taskBySentences', 'wordByTasks'));
    }


    public function updateWord(Request $request, $id){
        if ($id== 0){
            return response()->json(['msg' => __('এখনও  অডিও কালেকশন হয়নি ।')]);
        }
        $dcWordCollection = DCWordCollection::findOrFail($id);
        $dcWordCollection->english = $request->english;
        $dcWordCollection->transcription = $request->transcription;
        $dcWordCollection->modified_sentence = $request->modified_sentence;
        $dcWordCollection->update();
        return response()->json(['msg' =>__('নির্দেশিত বাক্য সফলভাবে আপডেট করা হয়েছে।')]);
    }


}

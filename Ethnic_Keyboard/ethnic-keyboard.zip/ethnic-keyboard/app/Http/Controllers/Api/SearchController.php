<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\DataCollection;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function searchLanguageByTopic(Request $request)
    {
        $keyword = $request->keyword;
        $language=$request->language;
        $topic=$request->topic;
        $word=$request->topic;

        $searchResult= $this->searchExistingData($request,$keyword, $language, $topic, $word);

        $language=$searchResult['language'];
        $topic=$searchResult['topic'];
        $word=$searchResult['word'];
        $spontaneous=$searchResult['spontaneous'];


        if (!$language && !$topic && !$word && !$spontaneous) {
            return ['message' => 'No data found'];
        }

        $dataCollections=DataCollection::with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
            'dcDirected.topic', 'dcSpontaneous.spontaneous', 'dcWord.topicWord')
            ->has('taskAssign')
            ->when($language, function ($query,$language){
                $query->whereHas('language', function ($query) use ($language) {
                    return $query->where('name', 'like', '%' . $language . '%');
                });
            })->when($topic, function ($query, $topic){
                $query->whereHas('dcDirected.topic', function ($query) use ($topic) {
                    return $query->where('name', 'like', '%' . $topic . '%');
                });
            })->when($spontaneous, function ($query, $spontaneous) {
                $query->whereHas('dcSpontaneous.spontaneous', function ($query) use ($spontaneous) {
                    return $query->where('word', 'like', '%' .$spontaneous. '%');
                });
            })->when($word, function ($query,$word) {
                $query->whereHas('dcWord.topicWord', function ($query) use ($word) {
                    return $query->where('name', 'like', '%' .$word. '%');
                });
            })
            ->orderBy('id', 'desc')
            ->get()->chunk(40000);

        foreach ($dataCollections as $dataCollection) {
            $direcTopicCollections = $dataCollection->where('type_id', 1)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcDirected']['topic_id']??'';
            });
            $sponWordCollections = $dataCollection->where('type_id', 2)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcSpontaneous']['spontaneous_id']??'';
            });
            $wordCollections = $dataCollection->where('type_id', 0)->unique(function ($item) {
                return $item['task_assign_id'].$item['dcWord']['topic_word_id']??'';
            });
            $dataCollections = $direcTopicCollections->merge($sponWordCollections)??'';
            $dataCollections = $dataCollections->merge($wordCollections);
        }
        $dataCollections = $dataCollections->sortByDesc('created_at');


        $retsult=[];
        $n=1;
        if ($dataCollections->count() == 0){
            return $retsult=[];
        }
        foreach ($dataCollections as $key=> $dataCollection){
            $type='';
            if ($dataCollection->type_id == 0){
                $type = 'word';
            }elseif ($dataCollection->type_id == 1){
                $type = 'directed';
            }elseif ($dataCollection->type_id == 2){
                $type = 'spontaneous';
            }
            $retsult[]=[
                'serial_no'=>$n++,
                'district'=>$dataCollection->district->name,
                'language'=>$dataCollection->language->name,
                'type'=>$type,
                'collector' =>$dataCollection->collector->name,
                'topic' =>$dataCollection->dcDirected->topic->name??$dataCollection->dcWord->topicWord->name??$dataCollection->dcSpontaneous->spontaneous->word,
                'task_assign_id' =>$dataCollection->task_assign_id,
                'topic_id' =>$dataCollection->dcDirected->topic_id??$dataCollection->dcWord->topic_word_id??$dataCollection->dcSpontaneous->spontaneous_id,
                'collection_id' =>$dataCollection->id,
            ];

        }

        return $retsult;

    }



    private function searchExistingData($request ,$keyword, $language, $topic, $word){
        if ($keyword && !$language && !$topic) {
            $isLanguage = DataCollection::whereHas('language', function ($query) use ($keyword) {
                return $query->where('name', 'like', '%' .$keyword. '%');
            })->exists();
            $language = $isLanguage ? $request->keyword : null;
            $isTopic = DataCollection::whereHas('dcDirected.topic', function ($query) use ($keyword) {
                return $query->where('name', 'like', '%' .$keyword. '%');
            })->exists();
            $topic = $isTopic ? $request->keyword : null;
            $isSpontaneous = DataCollection::whereHas('dcSpontaneous.spontaneous', function ($query) use ($keyword) {
                return $query->where('word', 'like', '%' .$keyword. '%');
            })->exists();
            $spontaneous = $isSpontaneous ? $request->keyword : null;
            $isWord = DataCollection::whereHas('dcWord.topicWord', function ($query) use ($keyword) {
                return $query->where('name', 'like', '%' .$keyword. '%');
            })->exists();
            $word = $isWord ? $request->keyword : null;
        }elseif ($keyword && $language && !$topic){
            $isLanguage = DataCollection::whereHas('language', function ($query) use ($language) {
                return $query->where('name', 'like', '%' .$language. '%');
            })->exists();
            $language = $isLanguage ? $request->language : null;
            $isTopic = DataCollection::whereHas('dcDirected.topic', function ($query) use ($keyword) {
                return $query->where('name', 'like', '%' .$keyword. '%');
            })->exists();
            $topic = $isTopic ? $request->keyword : null;
            $isSpontaneous = DataCollection::whereHas('dcSpontaneous.spontaneous', function ($query) use ($keyword) {
                return $query->where('word', 'like', '%' .$keyword. '%');
            })->exists();
            $spontaneous = $isSpontaneous ? $request->keyword : null;
            $isWord = DataCollection::whereHas('dcWord.topicWord', function ($query) use ($keyword) {
                return $query->where('name', 'like', '%' .$keyword. '%');
            })->exists();
            $word = $isWord ? $request->keyword : null;
        }elseif (!$keyword && !$language && $topic){
            $isLanguage = DataCollection::whereHas('language', function ($query) use ($topic) {
                return $query->where('name', 'like', '%' .$topic. '%');
            })->exists();
            $language = $isLanguage ? $request->topic : null;
            $isTopic = DataCollection::whereHas('dcDirected.topic', function ($query) use ($topic) {
                return $query->where('name', 'like', '%' .$topic. '%');
            })->exists();
            $topic = $isTopic ? $request->topic : null;
            $isSpontaneous = DataCollection::whereHas('dcSpontaneous.spontaneous', function ($query) use ($topic) {
                return $query->where('word', 'like', '%' .$topic. '%');
            })->exists();
            $spontaneous = $isSpontaneous ? $request->topic : null;
            $isWord = DataCollection::whereHas('dcWord.topicWord', function ($query) use ($word) {
                return $query->where('name', 'like', '%' .$word. '%');
            })->exists();
            $word = $isWord ? $request->topic : null;
        }elseif (!$keyword && $language && $topic){
            $isLanguage = DataCollection::whereHas('language', function ($query) use ($language) {
                return $query->where('name', 'like', '%' .$language. '%');
            })->exists();
            $language = $isLanguage ? $request->language : null;
            $isTopic = DataCollection::whereHas('dcDirected.topic', function ($query) use ($topic) {
                return $query->where('name', 'like', '%' .$topic. '%');
            })->exists();
            $topic = $isTopic ? $request->topic : null;
            $isSpontaneous = DataCollection::whereHas('dcSpontaneous.spontaneous', function ($query) use ($topic) {
                return $query->where('word', 'like', '%' .$topic. '%');
            })->exists();
            $spontaneous = $isSpontaneous ? $request->topic : null;
            $isWord = DataCollection::whereHas('dcWord.topicWord', function ($query) use ($word) {
                return $query->where('name', 'like', '%' .$word. '%');
            })->exists();
            $word = $isWord ? $request->topic : null;
        }
        else{
            $isLanguage = DataCollection::whereHas('language', function ($query) use ($language) {
                return $query->where('name', 'like', '%' .$language. '%');
            })->exists();
            $language = $isLanguage ? $request->language : null;
            $isTopic = DataCollection::whereHas('dcDirected.topic', function ($query) use ($topic) {
                return $query->where('name', 'like', '%' .$topic. '%');
            })->exists();
            $topic = $isTopic ? $request->topic : null;
            $isSpontaneous = DataCollection::whereHas('dcSpontaneous.spontaneous', function ($query) use ($keyword) {
                return $query->where('word', 'like', '%' .$keyword. '%');
            })->exists();
            $spontaneous = $isSpontaneous ? $request->keyword : null;
            $isWord = DataCollection::whereHas('dcWord.topicWord', function ($query) use ($word) {
                return $query->where('name', 'like', '%' .$word. '%');
            })->exists();
            $word = $isWord ? $request->topic : null;
        }

        return  [
            'language'=>$language,
            'topic'=>$topic,
            'spontaneous'=>$spontaneous,
            'word'=>$word
            ];
    }
}

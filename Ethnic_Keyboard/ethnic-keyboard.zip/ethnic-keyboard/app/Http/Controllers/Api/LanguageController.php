<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DCWordCollection;
use App\Models\Directed;
use App\Models\Language;
use App\Models\LanguageDistrict;
use App\Models\Speaker;
use App\Models\Spontaneous;
use App\Models\SubLanguage;
use App\Models\TaskAssign;
use App\Models\Topic;
use App\Models\Topic_word;
use App\Models\Word;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;


class LanguageController extends Controller
{
    public function getLanguageList(){
        try {
            $languages = Language::get(['id', 'name']);
            $languages = $languages->except([28, 55]);

            if ($languages->isEmpty()){
                return response([
                    'data' => '',
                    'message' => 'No data Found',
                    'status' => 200
                ]);
            }
            return $languages;


        } catch (\Exception $e) {
            return response([
                'data' => '',
                'message' => $e->getMessage(),
                'status' => 500
            ]);

        }
    }

    public function getLanguageByTime(){
        try {
            $totalDirectedAudio = DB::table('d_c_directed_sentences')
                ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_directed'), 'languages.name')
                ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
                ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->groupBy('data_collections.language_id')
                ->get()->toArray();
            $directedLanguageAudios = array_reduce($totalDirectedAudio, function ($result, $item) {
                if (!isset($result[$item->name])) $result[$item->name] = 0;
                $result[$item->name] += $item->sum_of_directed;
                return $result;
            }, array());

            $totalWordAudio = DB::table('d_c_word_collections')
                ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_word'), 'languages.name')
                ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
                ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->groupBy('data_collections.language_id')
                ->get()->toArray();

            $wordLanguageAudios = array_reduce($totalWordAudio, function ($result, $item) {
                if (!isset($result[$item->name])) $result[$item->name] = 0;
                $result[$item->name] += $item->sum_of_word;
                return $result;
            }, array());

            $totalSpontAudio = DB::table('d_c_spontaneouses')
                ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_spontaneous'), 'languages.name', 'data_collections.type_id')
                ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
                ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                ->groupBy('data_collections.language_id')
                ->get()->toArray();

            $spontaneousLanguageAudios = array_reduce($totalSpontAudio, function ($result, $item) {
                if (!isset($result[$item->name])) $result[$item->name] = 0;
                $result[$item->name] += $item->sum_of_spontaneous;
                return $result;
            }, array());


            $output = array_merge_recursive($totalDirectedAudio, $totalWordAudio, $totalSpontAudio);

            $totalAudio = array_reduce($output, function ($result, $item) {
                if (!isset($result[$item->name])) $result[$item->name] = 0;
                $result[$item->name] += $item->sum_of_length;
                return $result;
            }, array());
            $totalAudio = Arr::except($totalAudio, ['Test language', 'TEST']);

            $lebel = [];
            $data = [];
            foreach($totalAudio as $key=>$audio)
            {
                $collectedseconds= round($audio, 2);
                $collectedminutes = floor($collectedseconds / 60);
                $collectedseconds = $collectedseconds % 60;
                //$data[$key]= $collectedminutes.' . '.$collectedseconds;
                $lebel[] = $key;
                $data[] = $collectedminutes.'.'.$collectedseconds;
                /*$retsult[]=[
                    'language'=>$key,
                    'time'=>$collectedminutes.' . '.$collectedseconds,
                ];*/

            }
            // $numbers = collect($data)->map(fn ($datas) => (float) $datas)->toArray();

            return [
                'labels'=>$lebel,
                'times'=>$data,
            ];

        } catch (\Exception $e) {
            return response([
                'data' => '',
                'message' => $e->getMessage(),
                'status' => 500
            ]);

        }
    }


    public function getLanguageInfo(){
        try {
            $languageCount = Language::whereNotIn('id', [28, 55])->count();
            $subLanguageCount =SubLanguage::count();
            $speakersCount = Speaker::count();
            $topicWithSentence= $this->languageByAllTask(null);
            $timeCount = $this->getLanguageTotalTime(null);


            return $data = [
                'languages' => $languageCount,
                'sub_languages' => $subLanguageCount,
                'topics' => $topicWithSentence['topics'],
                'speakers' => $speakersCount,
                'sentences' => $topicWithSentence['sentences'],
                'times' => $timeCount,
            ];

        } catch (\Exception $e) {
            return response([
                'data' => '',
                'message' => $e->getMessage(),
                'status' => 500
            ]);

        }
    }



    private function getLanguageTotalTime($languageName = null){
        $totalDirectedAudio = DB::table('d_c_directed_sentences')
            ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_directed'), 'languages.name')
            ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->groupBy('data_collections.language_id')
            ->get()->toArray();

        $totalWordAudio = DB::table('d_c_word_collections')
            ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_word'), 'languages.name')
            ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->groupBy('data_collections.language_id')
            ->get()->toArray();

        $totalSpontAudio = DB::table('d_c_spontaneouses')
            ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_spontaneous'), 'languages.name', 'data_collections.type_id')
            ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->groupBy('data_collections.language_id')
            ->get()->toArray();

        $output = array_merge_recursive($totalDirectedAudio, $totalWordAudio, $totalSpontAudio);

        $totalAudio = array_reduce($output, function ($result, $item) {
            if (!isset($result[$item->name])) $result[$item->name] = 0;
            $result[$item->name] += $item->sum_of_length;
            return $result;
        }, array());

        if($languageName != null){
            $collectedseconds= round($totalAudio[$languageName['0']], 2);
            $collectedminutes = floor($collectedseconds / 60);
            $collectedseconds = $collectedseconds % 60;
            return $collectedminutes.'.'.$collectedseconds;
        }else{
            $result = 0;
            foreach($totalAudio as $key=>$audio) {
                $result += $audio;
            }
            $collectedseconds= round($result, 2);
            $collectedminutes = floor($collectedseconds / 60);
            $collectedseconds = $collectedseconds % 60;
            return $collectedminutes.'.'.$collectedseconds;
        }

        return false;
    }


    public function getSingleLanguageInfo($languageID){
        try {
            $languageCount = Language::where('id',$languageID)
                ->whereNotIn('id', [28, 55])->count();
            $languageName= Language::where('id',$languageID)->pluck('name');
            $languageDistric=LanguageDistrict::where('language_id',$languageID)->pluck('id');
            $speakersCount = Speaker::whereIn('language_district_id',$languageDistric)->count();
            $topicWithSentence= $this->languageByAllTask($languageID);
            $subLanguageCount =SubLanguage::where('language_id', $languageID)->count();
            $timeCount = $this->getLanguageTotalTime($languageName);


            return $data = [
                'languages' => $languageCount,
                'sub_languages' => $subLanguageCount,
                'topics' => $topicWithSentence['topics'],
                'speakers' => $speakersCount,
                'sentences' => $topicWithSentence['sentences'],
                'times' => $timeCount,
            ];

        } catch (\Exception $e) {
            return response([
                'data' => '',
                'message' => $e->getMessage(),
                'status' => 500
            ]);

        }
    }


    private function directedTopicCount($languageID){
        return  DB::table('d_c_directeds')
            ->select('data_collections.id', 'topic_id as topic',
                'data_collections.type_id as type', 'data_collections.task_assign_id')
            ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('topic_id','data_collections.task_assign_id')
            ->get()->count();
    }

    private function wordTopicCount($languageID){
        return DB::table('d_c_words')
            ->select('data_collections.id', 'topic_word_id as topic',
                'data_collections.type_id as type', 'data_collections.task_assign_id')
            ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
            ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
            ->where('data_collections.language_id', $languageID)
            ->groupBy('topic_word_id','data_collections.task_assign_id')
            ->get()->count();
    }


    public function languageByAllTask($languageID=null){
        if ($languageID == null){
            $languageByTasks= Cache::remember('languageByTasks', 120, function () {
                return TaskAssign::with('directedTaskSentence', 'wordTaskSentence')
                    ->withCount('directedTasks', 'WordTasks', 'spontaneousTasks')
                    ->get();
            });

        }else{
            $languageByTasks = Cache::remember('languageByTasks'.$languageID, 120, function () use ($languageID) {
                return TaskAssign::with('directedTaskSentence', 'wordTaskSentence')
                    ->withCount('directedTasks', 'WordTasks', 'spontaneousTasks')
                    ->where('language_id', $languageID)
                    ->get();
            });
        }

        $directeds_count = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->directedTaskSentence as $directedTaskSentence){
                $directeds_count += $directedTaskSentence->topic->directeds_count;
            }
        }

        $words_count = 0;
        foreach ($languageByTasks as $languageByTask){
            foreach ($languageByTask->wordTaskSentence as $wordTaskSentence){
                $words_count += $wordTaskSentence->topicWord->words_count;
            }
        }
        $topics=$languageByTasks->sum('directed_tasks_count')+
            $languageByTasks->sum('spontaneous_tasks_count')+
            $languageByTasks->sum('word_tasks_count');


        return  $languageByTasks=[
            'topics' => $topics,
            'sentences' => $directeds_count+$words_count,
        ];
    }


    public function languageByTopic($languageID){
        try {
            $query = DataCollection::query();
            $dataCollections=$query;
            $dataCollections=$dataCollections->with('language:id,name', 'district:id,name','taskAssign:id,start_date,end_date',
                'dcDirected.topic', 'dcSpontaneous.spontaneous', 'dcWord.topicWord')
                ->where('language_id', $languageID)
                ->orderBy('id', 'desc')
                ->get()->chunk(40000);

            foreach ($dataCollections as $dataCollection) {
                $direcTopicCollections = $dataCollection->where('type_id', 1)->unique(function ($item) {
                    return $item['task_assign_id'].$item['dcDirected']['topic_id']??'';
                });
                $sponWordCollections = $dataCollection->where('type_id', 2)->unique(function ($item) {
                    return $item['task_assign_id'].$item['dcSpontaneous']['spontaneous_id']??'';
                });
                $wordCollections = $dataCollection->where('type_id', 0)->unique(function ($item) {
                    return $item['task_assign_id'].$item['dcWord']['topic_word_id']??'';
                });
                $dataCollections = $direcTopicCollections->merge($sponWordCollections)??'';
                $dataCollections = $dataCollections->merge($wordCollections);
            }
            $dataCollections = $dataCollections->sortByDesc('created_at');

            $retsult=[];
            $n=1;
            foreach ($dataCollections as $key=> $dataCollection){
                $type='';
                if ($dataCollection->type_id == 0){
                    $type = 'word';
                }elseif ($dataCollection->type_id == 1){
                    $type = 'directed';
                }elseif ($dataCollection->type_id == 2){
                    $type = 'spontaneous';
                }
                $retsult[]=[
                    'serial_no'=>$n++,
                    'district'=>$dataCollection->district->name,
                    'type'=>$type,
                    'collector' =>$dataCollection->collector->name,
                    'topic' =>$dataCollection->dcDirected->topic->name??$dataCollection->dcWord->topicWord->name??$dataCollection->dcSpontaneous->spontaneous->word,
                    'task_assign_id' =>$dataCollection->task_assign_id,
                    'topic_id' =>$dataCollection->dcDirected->topic_id??$dataCollection->dcWord->topic_word_id??$dataCollection->dcSpontaneous->spontaneous_id,
                    'collection_id' =>$dataCollection->id,
                ];

            }

            return $retsult;
        }catch (\Exception $exception){
            return $exception->getMessage();
        }

    }

    public function languageBySentenceWithCollection($languageID, $type, $taskAssignID, $topicID){
        try {

            switch ($type){
                case 'directed':
                    $dataCollections = $this->directedCollectionlists($languageID, $taskAssignID, $topicID);
                    break;
                case 'spontaneous':
                    $dataCollections = $this->spontaneousCollectionlists($languageID, $taskAssignID, $topicID);
                    break;
                case 'word':
                    $dataCollections = $this->wordCollectionlists($languageID, $taskAssignID, $topicID);
                    break;
            }


            return $dataCollections;
        }catch (\Exception $exception){
            return $exception->getMessage();
        }

    }


    private function directedCollectionlists($languageID, $taskAssignID, $topicID){
        $query = DataCollection::query();
        $dataCollections=$query;

        $dataCollections=$dataCollections->where('task_assign_id', $taskAssignID)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcDirected.dcSentence.directed',
                'dcDirected.dcSentence'=>function($q){
                    $q->select('id', 'directed_id', 'd_c_directed_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date','like_count');
                }])
            ->whereHas('dcDirected', function ($query) use ($topicID) {
                $query->where('topic_id', $topicID);
            })
            ->where('language_id', $languageID)
            ->latest()
            ->get();
        $dataCollections = $dataCollections->unique('dcDirected.dcSentence.directed_id');

        $retsult=[];
        $n=1;
        foreach ($dataCollections as $key=> $dataCollection){

            //$baseUrl = 'https://'.$_SERVER['HTTP_HOST'].'/';
            $baseUrl = 'https://lob.bangla.gov.bd/';
            $retsult[]=[
                'serial_no'=>$n++,
                'district'=>$dataCollection->district->name,
                'type'=>'Directed',
                'collector' =>$dataCollection->collector->name,
                'topic' =>$dataCollection->dcDirected->topic->name,
                'task_assign_id' =>$dataCollection->task_assign_id,
                'topic_id' =>$dataCollection->dcDirected->topic_id,
                'sentence' =>$dataCollection->dcDirected->dcSentence->directed->sentence,
                'audio' =>$baseUrl.$dataCollection->dcDirected->dcSentence->audio,
                'english' =>$dataCollection->dcDirected->dcSentence->english,
                'transcription' =>$dataCollection->dcDirected->dcSentence->transcription,
                'bangla' =>$dataCollection->dcDirected->dcSentence->bangla,
                'like_counts' =>$dataCollection->dcDirected->dcSentence->like_count,
                'id' =>$dataCollection->dcDirected->dcSentence->id,
            ];
        }

        return $retsult;

    }

    private function wordCollectionlists($languageID, $taskAssignID, $topicID){
        $dataCollections=DataCollection::where('task_assign_id', $taskAssignID)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcWord.dcWordCollection.word',
                'dcWord.dcWordCollection'=>function($q2){
                    $q2->select('id', 'word_id', 'd_c_word_id', 'audio','status','topic_status',
                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date', 'like_count');
                }])
            ->whereHas('dcWord', function ($query) use ($topicID) {
                $query->where('topic_word_id', $topicID);
            })
            ->where('language_id', $languageID)
            ->latest()
            ->get();
        $dataCollections = $dataCollections->unique('dcWord.dcWordCollection.word_id');

        $retsult=[];
        $n=1;
        foreach ($dataCollections as $key=> $dataCollection){
            //$baseUrl = 'https://'.$_SERVER['HTTP_HOST'].'/';
            $baseUrl = 'https://lob.bangla.gov.bd/';
            $retsult[]=[
                'serial_no'=>$n++,
                'district'=>$dataCollection->district->name,
                'type'=>'Word',
                'collector' =>$dataCollection->collector->name,
                'topic' =>$dataCollection->dcWord->topicWord->name,
                'task_assign_id' =>$dataCollection->task_assign_id,
                'topic_id' =>$dataCollection->dcWord->topic_word_id,
                'sentence' =>$dataCollection->dcWord->dcWordCollection->word->sentence,
                'audio' =>$baseUrl.$dataCollection->dcWord->dcWordCollection->audio,
                'english' =>$dataCollection->dcWord->dcWordCollection->english,
                'transcription' =>$dataCollection->dcWord->dcWordCollection->transcription,
                'bangla' =>$dataCollection->dcWord->dcWordCollection->bangla,
                'like_counts' =>$dataCollection->dcWord->dcWordCollection->like_count,
                'id' =>$dataCollection->dcWord->dcWordCollection->id,
            ];
        }
        return $retsult;

    }


    private function spontaneousCollectionlists($languageID, $taskAssignID, $topicID){
        $dataCollection = DataCollection::where('task_assign_id', $taskAssignID)
            ->with(['language:id,name', 'district:id,name',
                'collector:id,name', 'speaker:id,name', 'taskAssign:id,start_date,end_date',
                'dcSpontaneous.spontaneous',
                'dcSpontaneous'=>function($q){
                    $q->select('id', 'spontaneous_id','data_collection_id', 'audio','status', 'approved_by', 'approved_date','like_count');
                }])
            ->whereHas('dcSpontaneous', function ($query) use ($topicID) {
                $query->where('spontaneous_id', $topicID);
            })
            ->where('language_id', $languageID)
            ->first();

        $trims = [];
        $spontinoursAudios = AudioTrim::where('d_c_spontaneouses_id', @$dataCollection->dcSpontaneous->id)->latest()->get();
        if ($spontinoursAudios->isNotEmpty()) {
            foreach ($spontinoursAudios as $spontinoursAudio) {
                array_push($trims, $spontinoursAudio);
            }
        }
        $trims = array_filter($trims);

        //$baseUrl = 'https://'.$_SERVER['HTTP_HOST'].'/';
        $baseUrl = 'https://lob.bangla.gov.bd/';
        $trims = array_map(function ($trim) use ($baseUrl) {
            $trim->audio = $baseUrl.$trim->audio;
            return $trim;
        }, $trims);
        // add serial no for trim audio
        $trims = array_map(function ($trim, $key) {
            $trim->serial_no = $key + 1;
            return $trim;
        }, $trims, array_keys($trims));


        $retsult=[];
        $n=1;
        if($dataCollection) {
            //$baseUrl = 'https://'.$_SERVER['HTTP_HOST'].'/';
            $baseUrl = 'https://lob.bangla.gov.bd/';
            $retsult[] = [
                'serial_no' => $n++,
                'district' => $dataCollection->district->name,
                'type' => 'Spontaneous',
                'collector' => $dataCollection->collector->name,
                'sentence' => $dataCollection->dcSpontaneous->spontaneous->word,
                'task_assign_id' => $dataCollection->task_assign_id,
                'topic_id' => $dataCollection->dcSpontaneous->spontaneous_id,
                'd_c_spontaneous_id' => $dataCollection->dcSpontaneous->id,
                'audio' => $baseUrl.$dataCollection->dcSpontaneous->audio,
                'like_counts' => $dataCollection->dcSpontaneous->like_count,
                'id' => $dataCollection->dcSpontaneous->id,
                'trimAudios'=>$trims,
            ];
        }
        return $retsult;
    }


    public function sentenceLikeCount( Request $request, $type, $ID){
        try {

            switch ($type){
                case 'directed':
                    $dataCollections = $this->directedSentenceLikeCount($ID, $request);
                    break;
                case 'spontaneous':
                    $dataCollections = $this->spontaneousTrimLikeCount($ID, $request);
                    break;
                case 'word':
                    $dataCollections = $this->wordSentenceLikeCount($ID, $request);
                    break;
            }

            return $dataCollections;
        }catch (\Exception $exception){
            return $exception->getMessage();
        }

    }

    private function directedSentenceLikeCount($ID, $request){
         $dcDirectedSentence = DCDirectedSentence::findOrFail($ID);
        if($request->like == '1'){
            $dcDirectedSentence->like_count = $dcDirectedSentence->like_count + 1;
            $dcDirectedSentence->save();
        }
        return response()->json([
                'message' => 'Like count updated successfully',
                'data' => $dcDirectedSentence
            ]);
    }

    private function spontaneousTrimLikeCount($ID, $request){
        $audioTrim = DCSpontaneous::findOrFail($ID);

        if($request->like == '1'){
            $audioTrim->like_count = $audioTrim->like_count + 1;
            $audioTrim->save();
        }
        return response()->json([
                'message' => 'Like count updated successfully',
                'data' => $audioTrim
            ]);

    }
    private function wordSentenceLikeCount($ID, $request){
         $dcWordSentence = DCWordCollection::findOrFail($ID);

         if($request->like == '1'){
            $dcWordSentence->like_count = $dcWordSentence->like_count + 1;
            $dcWordSentence->save();
        }

        return response()->json([
                'message' => 'Like count updated successfully',
                'data' => $dcWordSentence
            ]);

    }



}

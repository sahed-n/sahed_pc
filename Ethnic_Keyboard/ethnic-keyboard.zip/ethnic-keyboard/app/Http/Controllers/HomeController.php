<?php

namespace App\Http\Controllers;


use App\Models\AudioTrim;
use App\Models\DataCollection;
use App\Models\DCDirected;
use App\Models\DCDirectedSentence;
use App\Models\DCSpontaneous;
use App\Models\DCWordCollection;
use App\Models\Directed;
use App\Models\DirectedTaskAssign;
use App\Models\SpontaneousTaskAssign;
use App\Models\Language;
use App\Models\Notification;
use App\Models\Speaker;
use App\Models\Spontaneous;
use App\Models\TaskAssign;
use App\Models\Topic;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\LinguistTaskAssign;
use App\Models\ValidatorTaskAssign;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
use Spatie\Activitylog\Models\Activity;
//use function PHPUnit\Framework\isEmpty;
// use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        try {
            $allUsers = User::count();
            $languageCounts = Language::withCount(['directedLanguage', 'spontaneousLanguage'])->get();
            $totalSpeakers = Speaker::where('created_by', auth()->id())->count();
            $totalCollections = '';
            $totalLanguages = '';
            $totalDirectedTopics = '';
            $totalDirectedSentences = '';
            $totalSpontaneous = '';
            $totalCollectors = '';
            $todayDirecteds = '';
            $todayDirctedCounts = '';
            $todayDataCollections = '';
            $todaycollections = '';
            $todaySpontaneouses = '';
            $todaySpontaneouCounts = '';
            $taskAssignByLanguage = '';
            $languagebyLinguists = '';
            $languagebyValidators = '';
            $taskBycollections = '';
            $totalLang = '';
            $totalDirected = '';
            $totalSpon = '';
            $totalPendingSpon = '';
            $totalDirPending = '';
            $todayDataCollects = '';
            $totalAudio = '';
            $totalAudioApprove = '';
            $login = '';
            $totalApproved = '';
            $approvedCount = '';
            $totalPending = '';
            $CollectedCollections = [];
            $spontaneousLanguageAudios = '';
            $wordLanguageAudios = '';
            $directedLanguageAudios = '';


            $login = Activity::where('log_name', 'LIKE', "%{$login}%")
                ->whereDate('created_at', '=', Carbon::today()->toDateString())
                ->distinct()
                ->count('causer_id');

            /* if (Auth::user()->hasRole(['Manager'])){
                 $todayDataCollects = DataCollection::whereDate('created_at', '=', Carbon::today()->toDateString())
                     ->with(['language','collector','taskAssign','dcDirected' =>function($q){
                         $q->with('topic' ,'dcSentence.directed')->get();
                     } ])
                     ->latest()->get();
             }*/

            if (Auth::user()->hasRole(['Data Collector'])) {

                $approvedDirecteds = DCDirectedSentence::where('status', 1)->where('created_by', auth()->id())->count();
                $approvedWords = DCWordCollection::where('status', 1)->where('created_by', auth()->id())->count();
                $approvedSpontaneouses = AudioTrim::where('status', 3)
                    ->whereHas('dcSpontaneous', function ($q) {
                        $q->where('created_by', auth()->id());
                    })->count();
                $totalApproved = $approvedDirecteds + $approvedWords + $approvedSpontaneouses;

                $directeds = DCDirectedSentence::where('status', 0)->where('created_by', auth()->id())->count();
                $words = DCWordCollection::where('status', 0)->where('created_by', auth()->id())->count();
                $spontaneouses = AudioTrim::where('status', 1)
                    ->whereHas('dcSpontaneous', function ($q) {
                        $q->where('created_by', auth()->id());
                    })->count();
                $totalPending = $directeds + $words + $spontaneouses;

                $todayDataCollections = DataCollection::where('created_by', auth()->id())->whereDate('created_at', '=', Carbon::today()->toDateString())
                    ->with(['language', 'collector', 'dcSpontaneous.spontaneous', 'dcDirected' => function ($q) {
                        $q->with('topic', 'dcSentence.directed')->get();
                    }])->latest()->limit(5)->get();
                // dd($todayDataCollections->toArray());

                $todaycollections = DataCollection::where('collector_id', auth()->id())->whereDate('created_at', '=', Carbon::today()->toDateString())
                    ->count();
                $totalLang = TaskAssign::where('user_id', auth()->id())->distinct('language_id')->count('language_id');

                $taskAssignByLanguage = TaskAssign::with(['directedTasks.topic' => function ($query) {
                    $query->withCount('directeds');
                }, 'WordTasks.topicWord' => function ($q) {
                    $q->withCount('words');
                }, /*'spontaneousTasks.spontaneous',*/ 'language.subLanguages', 'district', 'collections.speaker',
                    /*'collections.dcSpontaneous.spontaneous', 'collections.dcDirected.dcSentence.directed.topics',*/])
                    ->where('user_id', auth()->id())
                    ->withCount('WordTasks', 'directedTasks', 'spontaneousTasks')
                    ->latest()
                    ->get();
                foreach ($taskAssignByLanguage as $taskItem) {
                    $totalCollections = $taskItem->Collections->count();
                    $totalTask = $taskItem->spontaneous_tasks_count + $taskItem->directedTasks->sum('topic.directeds_count') +
                        $taskItem->WordTasks->sum('topicWord.words_count');
                    if ($totalTask == $totalCollections) {
                        $CollectedCollections[] = $taskItem;
                    }
                }
            }

            if (Auth::user()->hasRole(['Linguist', 'Validator'])) {
                $totalLanguages = Language::count();
                $totalDirectedTopics = Topic::count();
                $totalDirectedSentences = Directed::count();
                $totalSpontaneous = Spontaneous::count();

                if (Auth::user()->hasRole(['Linguist'])) {
                    $languagebyLinguists = LinguistTaskAssign::where('user_id', auth()->id())
                        ->get();
                    $languagebyLinguists = $languagebyLinguists->pluck('language.name', 'language.id');
                }


                if (Auth::user()->hasRole(['Validator'])) {
                    $languagebyValidators = ValidatorTaskAssign::where('user_id', auth()->id())->get();
                    $languagebyValidators = $languagebyValidators->pluck('language.name', 'language.id');
                }

            }
            if (Auth::user()->hasRole(['Admin', 'Manager'])) {

                $approvedDirecteds = DCDirectedSentence::where('status', 1)->count();
                $approvedWords = DCWordCollection::where('status', 1)->count();
                $approvedSpontaneouses = AudioTrim::where('status', 3)->count();
                $approvedCount = $approvedDirecteds + $approvedWords + $approvedSpontaneouses;

                $directeds = DCDirectedSentence::where('status', 0)->count();
                $words = DCWordCollection::where('status', 0)->count();
                $spontaneouses = AudioTrim::where('status', 1)->count();
                $totalPending = $directeds + $words + $spontaneouses;

                $totalCollections = DataCollection::count();

                $taskAssignByLanguage = TaskAssign::with('language')->groupBy(['language_id'])->orderByDesc('language_id')->get();

                $totalDirectedAudio = DB::table('d_c_directed_sentences')
                    ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_directed'), 'languages.name')
                    ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
                    ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->groupBy('data_collections.language_id')
                    ->get()->toArray();
                $directedLanguageAudios = array_reduce($totalDirectedAudio, function ($result, $item) {
                    if (!isset($result[$item->name])) $result[$item->name] = 0;
                    $result[$item->name] += $item->sum_of_directed;
                    return $result;
                }, array());

                $totalWordAudio = DB::table('d_c_word_collections')
                    ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_word'), 'languages.name')
                    ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
                    ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->groupBy('data_collections.language_id')
                    ->get()->toArray();

                $wordLanguageAudios = array_reduce($totalWordAudio, function ($result, $item) {
                    if (!isset($result[$item->name])) $result[$item->name] = 0;
                    $result[$item->name] += $item->sum_of_word;
                    return $result;
                }, array());

                $totalSpontAudio = DB::table('d_c_spontaneouses')
                    ->select(DB::raw('SUM(audio_duration)*60 AS sum_of_length'), DB::raw('SUM(audio_duration)*60 AS sum_of_spontaneous'), 'languages.name', 'data_collections.type_id')
                    ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->groupBy('data_collections.language_id')
                    ->get()->toArray();

                $spontaneousLanguageAudios = array_reduce($totalSpontAudio, function ($result, $item) {
                    if (!isset($result[$item->name])) $result[$item->name] = 0;
                    $result[$item->name] += $item->sum_of_spontaneous;
                    return $result;
                }, array());


                $output = array_merge_recursive($totalDirectedAudio, $totalWordAudio, $totalSpontAudio);

                $totalAudio = array_reduce($output, function ($result, $item) {
                    if (!isset($result[$item->name])) $result[$item->name] = 0;
                    $result[$item->name] += $item->sum_of_length;
                    return $result;
                }, array());

                //approve graph
                $totalDirectedApprove = DB::table('d_c_directed_sentences')
                    ->select('d_c_directed_sentences.audio', 'languages.name', DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
                    ->leftjoin('d_c_directeds', 'd_c_directed_sentences.d_c_directed_id', '=', 'd_c_directeds.id')
                    ->leftjoin('data_collections', 'd_c_directeds.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->where('d_c_directed_sentences.status', 1)
                    ->groupBy('data_collections.language_id')
                    ->get()->toArray();
                $totalWordApprove = DB::table('d_c_word_collections')
                    ->select('d_c_word_collections.audio', 'languages.name', DB::raw('SUM(audio_duration)*60 AS sum_of_length'))
                    ->leftjoin('d_c_words', 'd_c_word_collections.d_c_word_id', '=', 'd_c_words.id')
                    ->leftjoin('data_collections', 'd_c_words.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->where('d_c_word_collections.status', 1)
                    ->groupBy('data_collections.language_id')
                    ->get()->toArray();


                $totalSpontApprove = DB::table('audio_trims')
                    ->select('audio_trims.audio', 'languages.name')
                    ->leftjoin('d_c_spontaneouses', 'audio_trims.d_c_spontaneouses_id', '=', 'd_c_spontaneouses.id')
                    ->leftjoin('data_collections', 'd_c_spontaneouses.data_collection_id', '=', 'data_collections.id')
                    ->leftjoin('languages', 'data_collections.language_id', '=', 'languages.id')
                    ->where('audio_trims.status', 3)
                    ->get()->toArray();


                foreach ($totalSpontApprove as $key => $audio) {
                    $totalSpontApprove[$key]->sum_of_length = $this->getAudioDuration($audio->audio);
                }
                $outputApprove = array_merge_recursive($totalDirectedApprove, $totalWordApprove, $totalSpontApprove);
                $totalAudioApprove = array_reduce($outputApprove, function ($result, $item) {
                    if (!isset($result[$item->name])) $result[$item->name] = 0;
                    $result[$item->name] += $item->sum_of_length;
                    return $result;
                }, array());

                foreach ($totalAudio as $key => $value) {
                    $totalAudioApprove[$key] = $totalAudioApprove[$key] ?? 0;
                }
            }


            $languages = Language::pluck('name', 'id');
        }catch (\Exception $e){

            return redirect()->back()->with('error', $e->getMessage());
        }

        return view('dashboard', compact('allUsers', 'languageCounts', 'totalApproved', 'totalPending', 'totalCollectors',
                'todayDataCollections', 'todaycollections', 'totalCollections', 'languages','totalSpeakers', 'taskAssignByLanguage', 'totalLanguages',
                'totalDirectedTopics','totalDirectedSentences', 'totalSpontaneous', 'todayDirecteds', 'todayDirctedCounts',
                'todaySpontaneouses', 'todaySpontaneouCounts', 'taskBycollections', 'todaySpontaneouses', 'todaySpontaneouCounts',
                'totalLang','totalDirected','totalSpon','totalPendingSpon','totalDirPending','languagebyLinguists',
                'todayDataCollects','totalAudio','languagebyValidators','totalAudioApprove', 'login', 'CollectedCollections',
                'approvedCount', 'directedLanguageAudios', 'wordLanguageAudios', 'spontaneousLanguageAudios'));
    }


    public function getAudioDuration($audioFile){
        $media = FFMpeg::openUrl($audioFile);
        return $durationInSeconds = $media->getDurationInSeconds();
        /*$durationInMinutes = $durationInSeconds / 60;
        return $durationInMinutes;*/
    }

}

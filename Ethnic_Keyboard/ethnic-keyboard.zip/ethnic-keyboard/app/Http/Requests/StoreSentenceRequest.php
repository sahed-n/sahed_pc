<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreSentenceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'language_id' => 'required',
            'type_id'  => 'required',
            'audio-exists' => 'required_without_all:audio_blob,audio',
            /*'audio-exists' => 'required_without:audio_blob',*/
            'speaker_id' => 'required',
        ];
    }


    public function messages()
    {
        return [
            'audio-exists.required_without_all' => 'The record or audio file  is required.',
        ];
    }
}

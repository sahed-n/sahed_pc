<?php

namespace App\Imports;

use App\Models\Topic_word;
use App\Models\Word;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class wordWithSentence implements ToCollection, WithHeadingRow
{
    /**
    * @param Collection $collection
    */
    public function collection(Collection $rows)
    {
//        dd($rows->toArray());
        try {
            foreach ($rows as $row)
            {
                 if ($row['word'] != null){
                     // if exist $row['word'] in Topic_word table then not insert
                        $existTopicWord = Topic_word::where('name', $row['word'])->first();
                        if ($existTopicWord == null){
                            $topicWord = new Topic_word();
                            $topicWord->name = $row['word'];
                            $topicWord->save();
                        }
                 }
                $topicWordID = $topicWord->id??'';
                 $existTopicWordID=$existTopicWord->name??'';
                if ($topicWordID != null){
                    $word = new Word();
                    $word->sentence = $row['sentence'];
                    $word->english = $row['english'];
                    $word->topic_word_id = $topicWordID;
                    $word->save();
                }
                // if exist then show message and next loop
                /*if ($existTopicWordID != null){
                    return redirect()->back()->with('error', 'Word '.$existTopicWordID.' already exist');
                }*/
            }
        }catch (\Exception $e) {
            //throw new \Exception("error".$e->getMessage());
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

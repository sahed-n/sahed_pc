<?php

namespace App\Imports;

use App\Models\Directed;
use App\Models\Topic;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Exception;

class DirectedsImport implements ToCollection, WithHeadingRow
{

    public function collection(Collection $rows)
    {
        try {
            foreach ($rows as $row)
            {
                $topicID= Topic::where('name', $rows['0']['topic'])->first()->id;
                $directed = new Directed();
                $directed->sentence = $row['sentence'];
                $directed->topic_id = $topicID;
                $directed->english = $row['english'];
                $directed->save();
            }
        }catch (Exception $e) {
            //throw new \Exception("error".$e->getMessage());
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

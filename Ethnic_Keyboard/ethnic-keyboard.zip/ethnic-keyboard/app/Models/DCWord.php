<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class DCWord extends Model
{
    use HasFactory,LogsActivity;

    protected static $logAttributes =['id', 'data_collection_id', 'topic_word_id'];


    public function topicWord(){
        return $this->belongsTo(Topic_word::class, 'topic_word_id');
    }

    public function collection(){
        return $this->belongsTo(DataCollection::class, 'data_collection_id');
    }

    public function dcWordCollection()
    {
        return $this->hasOne(DCWordCollection::class,  'd_c_word_id');
    }
}

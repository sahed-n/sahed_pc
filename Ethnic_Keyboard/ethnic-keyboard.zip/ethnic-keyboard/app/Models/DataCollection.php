<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class DataCollection extends Model
{
    use HasFactory, LogsActivity;
    protected static $logAttributes =['id', 'type_id', 'task_assign_id','language_id','district_id', 'collector_id', 'speaker_id'];
    protected static $logFillable = true;

    public function speaker(){
        return $this->belongsTo(Speaker::class, 'speaker_id');
    }

    public function collector(){
        return $this->belongsTo(User::class, 'collector_id');
    }

    public function taskAssign(){
        return $this->belongsTo(TaskAssign::class, 'task_assign_id');
    }

    public function language(){
        return $this->belongsTo(Language::class, 'language_id');
    }

    public function tests(){
        return $this->hasMany(TaskAssign::class, 'task_assign_id');
    }

    public function district(){
        return $this->belongsTo(District::class, 'district_id');
    }
    public function dcWord(){
        return $this->hasOne(DCWord::class, 'data_collection_id', 'id');
    }

    public function dcDirected(){
        return $this->hasOne(DCDirected::class, 'data_collection_id', 'id');
    }
    public function dcSpontaneous(){
        return $this->hasOne(DCSpontaneous::class, 'data_collection_id', 'id');
    }

    public function dcSpontaneousCustom(){
        return $this->hasMany(DCSpontaneous::class, 'data_collection_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class DCWordCollection extends Model
{

    use HasFactory, LogsActivity;

    protected static $logAttributes =['id', 'audio','audio_duration', 'd_c_word_id', 'word_id'];


    public function word(){
        return $this->belongsTo(Word::class, 'word_id');
    }

    public function dcWord(){
        return $this->belongsTo(DCWord::class, 'd_c_word_id');
    }


    public function validator(){
        return $this->belongsTo(Speaker::class, 'validator_id');
    }
}

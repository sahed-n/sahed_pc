<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
class TaskAssign extends Model
{
    use HasFactory, LogsActivity;

    protected static $logAttributes = ['id','group_id','user_id','language_id','start_date', 'end_date', 'created_by', 'updated_by','created_at', 'updated_at'];

    public function getDescriptionForEvent(string $eventName): string
    {
        return "You Have {$eventName} Task Assign";
    }
    public function topics(){
        return $this->belongsToMany(Topic::class, 'directed_task_assigns',
            'task_assign_id', 'topic_id');
    }
    public function topicWords(){
        return $this->belongsToMany(Topic_word::class, 'word_task_assigns',
            'task_assign_id', 'topic_word_id');
    }
    public function spontaneouses(){
        return $this->belongsToMany(Spontaneous::class, 'spontaneous_task_assigns',
            'task_assign_id', 'spontaneous_id');
    }

    public function group(){
        return $this->belongsTo(Group::class, 'group_id');
    }
    public function collector(){
        return $this->belongsTo(User::class, 'user_id');
    }

    public function language(){
        return $this->belongsTo(Language::class, 'language_id');
    }

    public function district(){
        return $this->belongsTo(District::class, 'district_id');
    }
    public function upazila(){
        return $this->belongsTo(Upazila::class, 'upazila_id');
    }
    public function union(){
        return $this->belongsTo(Union::class, 'union_id');
    }

    public function collections(){
        return $this->hasMany(DataCollection::class);
    }
    public function audios(){
        return $this->hasMany(DCDirectedSentence::class);
    }

    public function directedTasks(){

        return $this->hasMany(DirectedTaskAssign::class);
    }
    public function directedTaskSentence(){
        return $this->hasMany(DirectedTaskAssign::class, 'task_assign_id')
            ->with(['topic'=> function ($query){
                $query->withCount('directeds');
            },]);
    }

    public function wordTaskSentence(){
        return $this->hasMany(WordTaskAssign::class, 'task_assign_id')
            ->with(['topicWord'=> function ($query){
                $query->withCount('words');
            },]);
    }

    public function spontaneousTaskTrims(){
        return $this->hasManyThrough(DCSpontaneous::class, DataCollection::class,'task_assign_id', 'data_collection_id')
            ->where('type_id', 2)
            ->withCount( ['trimAudios as trim_count']);
    }

    public function WordTasks(){

        return $this->hasMany(WordTaskAssign::class);
    }

    public function spontaneousTasks(){
        return $this->hasMany(SpontaneousTaskAssign::class);
    }
    public function speakers(){
        return $this->hasMany(Speaker::class, 'task_assign_id')->where('type', 0)
            ->latest();
    }

    public function linguistAssign(){
        return $this->hasMany(LinguistTaskAssign::class);
    }
    public function validatorAssign(){
        return $this->hasMany(ValidatorTaskAssign::class);
    }

    public function validators(){
        return $this->hasMany(Speaker::class, 'task_assign_id')->where('type', 1)
            ->latest();
    }
    // directed collection language_id and task_assign_id
    public function directedCollections(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 1)
            ->groupBy('language_id');
    }

   /* public function directedAudios(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 1)
            ->whereHas('dcDirected', function ($query) {
                $query->withSum('dcSentence', 'audio_duration');
            });
//            ->groupBy('language_id');
    }*/

    public function wordCollections(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 0)
            ->groupBy('language_id');
    }

    public function spontaneousCollections(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 2)
            ->groupBy('language_id');
    }

    public function validatedDirected(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 1)
            ->whereHas('dcDirected.dcSentence', function ($query) {
                $query->whereNotNull('validator_id');
            })
            ->groupBy('language_id');
    }

    public function validatedWord(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 0)
            ->whereHas('dcWord.dcWordCollection', function ($query) {
                $query->whereNotNull('validator_id');
            })
            ->groupBy('language_id');
    }

  /*    public function validatedSpontaneousTrims(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 2)
            ->withCount(['dcSpontaneous.trimAudios'=> function ($query) {
                $query->whereNotNull('validator_id');
            },])
            ->groupBy('language_id');
    }*/

    public function validatedSpontaneousTrims(){
        return $this->hasManyThrough(DCSpontaneous::class, DataCollection::class,'task_assign_id', 'data_collection_id')
            ->where('type_id', 2)
            ->withCount( ['trimAudios as validated_count' => function ($query) {
                $query->whereNotNull('validator_id');
            },]);
            //->groupBy('language_id');
    }


    public function approveddDirected(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 1)
            ->whereHas('dcDirected.dcSentence', function ($query) {
                $query->where('status', 1);
            })
            ->groupBy('language_id');
    }

    public function approvedWord(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 0)
            ->whereHas('dcWord.dcWordCollection', function ($query) {
                $query->where('status', 1);
            })
            ->groupBy('language_id');
    }

    /*public function approvedSpontaneousTrims(){
        return $this->hasMany(DataCollection::class,'task_assign_id')
            ->where('type_id', 2)
            ->with('dcSpontaneous.trimAudios', function ($query) {
                $query->where('status', 3);
            })
            ->groupBy('language_id');
    }*/

    public function approvedSpontaneousTrims(){
        return $this->hasManyThrough(DCSpontaneous::class, DataCollection::class,'task_assign_id', 'data_collection_id')
            ->where('type_id', 2)
            ->withCount( ['trimAudios as approved_count' => function ($query) {
                $query->where('status', 3);
            },]);
            //->groupBy('language_id');
    }

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class Topic_word extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable=['name'];

    protected static $logAttributes = ['id','name'];

    public function getDescriptionForEvent(string $eventName): string
    {
        return "You Have {$eventName} Word Topic";
    }

    public function words(){

        return $this->hasMany(Word::class, 'topic_word_id');
    }

    public function topicWordAssignLanguage(){
        return $this->hasMany(WordLanguage::class, 'topic_word_id');
    }

    public static function boot() {
        parent::boot();

        static::updating(function($model)
        {
            $model->updated_by = isset(auth()->user()->id) ? auth()->user()->id  : 0;
        });

        static::creating(function($model)
        {
            $model->created_by = isset(auth()->user()->id) ? auth()->user()->id  : 0;
            $model->updated_by = 0;
        });
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class DCDirectedSentence extends Model
{
    use HasFactory, LogsActivity;

    protected static $logAttributes =['id', 'audio', 'audio_duration', 'd_c_directed_id','directed_id'];


    public function directed(){
        return $this->belongsTo(Directed::class, 'directed_id');
    }

    public function dcDirected(){
        return $this->belongsTo(DCDirected::class, 'd_c_directed_id');
    }


    public function validator(){
        return $this->belongsTo(User::class, 'validator_id');
    }

    public function linguest(){
        return $this->belongsTo(User::class, 'approved_by');
    }

}

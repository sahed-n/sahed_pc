<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class WordTaskAssign extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = ['task_assign_id', 'user_id','topic_word_id', 'created_by', 'updated_by'];

    protected static $logAttributes = ['id','task_assign_id', 'user_id','topic_word_id', 'created_by', 'updated_by'];

    public function getDescriptionForEvent(string $eventName): string
    {
        return "You Have {$eventName} Word Task Assign";
    }

    public function topicWord(){
        return $this->belongsTo(Topic_word::class , 'topic_word_id');
    }

    public function taskAssign(){
        return $this->belongsTo(TaskAssign::class, 'task_assign_id');
    }

    public function collector(){
        return $this->belongsTo(User::class, 'user_id');
}
}

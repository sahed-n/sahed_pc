<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;
class Directed extends Model
{
    use HasFactory,LogsActivity;


    protected $fillable =['sentence', 'topic_id', 'created_by', 'updated_by'];

    protected static $logAttributes = ['id','sentence','english', 'topic_id', 'created_by', 'updated_by'];

    public function getDescriptionForEvent(string $eventName): string
    {
        return "You Have {$eventName} Directed";
    }

    public function topics(){
        return $this->belongsTo(Topic::class, 'topic_id');
    }
//    custom test
    public function dcSentence()
    {
        return $this->hasOne(DCDirectedSentence::class,  'directed_id');
    }


    public static function boot() {
        parent::boot();

        static::updating(function($model)
        {
            $model->updated_by = isset(auth()->user()->id) ? auth()->user()->id  : 0;
        });

        static::creating(function($model)
        {
            $model->created_by = isset(auth()->user()->id) ? auth()->user()->id  : 0;
            $model->updated_by = 0;
        });
    }
}

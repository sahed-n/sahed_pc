<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class WordLanguage extends Model
{
    use HasFactory, LogsActivity;

    protected $table = 'word_languages';

    protected $fillable = ['topic_word_id', 'language_id', 'created_by', 'updated_by'];

    protected static $logAttributes =['id','topic_word_id', 'language_id', 'created_by', 'updated_by'];

    public function getDescriptionForEvent(string $eventName): string
    {
        return "You Have {$eventName} Word Language";
    }

    public function topicsWord(){
        return $this->belongsTo(Topic_word::class, 'topic_word_id');
    }

    public function language(){
        return $this->belongsTo(Language::class, 'language_id');
    }
}

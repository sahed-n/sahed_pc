<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\Traits\LogsActivity;

class DCSpontaneous extends Model
{
    use HasFactory, LogsActivity;

    protected static $logAttributes =['id', 'audio', 'audio_duration', 'data_collection_id','spontaneous_id'];


    public function spontaneous(){
        return $this->belongsTo(Spontaneous::class, 'spontaneous_id');
    }

    public function collection(){
        return $this->belongsTo(DataCollection::class, 'data_collection_id');
    }

    public function validator(){
        return $this->belongsTo(Speaker::class, 'validator_id');
    }

    public function audioTrim(){
        return $this->hasOne(AudioTrim::class, 'd_c_spontaneouses_id', 'id');
    }

    public function trimAudios(){
        return $this->hasMany(AudioTrim::class, 'd_c_spontaneouses_id', 'id');
    }


}

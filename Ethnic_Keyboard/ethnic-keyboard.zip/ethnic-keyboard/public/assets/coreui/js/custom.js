$(document).ready(function() {
    var table = $('#ethnic-dataTable').DataTable({
        "ordering": false,
        "stateSave": true,
        /*"pageLength": 2,*/
    });
    // audio player view
    $('.myLink').trigger('click');
    /*$('a[data-dt-idx]').addClass('clicked-once');
    $('a[data-dt-idx="1"]').removeClass('clicked-once');*/

    $('[data-toggle="tooltip"]').tooltip();

} );

// sentense tooltip
$(document).on("click", ".page-link", function(e) {
    /*var ID =  $(this).data('dt-idx');
    ID = ID+1
    if($(this).hasClass('clicked-once')){
        $('.myLink').trigger('click');
        $('a[data-dt-idx="'+ID+'"]').addClass('clicked-once');
    } else {
        // $('a[data-dt-idx="'+ID+'"]').addClass('clicked-once');
        /!*setTimeout(function() {
            $('.myLink').trigger('click');
        }, 1000);*!/
    }*/
    if($('.myLink').length){
        window.location.reload(function (){
            $('.myLink').trigger('click');
            });
    }
});

function waveSurferView(data ){
   // var baseUrl = {!! json_encode(url('/')) !!}+ '/';
    var baseUrl = window.location.origin+'/';
    let audioPath = baseUrl+data.audio;
    //let uniqueCode= data.audio.split('/').pop().slice('0', -4);
    let uniqueCode = data.audio.split('/').pop().slice(0, -4).replace('.', '');


    var buttons = {play: document.getElementById("play-pause"+uniqueCode)};

    var Spectrum = WaveSurfer.create({
        container: '#waveform'+uniqueCode,
        waveColor: '#8eea8e',
        progressColor: "#CACACA",
        height: '60',
    });

    Spectrum.on('ready', function() {
        buttons.play.addEventListener("click", function(){
            if(buttons.play.value === "Play"){
                buttons.play.value = "Pause";
                Spectrum.play();
            }else{
                buttons.play.value= "Play";
                Spectrum.pause();
            }
        }, false);
    });

    Spectrum.load(audioPath);

    Spectrum.on('ready', updateTimer)
    Spectrum.on('audioprocess', updateTimer)
    Spectrum.on('seek', updateTimer)

    function updateTimer() {
        var formattedTime = secondsToTimestamp(Spectrum.getCurrentTime());
        $('#waveform-time-indicator .time'+uniqueCode).text(formattedTime);
    }

    function secondsToTimestamp(seconds) {
        seconds = Math.floor(seconds);
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds - (h * 3600)) / 60);
        var s = seconds - (h * 3600) - (m * 60);

        h = h < 10 ? '0' + h : h;
        m = m < 10 ? '0' + m : m;
        s = s < 10 ? '0' + s : s;
        return h + ':' + m + ':' + s;
    }

    Spectrum.on('ready', function () {
        var formattedTime = secondsToTimestamp(Spectrum.getDuration());
        $('#waveform-time-indicator .time'+uniqueCode).text(formattedTime);
    });

}

// singe page WaveSurfer view
document.addEventListener('DOMContentLoaded', function () {
    var baseUrl = window.location.origin+'/';
    var filePath = $('#audio').val();
    if (filePath == '') {
        var filePath = $('#audio-exist').val();
    }
    let audioPath = baseUrl+filePath;
    var buttons = {
        play: document.getElementById("btn-play"),
        pause: document.getElementById("btn-pause"),
        stop: document.getElementById("btn-stop")
    };
    // alert(filePath)
   if (filePath != undefined) {
       var Spectrum = WaveSurfer.create({
           container: '#wavetrim',
           waveColor: '#8eea8e',
           progressColor: "#CACACA",
           height: '55',
       });


       Spectrum.on('ready', function() {
           buttons.play.addEventListener("click", function(){
               if(buttons.play.value === "Play"){
                   buttons.play.value = "Pause";
                   Spectrum.play();
               }else{
                   buttons.play.value= "Play";
                   Spectrum.pause();
               }
           }, false);
       });

       Spectrum.load(audioPath);

       Spectrum.on('ready', updateTimer)
       Spectrum.on('audioprocess', updateTimer)
       Spectrum.on('seek', updateTimer)

       function updateTimer() {
           var formattedTime = secondsToTimestamp(Spectrum.getCurrentTime());
           $('#waveform-time-indicator .time').text(formattedTime);
       }

       function secondsToTimestamp(seconds) {
           seconds = Math.floor(seconds);
           var h = Math.floor(seconds / 3600);
           var m = Math.floor((seconds - (h * 3600)) / 60);
           var s = seconds - (h * 3600) - (m * 60);

           h = h < 10 ? '0' + h : h;
           m = m < 10 ? '0' + m : m;
           s = s < 10 ? '0' + s : s;
           return h + ':' + m + ':' + s;
       }
       Spectrum.on('ready', function () {
           var formattedTime = secondsToTimestamp(Spectrum.getDuration());
           $('#waveform-time-indicator .time').text(formattedTime);
       });
   }


});

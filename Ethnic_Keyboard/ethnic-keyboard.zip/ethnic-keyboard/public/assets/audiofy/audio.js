
function formatTimeCallback(seconds, pxPerSec) {
    seconds = Number(seconds);
    var minutes = Math.floor(seconds / 60);
    seconds = seconds % 60;

    // fill up seconds with zeroes
    var secondsStr = Math.round(seconds).toString();
    if (pxPerSec >= 25 * 10) {
        secondsStr = seconds.toFixed(2);
    } else if (pxPerSec >= 25 * 1) {
        secondsStr = seconds.toFixed(1);
    }

    if (minutes > 0) {
        if (seconds < 10) {
            secondsStr = '0' + secondsStr;
        }
        return `${minutes}:${secondsStr}`;
    }
    return secondsStr;
}


function timeInterval(pxPerSec) {
    var retval = 1;
    if (pxPerSec >= 25 * 100) {
        retval = 0.01;
    } else if (pxPerSec >= 25 * 40) {
        retval = 0.025;
    } else if (pxPerSec >= 25 * 10) {
        retval = 0.1;
    } else if (pxPerSec >= 25 * 4) {
        retval = 0.25;
    } else if (pxPerSec >= 25) {
        retval = 1;
    } else if (pxPerSec * 5 >= 25) {
        retval = 5;
    } else if (pxPerSec * 15 >= 25) {
        retval = 15;
    } else {
        retval = Math.ceil(0.5 / pxPerSec) * 60;
    }
    return retval;
}


function primaryLabelInterval(pxPerSec) {
    var retval = 1;
    if (pxPerSec >= 25 * 100) {
        retval = 10;
    } else if (pxPerSec >= 25 * 40) {
        retval = 4;
    } else if (pxPerSec >= 25 * 10) {
        retval = 10;
    } else if (pxPerSec >= 25 * 4) {
        retval = 4;
    } else if (pxPerSec >= 25) {
        retval = 1;
    } else if (pxPerSec * 5 >= 25) {
        retval = 5;
    } else if (pxPerSec * 15 >= 25) {
        retval = 15;
    } else {
        retval = Math.ceil(0.5 / pxPerSec) * 60;
    }
    return retval;
}

function secondaryLabelInterval(pxPerSec) {
    // draw one every 10s as an example
    return Math.floor(10 / timeInterval(pxPerSec));
}

async function readAndDecodeAudio() {
    arrBuffer = null;
    audioBuffer = null;

    //Read the original Audio
    await readAudio(audioFile)
        .then((results) => {
            arrBuffer = results.result;
        })
        .catch((error) => {
            window.alert("Some Error occured");
            return;
        });

    //Decode the original Audio into audioBuffer
    await new AudioContext().decodeAudioData(arrBuffer)
        .then((res) => {
            audioBuffer = res;
            console.log(audioBuffer);
        })
        .catch((err) => {
            window.alert("Can't decode Audio");
            return;
        });
}

async function trimAudio(region) {
    //Create empty buffer and then put the slice of audioBuffer i.e wanted part
    var regionDuration = region.end - region.start;
    var startPoint = Math.floor((region.start*audioBuffer.length)/totalAudioDuration);
    var endPoint = Math.ceil((region.end*audioBuffer.length)/totalAudioDuration);
    var audioLength = endPoint - startPoint;

    var trimmedAudio = new AudioContext().createBuffer(
        audioBuffer.numberOfChannels,
        audioLength,
        audioBuffer.sampleRate
    );

    for(var i=0;i<audioBuffer.numberOfChannels;i++){
        trimmedAudio.copyToChannel(audioBuffer.getChannelData(i).slice(startPoint,endPoint),i);
    }

    var audioData = {
        channels: Array.apply(null,{length: trimmedAudio.numberOfChannels})
            .map(function(currentElement, index) {
                return trimmedAudio.getChannelData(index);
            }),
        sampleRate: trimmedAudio.sampleRate,
        length: trimmedAudio.length,
    }

    var temp = null;
    await encodeAudioBufferLame(audioData)
        .then((res) => {
            console.log(res);

        })
        .catch((c) => {
            console.log(c);
        });
    console.log(audioData);
}

async function mergeAudio(audioList) {
    console.log(audioList);
    var trackDetails = new Array();
    var channelLength = 0;
    for( var i in audioList) {
        var regionDuration = audioList[i].end - audioList[i].start;
        var startPoint = Math.floor((audioList[i].start*audioBuffer.length)/totalAudioDuration);
        var endPoint = Math.ceil((audioList[i].end*audioBuffer.length)/totalAudioDuration);
        var audioLength = endPoint - startPoint;
        channelLength = channelLength + audioLength;

        var trackDetail = {
            'regionDuration': regionDuration,
            'startPoint': startPoint,
            'endPoint': endPoint,
            'audioLength': audioLength
        }
        trackDetails.push(trackDetail);
    }

    var mergedAudio = new AudioContext().createBuffer(
        audioBuffer.numberOfChannels,
        channelLength,
        audioBuffer.sampleRate
    );

    var channelData = (audioBuffer.numberOfChannels === 1 ?
        new Array(new Float32Array(channelLength)) :
        new Array(new Float32Array(channelLength), new Float32Array(channelLength)));

    for(var i=0;i<audioBuffer.numberOfChannels;i++) {
        var startLength = 0;
        for(var j in trackDetails) {
            channelData[i].set(audioBuffer.getChannelData(i).slice(
                trackDetails[j]["startPoint"], trackDetails[j]["endPoint"]), startLength);
            startLength = trackDetails[j]["audioLength"];
        }
    }

    for(var i=0; i<audioBuffer.numberOfChannels; i++) {
        mergedAudio.copyToChannel(channelData[i], i)
    }

    var audioData = {
        channels: Array.apply(null,{length: mergedAudio.numberOfChannels})
            .map(function(currentElement, index) {
                return mergedAudio.getChannelData(index);
            }),
        sampleRate: mergedAudio.sampleRate,
        length: mergedAudio.length,
    }

    var temp = null;
    await encodeAudioBufferLame(audioData)
        .then((res) => {
            console.log(res)
            document.getElementById("merged-track").src = processedAudio.src;
        })
        .catch((c) => {
            console.log(c)
        });
    console.log(audioData);
}

function encodeAudioBufferLame( audioData ) {
    return new Promise( (resolve, reject) => {
        var worker = new Worker('/assets/audiofy/worker/worker.js');

        worker.onmessage = (event) => {
            console.log(event.data);
            if(event.data != null){
                resolve(event.data);
            }
            else{
                reject("Error");
            }
            var blob = new Blob(event.data.res, {type: 'audio/mp3'});
            processedAudio = new window.Audio();
            processedAudio.src = URL.createObjectURL(blob);
            console.log(blob);
            downloadAudio(blob);
        };

        worker.postMessage({'audioData': audioData});
    });
}

function readAudio(file) {
    return new Promise((resolve, reject) => {
        var reader = new FileReader();
        reader.readAsArrayBuffer(file);

        //Resolve if audio gets loaded
        reader.onload = function() {
            console.log("Audio Loaded");
            resolve(reader);
        }

        reader.onerror = function(error){
            console.log("Error while reading audio");
            reject(error);
        }

        reader.onabort = function(abort){
            console.log("Aborted");
            console.log(abort);
            reject(abort);
        }

    })
}


function loadAudio(audio = null) {

    if (audio == null) {

        var element = document.getElementById("audio-file");
        if(element.files[0].type !== "audio/mpeg"){
            alert("Invalid Format");
            return;
        }
        audioFile = element.files[0];

    }else{

        audioFile = audio;

    }

    if(wavesurfer !== undefined)
        wavesurfer.destroy();
     wavesurfer = WaveSurfer.create({
        container: "#waveform",
        waveColor: '#5bd95b',
        responsive: true,
        height: 200,
        cursor: true,
        progressColor: '#3B8686',
        backend: 'MediaElement',
        /*scrollParent: true,*/
        plugins: [
            WaveSurfer.regions.create({
                dragSelection: {
                    slop: 5
                }
            }),
            WaveSurfer.timeline.create({
                container: "#wave-timeline",
                formatTimeCallback: formatTimeCallback,
                timeInterval: true,
                primaryLabelInterval: primaryLabelInterval,
                secondaryLabelInterval: secondaryLabelInterval,
                primaryColor: 'blue',
                secondaryColor: 'red',
                primaryFontColor: 'blue',
                secondaryFontColor: 'red'
            }),
            WaveSurfer.cursor.create({
                showTime: true,
                opacity: 1,
                customShowTimeStyle: {
                    'background-color': '#2da34a',
                    color: '#fff',
                    padding: '2px',
                    'font-size': '10px'
                }
            })
        ]
    });

    // Zoom slider
    let slider = document.querySelector('[data-action="zoom"]');
    slider.addEventListener('input', function() {
        wavesurfer.zoom(Number(this.value));
    });
    // set initial zoom to match slider value
    wavesurfer.zoom(slider.value);


    wavesurfer.on('ready', function() {
        readAndDecodeAudio();
        preTrimUIChanges();
        totalAudioDuration = wavesurfer.getDuration();
        document.getElementById('time-total').innerText = totalAudioDuration.toFixed(1);
        wavesurfer.enableDragSelection({});
        console.log(intro);
        if(intro != undefined) {
            intro.nextStep();
        }
    });
    wavesurfer.on('finish', setPlayButton);

    if (audio == null) {
        wavesurfer.load(URL.createObjectURL(element.files[0]));
    }else{
        wavesurfer.load(URL.createObjectURL(audio));
    }
    // End condition
    wavesurfer.on('audioprocess', function() {
        if(wavesurfer.isPlaying()) {
            var currentTime = wavesurfer.getCurrentTime();
            document.getElementById('time-current').innerText = currentTime.toFixed(1);
        }
    });
    wavesurfer.on('region-created', function(newRegion) {
        var audioTracks = document.getElementById("audio-tracks").tBodies[0];
        console.log(audioTracks.childNodes);
        var tableRow = createAudioRow(new Array(newRegion.id, newRegion.start, newRegion.end));
        audioTracks.appendChild(tableRow);
        showAndHideMergeOption();
    });
    wavesurfer.on('region-update-end', function(newRegion) {
        document.getElementById(newRegion.id+1).innerText =
            ( 0 >= newRegion.start.toFixed(4) ? 0 : newRegion.start.toFixed(4));
        document.getElementById(newRegion.id+2).innerText =
            ( wavesurfer.getDuration() <= newRegion.end ? wavesurfer.getDuration().toFixed(4) : newRegion.end.toFixed(4));
        if(intro != undefined) {
            intro.exit();
        }
    });
    var audioButtons = document.getElementById("audio-buttons");
    var audioButtonsClass = audioButtons.getAttribute("class").replace("w3-hide","w3-show");
    audioButtons.setAttribute("class",audioButtonsClass);
}

function downloadAudio(resBase64) {
    var anchorAudio = document.createElement("input");
    blobToBase64(resBase64).then(res => {
        var form_div = $('#form-hidden')
        anchorAudio.setAttribute("type", "hidden");
        anchorAudio.setAttribute("name", "trim_value");
        anchorAudio.setAttribute("id", "trim_base64");
        anchorAudio.setAttribute("value", res);
        form_div.append(anchorAudio);
       console.log(anchorAudio);
        $('.show-submit').css('display', 'block');
        $('#loader').hide();
    })

}
// function downloadAudio() {
// 	var anchorAudio = document.createElement("a");
//     anchorAudio.href = processedAudio.src;
// 	anchorAudio.download = "output.mp3";
// 	anchorAudio.click();
// 	console.log(anchorAudio);
// }
const blobToBase64 = blob => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    return new Promise(resolve => {
        reader.onloadend = () => {
            resolve(reader.result);
        };
    });
};



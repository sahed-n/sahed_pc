<?php

return [
    'bn' => [
        'display' => 'বাংলা',
        'flag-icon' => 'bn'
    ],
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us'
    ],


];


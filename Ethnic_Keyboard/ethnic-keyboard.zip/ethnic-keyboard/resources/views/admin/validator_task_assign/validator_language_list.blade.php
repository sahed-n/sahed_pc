@extends('layouts.app')

@section('title', 'ভাষা অনুসারে অর্পিত দায়িত্ব')

@section('content')
    <div class="container-fluid px-0 ">
        <div class="card mb-3 min-vh-100">
            <div class="card-header"><a class="btn btn-sm bg-success" href="{{route('admin.dashboard')}}">{{__('ড্যাশবোর্ড ফিরে যান')}}</a></div>
            <div class="card-body">
                @if(Auth::user()->hasRole(['Validator']))
                    <div class="card mb-3">
                        <div class="card-header">
                            <ul class="nav nav-pills card-header-pills justify-content-between">
                                <li class="nav-item">{{__('ভাষা অনুসারে অর্পিত দায়িত্ব')}}</li>
                            </ul>

                        </div>
                        <div class="card-body">
                            <div class="row">
                                @foreach($taskAssignByValidators as $validatorTaskAssign)
                                    <div class="col-xl-2">
                                        @php
                                            $total=0;
                                        @endphp
                                        @foreach($validatorTaskAssign->directedTasks as $t)
                                            @php
                                                $num = $t->topic->directeds_count;
                                                $total = $num + $total;
                                            @endphp
                                        @endforeach
                                        @php
                                            $totalWord=0;
                                        @endphp
                                        @foreach($validatorTaskAssign->WordTasks as $tw)
                                            @php
                                                $num = $tw->topicWord->words_count;
                                                $totalWord = $num + $totalWord;
                                            @endphp
                                        @endforeach

                                        <div class="card text-white @if($validatorTaskAssign->collections->isEmpty()) bg-danger @elseif(count($validatorTaskAssign->collections) == $total+$validatorTaskAssign->spontaneous_tasks_count ) bg-success @else bg-primary-new @endif mb-3">
                                            <div class="card-body" >
                                                <h5 class="card-title text-center">{{$validatorTaskAssign->language->name}}</h5>
                                                <h6 class="card-subtitle text-center mb-2" style="font-size: 0.8rem;">({{$validatorTaskAssign->district->name}})</h6>
                                                <h6 class="card-subtitle text-center mb-2" style="font-size: 0.7rem;">({{$validatorTaskAssign->collector->name}})</h6>
                                                <p class="card-text text-center mb-0 custom-hover">
                                                    <a class="text-white text-decoration-none" href="{{route('admin.directed.language.tasks.list', $validatorTaskAssign->id)}}">
                                                        {{__('messages.নির্দেশিত')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($validatorTaskAssign->directed_tasks_count)}})
                                                        @else
                                                            ({{$validatorTaskAssign->directed_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                                <p class="card-text text-center mb-0 custom-hover" id="scrollToDiv">
                                                    <a class="text-white text-decoration-none" href="{{route('admin.spontaneous.language.tasks.list', $validatorTaskAssign->id)}}">
                                                        {{__('messages.স্বতঃস্ফূর্ত')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($validatorTaskAssign->spontaneous_tasks_count)}})
                                                        @else
                                                            ({{$validatorTaskAssign->spontaneous_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                                <p class="card-text text-center     custom-hover">
                                                    <a class="text-white text-decoration-none" style="font-size: .9rem;" href="{{route('admin.word.language.tasks.list', $validatorTaskAssign->id)}}">
                                                        {{__('শব্দ ও ব্যাকরণ')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($validatorTaskAssign->word_tasks_count)}})
                                                        @else
                                                            ({{$validatorTaskAssign->word_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

@section('pie-chart-js')
    <script>
        /*scroll to div */
        $(document).ready(function () {
            /*collapase and expand */
            let languageCount = $('.language').length;
            if (languageCount > 6) {
                $('.language').slice(6).hide();
                $('#btn').show();
            }
            $('#btn').on('click', function () {
                $('.language').slice(6).toggle();
                if ($('#btn').text() == 'আরো দেখুন') {
                    $('#btn').text('কম দেখুন');
                } else {
                    $('#btn').text('আরো দেখুন');
                }
            });

        });
    </script>
@endsection

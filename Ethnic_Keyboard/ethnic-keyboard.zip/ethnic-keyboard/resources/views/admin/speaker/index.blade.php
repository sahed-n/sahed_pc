@extends('layouts.app')

@section('title', 'স্পিকার তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('স্পিকার')}}</li>
                    {{--@if(Auth::user()->hasRole('Data Collector'))
                        --}}{{--<li class="nav-item">
                            <button class="btn btn-sm btn-success text-white speaker-create" type="button" > {{__('messages.নতুন স্পিকার')}}</button>
                        </li>--}}{{--
                    @endif--}}
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                @if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif
                <div class="table-responsive">
                    <table class="table table-hover table-bordered"  id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">{{__('##')}}</th>
                            <th scope="col">{{__('নাম')}}</th>
                            <th scope="col">{{__('ভাষা')}}</th>
                            <th scope="col">{{__('জেলা')}}</th>
                            <th scope="col">{{__('লিঙ্গ')}}</th>
                            <th scope="col">{{__('ফোন')}}</th>
                            <th scope="col">{{__('ডাটা কালেক্টর')}}</th>
                            <th scope="col">{{__('তৈরির সময়')}}</th>
                            <th scope="col" class="text-center">{{__('পদক্ষেপ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($speakers as $speaker)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td class="align-middle">{{$speaker->name}}</td>
                                <td class="align-middle">{{ $speaker->languageDistrict->language->name??''}}</td>
                                <td class="align-middle">{{ $speaker->district->name ?? $speaker->languageDistrict->district->name}}</td>
                                @if($speaker->gender == 0)
                                    <td class="align-middle">{{__('পুরুষ')}}</td>
                                @elseif($speaker->gender == 1)
                                    <td class="align-middle">{{__('মহিলা')}}</td>
                                @else
                                    <td class="align-middle">{{__('অন্যান্য')}}</td>
                                @endif
                                <td class="align-middle"><a href="tel:{{$speaker->phone}}">{{$speaker->phone}}</a></td>
                                <td class="align-middle">{{$speaker->createdUser->name??''}}</td>
                                <td class="align-middle">{{$speaker->created_at}}</td>
                                <td class="text-center">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        <a href="javascript:void(0)" onclick="speakerShow({{$speaker->id}})" type="button" class="btn btn-success btn-sm text-white">
                                            {{__('দেখুন')}}
                                        </a>
                                        <a class="btn btn-purple btn-sm" href="{{route('admin.speakers.edit', $speaker->id)}}">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        @can('Speaker-Delete')
                                            <form action="{{ route('admin.speakers.destroy', $speaker->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-danger btn-sm">
                                                    <svg class="icon  text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                    </svg>
                                                </button>
                                            </form>
                                        @endcan
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="speakerShow" tabindex="-1" aria-labelledby="speakerTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content" id="speaker-modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{__('messages.নতুন')}}</h5>
                    <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                </div>
                <div class="modal-footer">
                    <button class="btn btn-danger btn-sm text-white" type="button" data-coreui-dismiss="modal">{{__('messages.বন্ধ করুন')}}</button>
                    <button class="btn btn-success btn-sm text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>
        function speakerShow(id){
            console.log(id);
            showUrl = "speakers/"+id;
            $.get(showUrl, function(data){
                $('#speakerShow #speaker-modal-content').html(data);
                $('#speakerShow').modal('show');
            });

        }

        // select Districts
        $('select[name="language_id"]').on('change', function() {
            var languageID = $(this).val();
            console.log(languageID);
            if(languageID) {
                $.ajax({
                    url:"{{url('admin/getDistrict')}}?language_id="+languageID,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="district"]').empty();
                        $('select[name="upazila"]').empty()
                        $('select[name="union"]').empty();
                        $('select[name="village"]').empty();
                        $('#district').append('<option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>');
                        $.each(data, function(key, value) {
                            $('select[name="district"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }else{
                $('select[name="district"]').empty()
                $('select[name="upazila"]').empty()
                $('select[name="union"]').empty();
                $('select[name="village"]').empty();
            }
        });
        $('select[name="district_id"]').on('change', function() {
            var disID = $(this).val();
            console.log(disID);
            if(disID) {
                $.ajax({
                    url:"{{url('admin/getUpazila')}}?district_id="+disID,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="upazila_id"]').empty();
                        $('#upazila_id').append('<option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>');
                        $.each(data, function(key, value) {
                            $('select[name="upazila_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }else{
                $('select[name="upazila_id"]').empty();
                $('select[name="union_id"]').empty();
            }
        });

        // select Union
        $('select[name="upazila_id"]').on('change', function() {
            var upazilaID = $(this).val();
            console.log(upazilaID);
            if(upazilaID) {
                $.ajax({
                    url: "{{url('admin/getUnion')}}?upazila_id="+upazilaID,
                    type: "GET",
                    dataType: "json",
                    success:function(data) {
                        $('select[name="union_id"]').empty();
                        $('#union_id').append('<option value="">{{__('messages.ইউনিয়ন নির্বাচন করুন')}}</option>');
                        $.each(data, function(key, value) {
                            $('select[name="union_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                        });
                    }
                });
            }else{
                $('select[name="union_id"]').empty();
            }
        });

        $('#district_id').select2({
            dropdownParent: $("#speakerForm"),
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#upazila_id').select2({
            dropdownParent: $("#speakerForm"),
            width: '100%',
            placeholder: "{{__('messages.উপজেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#union_id').select2({
            dropdownParent: $("#speakerForm"),
            width: '100%',
            placeholder: "{{__('messages.ইউনিয়ন নির্বাচন করুন')}}",
            allowClear: true
        });

    </script>
@endsection


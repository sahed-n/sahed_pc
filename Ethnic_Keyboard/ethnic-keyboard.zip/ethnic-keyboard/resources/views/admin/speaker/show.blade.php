<div class="modal-header">
    <h5 class="modal-title">{{__('স্পিকার')}}</h5>
    <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="row">

        <div class="col-md-4 col-sm-12">
            <div class="card align-items-center">
                <img class="rounded" src="{{asset($speaker->image)??''}}" width="200" height="200" alt="">
            </div>
        </div>
        <div class="col-md-8 col-sm-12">
            <div class="card">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    <tr>
                        <th>{{ __('নাম') }}</th>
                        <td>{{ $speaker->name?? ''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('ভাষা') }}</th>
                        <td>{{ $speaker->languageDistrict->language->name??''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('লিঙ্গ') }}</th>
                        <td>
                            @if($speaker->gender==0)
                                {{__('messages.পুরুষ')}}
                            @elseif($speaker->gender==1)
                                {{__('messages.মহিলা')}}
                            @else
                                {{__('messages.অন্যান্য')}}
                            @endif
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('মোবাইল') }}</th>
                        <td>{{ $speaker->phone?? ''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('ইমেইল') }}</th>
                        <td>
                            {{$speaker->email ?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('বয়স') }}</th>
                        <td>
                            {{$speaker->age ?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('পেশা') }}</th>
                        <td>
                            {{$speaker->occupation ?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('ঠিকানা') }}</th>
                        <td>
                            {{$speaker->address?? ''}}
                        </td>
                    </tr>

                    <tr>
                        <th>{{ __('সর্বোচ্চ শিক্ষা') }}</th>
                        <td>
                            {{$speaker->education?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('জেলা') }}</th>
                        <td>
                            {{$speaker->district->name?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('উপজেলা') }}</th>
                        <td>{{ $speaker->upazila->name?? '' }}</td>
                    </tr>
                    <tr>
                        <th>{{ __('ইউনিয়ন')}}</th>
                        <td>{{ $speaker->union->name??''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('গ্রাম')}}</th>
                        <td>{{ $speaker->area?? '' }}</td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button class="btn btn-danger btn-sm text-white" type="button" data-coreui-dismiss="modal">{{__('messages.বন্ধ করুন')}}</button>
</div>

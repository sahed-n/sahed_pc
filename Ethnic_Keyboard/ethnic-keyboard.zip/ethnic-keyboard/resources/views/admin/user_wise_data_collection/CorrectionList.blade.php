@extends('layouts.app')

@section('title', 'ডাটা কালেক্টর তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('messages.তথ্য সংগ্রহ')}}</li>
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 5rem;">{{__('##')}}</th>
                            <th scope="col">{{__('ভাষা')}}</th>
                            {{--<th scope="col">{{__('অবস্থান')}}</th>
                            <th scope="col">{{__('কালেক্টর')}}</th>
                            <th scope="col">{{__('স্পিকার')}}</th>--}}
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col">{{__('অডিও')}}</th>
                            <th scope="col" style="width: 14rem;">{{__('শব্দ/টপিক/বাক্য')}}</th>
                            <th scope="col">{{__('messages.কমেন্ট')}}</th>
                            <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                            <th scope="col" class="text-center">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $key=>$dataCollection)
                            <tr>
                                <td>{{$loop->iteration }}
                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous->collection->language))
                                        {{$dataCollection->dcSpontaneous->collection->language->name}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection->language->name))
                                        {{$dataCollection->dcDirected->collection->language->name}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection->language))
                                        {{$dataCollection->dcWord->collection->language->name}}
                                    @endif
                                </td>
                                {{--<td class="small">
                                    @if(isset($dataCollection->dcSpontaneous->collection->district))
                                        {{$dataCollection->dcSpontaneous->collection->district->name}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection->district))
                                        {{$dataCollection->dcDirected->collection->district->name}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection->district))
                                        {{$dataCollection->dcWord->collection->district->name}}
                                    @endif
                                </td>
                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous->collection->collector))
                                        {{$dataCollection->dcSpontaneous->collection->collector->name}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection->collector))
                                        {{$dataCollection->dcDirected->collection->collector->name}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection->collector))
                                        {{$dataCollection->dcWord->collection->collector->name}}
                                    @endif
                                </td>
                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous->collection->speaker))
                                        {{$dataCollection->dcSpontaneous->collection->speaker->name}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection->speaker))
                                        {{$dataCollection->dcDirected->collection->speaker->name}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection->speaker))
                                        {{$dataCollection->dcWord->collection->speaker->name}}
                                    @endif
                                </td>--}}
                                <td class="small collectionType">
                                    @if(isset($dataCollection->dcSpontaneous->collection))
                                        @if($dataCollection->dcSpontaneous->collection->type_id == 2)
                                            <span class="badge bg-success">{{__('স্বতঃস্ফূর্ত')}}</span>
                                        @endif
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection))
                                        @if($dataCollection->dcDirected->collection->type_id == 1)
                                            <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                                        @endif
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection))
                                        @if($dataCollection->dcWord->collection->type_id == 0)
                                            <span class="badge bg-success">{{__('শব্দ ও ব্যাকরণ')}}</span>
                                        @endif
                                    @endif
                                </td>
                                @if(isset($dataCollection))
                                    @php
                                        $audio = explode('/', $dataCollection->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 14rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif

                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous))

                                        <div class="small badge bg-primary-new" data-toggle="tooltip" data-placement="top" title="{{ __('টপিক') }}">{{$dataCollection->dcSpontaneous->spontaneous->word}}</div>
                                        <div class="small">
                                            <span class="" data-toggle="tooltip" data-placement="top" title="{{ __('ট্রিম অংশের বাংলা বাক্য') }}">{{$dataCollection->bangla}}</span>
                                        </div>
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection))
                                        {{$dataCollection->directed->sentence}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection))
                                        {{$dataCollection->word->sentence}}
                                    @endif
                                </td>
                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous))
                                        {{$dataCollection->comment}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection))
                                        {{$dataCollection->comment}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection))
                                        {{$dataCollection->comment}}
                                    @endif
                                </td>
                                @if($dataCollection->status == 2 /* && $dataCollection->approved_by != null*/)
                                    <td class="">
                                        {{--<a class="btn btn-info btn-sm text-white" href="{{ route('trim-page',['type'=>isset($dataCollection->d_c_directed_id) ? 'directed' : 'spontaneous', 'id' => $dataCollection->id]) }}">
                                            <i class="fa-solid fa-scissors"></i>
                                            {{__('messages.সংশোধন')}}
                                        </a>--}}
                                        <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                    </td>
                                @endif


                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        @if ($dataCollection->d_c_directed_id)
                                            <a class="btn btn-info btn-sm text-white" href="{{ route('admin.data_collection.redirected.topic.revert',['task_assign_id'=>$dataCollection->dcDirected->collection->task_assign_id,'topic_id'=>$dataCollection->dcDirected->topic_id,'directed_id'=>$dataCollection->directed_id]) }}">
                                                {{-- <i class="text-white far fa-eye"></i> --}}
                                                {{__('সংশোধন')}}
                                            </a>
                                        @endif
                                        @if ($dataCollection->d_c_word_id)
                                            <a class="btn btn-info btn-sm text-white" href="{{ route('admin.data_collection.redirected.word.revert',['task_assign_id'=>$dataCollection->dcWord->collection->task_assign_id,'topic_word_id'=>$dataCollection->dcWord->topic_word_id,'word_id'=>$dataCollection->word_id]) }}">
                                                {{-- <i class="text-white far fa-eye"></i> --}}
                                                {{__('সংশোধন')}}
                                            </a>
                                        @endif
                                        {{-- @if ($dataCollection->d_c_directed_id)
                                        <a class="btn btn-info btn-sm" href="{{ route('admin.data_collections.trim.show',['type'=>isset($dataCollection->d_c_directed_id) ? 'directed' : 'spontaneous', 'id' => $dataCollection->id]) }}">
                                            <i class="text-white far fa-eye"></i>
                                        </a>
                                        @endif --}}
                                        @if ($dataCollection->d_c_spontaneouses_id)
                                            <a class="btn btn-info btn-sm text-white" href="{{ route('trim-page',['type'=>'spontaneous', 'id' => $dataCollection->d_c_spontaneouses_id]) }}">
                                                {{-- <i class="text-white far fa-eye"></i> --}}
                                                {{__('সংশোধন')}}
                                            </a>
                                        @endif
                                        @if($dataCollection->d_c_directed_id)
                                            <form action="{{route('admin.collection.approve.store')}}" method="post" >
                                                @csrf
                                                <input  id="d_c_directed_sentence_id" type="hidden" name="d_c_directed_sentence_id" value="{{$dataCollection->id}}">
                                                <input  id="SendToApprove" type="hidden" name="status" value="0">
                                                <button class="btn btn-sm btn-success text-white">
                                                    <i class="fa-solid fa-paper-plane"></i>
                                                </button>
                                            </form>
                                        @endif
                                        {{-- <a class="btn btn-purple btn-sm text-white" href="{{ route('trim-page',['type'=>isset($dataCollection->d_c_directed_id) ? 'directed' : 'spontaneous', 'id' => $dataCollection->d_c_spontaneouses_id]) }}">
                                            <i class="fa-solid fa-scissors"></i>

                                        </a> --}}
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        // alertify delete notification
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });


        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }

        $('.collectionType').hover(function() {
            $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
        }, function() {
            $(this).find('.badge').addClass('bg-success').removeClass('bg-danger');
        });

    </script>

@endsection


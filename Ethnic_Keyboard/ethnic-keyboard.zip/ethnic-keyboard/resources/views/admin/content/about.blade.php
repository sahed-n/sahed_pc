@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#"></a>{{__('messages.বিজ্ঞপ্তি')}} </li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.নতুন')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                @if(Auth::user()->hasRole(['Admin','Manager']))
                    <form action="{{route('admin.about.store')}}" method="post">
                    @csrf
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="row ">
                                <label class="" for="description" >{{__('বিবরণ')}}</label>
                                <div class="input-group">
                                    <textarea class="form-control @error('description') is-invalid @enderror" name="description" id="description" cols="30" rows="10"  placeholder="{{__('বিবরণ')}}">{!!@$about->description!!}</textarea>
                                    @error('description')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="text-end">
                                    <button class="btn btn-success text-white" type="submit">{{__('জমা দিন')}}</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                @else

                    <div class="row">
                        <div class="col-md-10 col-sm-12 offset-1 off">
                            <div class="row ">
                                <div class="input-group">
                                    {!!@$about->description!!}
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
@section('language-filter-js')
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'description' );
        CKEDITOR.config.width = '100%';
    </script>
@endsection

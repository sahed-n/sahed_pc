@extends('layouts.app')
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{route('admin.dashboard')}}">{{__('ড্যাশবোর্ড')}}</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">{{@$languageByTasks['language']}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <table class="table table-bordered table-hover table-responsive" id="languageByCollection">
                            <thead class="table-info">
                            <tr>
                                <th scope="col">{{ __('ক্রমিক') }}</th>
                                <th scope="col">{{ __('টপিক/বাক্য') }}</th>
                                <th> {{__('সংগৃহীত')}}</th>
                                <th>{{__('যাচাইকৃত')}}</th>
                                <th>{{__('অনুমোদিত')}}</th>
                                <th>{{__('মোট সংগ্রহ')}}</th>
                                <th>{{__('মোট যাচাইকৃত')}}</th>
                                <th>{{__('মোট অনুমোদিত')}}</th>
                                <th>{{__('পদক্ষেপ')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-success text-hover me-4">
                                            {{ __('নির্দেশিত') }}:
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            {{ __('টপিক') }}: {{@$languageByTasks['directedTasksCount']}}
                                        </span>
                                        <span class="badge bg-info-new text-hover">
                                            {{__('বাংলা বাক্য')}}: {{@$languageByTasks['directedsCount']}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            {{ __('টপিক') }}: {{@$languageByTasks['dcTopicCollectionCount']}}
                                        </span>
                                        <span class="badge bg-info-new text-hover">
                                            @if(@$languageByTasks['directedCollections'] > @$languageByTasks['directedsCount'])
                                                {{__('বাংলা বাক্য')}}: {{@$languageByTasks['directedsCount']}}
                                            @else
                                                {{__('বাংলা বাক্য')}}: {{@$languageByTasks['directedCollections']}}
                                            @endif
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                             {{__('বাংলা বাক্য')}}: {{@$languageByTasks['validatedDirected']}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                             {{__('বাংলা বাক্য')}}: {{@$languageByTasks['approveddDirected']}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                             @php
                                                 $seconds= round(@$languageByTasks['directedAudios'], 2);
                                                 $directed_minutes = floor($seconds / 60);
                                                 $directed_seconds = $seconds % 60;

                                             @endphp
                                            {{ (int)$directed_minutes }} {{__('মি.')}} {{ (int)$directed_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                                @php
                                                    $seconds= round(@$languageByTasks['totalDirectedValidate'], 2);
                                                    $directed_minutes = floor($seconds / 60);
                                                    $directed_seconds = $seconds % 60;

                                                @endphp
                                                {{ (int)$directed_minutes }} {{__('মি.')}} {{ (int)$directed_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['totalDirectedApprove'], 2);
                                                $directed_minutes = floor($seconds / 60);
                                                $directed_seconds = $seconds % 60;
                                                @endphp
                                            {{ (int)$directed_minutes }} {{__('মি.')}} {{ (int)$directed_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <a class="btn btn-info btn-sm" href="{{route('admin.language-directed-collections',@$languageByTasks['languageID'] )}}">
                                        <i class="text-white fa fa-tasks"></i>
                                    </a>
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-success text-hover">
                                            {{__('শব্দ ও ব্যাকরণ')}}:
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            {{ __('টপিক') }}: {{@$languageByTasks['wordTasksCount']}}
                                        </span>
                                        <span class="badge bg-info-new text-hover">
                                            {{__('বাংলা বাক্য')}}: {{@$languageByTasks['wordsCount']}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            {{ __('টপিক') }}: {{@$languageByTasks['wordTopicCollectionCount']}}
                                        </span>
                                        <span class="badge bg-info-new text-hover">
                                            @if(@$languageByTasks['wordCollections'] > @$languageByTasks['wordsCount'])
                                                {{__('বাংলা বাক্য')}}: {{@$languageByTasks['wordsCount']}}
                                            @else
                                                {{__('বাংলা বাক্য')}}: {{@$languageByTasks['wordCollections']}}
                                            @endif
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover"> {{__('বাংলা বাক্য')}}:{{@$languageByTasks['validatedWord']}}</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover"> {{__('বাংলা বাক্য')}}: {{@$languageByTasks['approvedWord']}}</span>
                                    </div>

                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                         <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['wordAudios'], 2);
                                                $spontaneous_minutes = floor($seconds / 60);
                                                $spontaneous_seconds = $seconds % 60;

                                            @endphp
                                             {{ (int)$spontaneous_minutes??0 }} {{__('মি.')}} {{ (int)$spontaneous_seconds??0 }} {{__('সে.')}}
                                        </span>

                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['totalWordValidate'], 2);
                                                $word_minutes = floor($seconds / 60);
                                                $word_seconds = $seconds % 60;

                                            @endphp
                                            {{ (int)$word_minutes }} {{__('মি.')}} {{ (int)$word_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['totalWordApprove'], 2);
                                                $word_minutes = floor($seconds / 60);
                                                $word_seconds = $seconds % 60;
                                            @endphp
                                            {{ (int)$word_minutes }} {{__('মি.')}} {{ (int)$word_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <a class="btn btn-info btn-sm" href="{{route('admin.language-word-collections',@$languageByTasks['languageID'] )}}">
                                        <i class="text-white fa fa-tasks"></i>
                                    </a>
                                </td>

                            </tr>
                            <tr>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-success text-hover  me-4">
                                            {{__('স্বতঃস্ফূর্ত')}}:
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            {{ __('টপিক') }}: {{@$languageByTasks['spontaneousTasksCount']}}
                                        </span>
                                    </div>
                                </td>
                                <td>

                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover"> {{ __('টপিক') }}: {{@$languageByTasks['spontaneousCollections']}}</span>
                                        <span class="badge bg-info-new text-hover">{{ __('ট্রিম') }}: {{@$languageByTasks['trim_count']}}</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover"> {{__('ট্রিমিং')}}: {{@$languageByTasks['validatedSpontaneous']}}</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">{{__('ট্রিমিং')}}: {{@$languageByTasks['approvedSpontaneous']}}</span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                        @php
                                            $seconds= round(@$languageByTasks['spontaneousAudios'], 2);
                                            $word_minutes = floor($seconds / 60);
                                            $word_seconds = $seconds % 60;

                                        @endphp
                                            {{ (int)$word_minutes }} {{__('মি.')}} {{ (int)$word_seconds }} {{__('সে.')}}
                                        </span>
                                        <span class="badge bg-info-new text-hover">
                                             @php
                                                 $seconds= round(@$languageByTasks['spontaneousTrims'], 2);
                                                 $word_minutes = floor($seconds / 60);
                                                 $word_seconds = $seconds % 60;

                                             @endphp
                                            {{ (int)$word_minutes }} {{__('মি.')}} {{ (int)$word_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['totalSpontValidate'], 2);
                                                $spontaneous_minutes = floor($seconds / 60);
                                                $spontaneous_seconds = $seconds % 60;
                                            @endphp
                                            {{ (int)$spontaneous_minutes }} {{__('মি.')}} {{ (int)$spontaneous_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>

                                <td>
                                    <div class="text-medium-emphasis">
                                        <span class="badge bg-info-new text-hover">
                                            @php
                                                $seconds= round(@$languageByTasks['totalSpontApprove'], 2);
                                                $spontaneous_minutes = floor($seconds / 60);
                                                $spontaneous_seconds = $seconds % 60;
                                            @endphp
                                            {{ (int)$spontaneous_minutes }} {{__('মি.')}} {{ (int)$spontaneous_seconds }} {{__('সে.')}}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <a class="btn btn-info btn-sm" href="{{route('admin.language-spontaneous-collections',@$languageByTasks['languageID'] )}}">
                                        <i class="text-white fa fa-tasks"></i>
                                    </a>
                                </td>

                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection
@section('language-js')
    <script>
        // datatable and print
        $(document).ready(function () {
            $('#languageByCollection').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend:'print',
                        title: '{{@$languageByTasks['language']}}',
                    }
                ]
            });
        });

    </script>
@endsection

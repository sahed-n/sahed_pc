@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.language_assigns.index')}}">{{__('টপিক বিষয়ের তালিকা')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.এডিট')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                {{--@if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif--}}
                {{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}
                <form action="{{route('admin.language_assigns.update', $languageAssign->id)}}" method="post">
                    @csrf
                    @method("PUT")
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <div class="row mb-3">
                                <label  for="language_id">{{__('messages.ভাষার নাম')}}</label>
                                <div class=" input-group">
                                    <select class="form-select @error('language_id') is-invalid @enderror" id="language_id" name="language_id">
                                        <option value="{{$languageAssign->id}}" selected>{{$languageAssign->name}}</option>
                                    </select>
                                    @error('language_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-4 col-sm-12" id="scroll-word">
                            <div class=" input-group" >
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="word" id="word" type="checkbox" onclick="checkAll(document.getElementsByClassName('word'),this)">
                                    <label class="form-check-label" for="word"><strong>{{__('শব্দ ও ব্যাকরণ')}}</strong></label>
                                </div>
                            </div>
                            <div class="row mb-3" style="height: 400px; position:relative;">
                                <div class=" input-group word" style="position:absolute; max-height:100%;overflow:auto;">
                                    <table class="table table-bordered table-hover table-striped table-responsive">
                                        <tbody>
                                        @foreach($wordTopics as $key => $wordTopic)
                                            <tr>
                                                <td>
                                                    <div class="form-check form-check-inline">
                                                        {{ Form::checkbox('topic_word[]', $key, in_array($key, $wordAssign) ? true : false, array('class' => 'form-check-input')) }}
                                                        <label class="form-check-label" for="topic_word"><small>{{ $wordTopic }}</small></label>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    @error('topic_word')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12" id="scroll-directed">
                            <div class=" input-group" >
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="directed" id="directed" type="checkbox" onclick="checkAll(document.getElementsByClassName('directed'),this)">
                                    <label class="form-check-label" for="directed"><strong>{{__('messages.নির্দেশিত')}}</strong></label>
                                </div>
                            </div>
                            <div class="row mb-3" style="height: 400px; position:relative;">

                                <div class=" input-group directed" style="position:absolute; max-height:100%;overflow:auto;">
                                    <table class="table table-bordered table-hover table-striped table-responsive">
                                        <tbody>
                                        @foreach($directedTopics as $key => $directedTopic)
                                            <tr>
                                                <td>
                                                    <div class="form-check form-check-inline">
                                                        {{ Form::checkbox('topic[]', $key, in_array($key, $directedAssign) ? true : false, array('class' => 'form-check-input')) }}
                                                        <label class="form-check-label" for="topic"><small>{{ $directedTopic }}</small></label>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                    @error('topic')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12" id="scroll-spontaneous">
                            <div class=" input-group" >
                                <div class="form-check form-check-inline" >
                                    <input class="form-check-input" name="spontaneous" id="spontaneous" type="checkbox" onclick="checkAll(document.getElementsByClassName('spontaneous'),this)">
                                    <label class="form-check-label" for="spontaneous"><strong>{{__('messages.স্বতঃস্ফূর্ত')}}</strong></label>
                                </div>
                            </div>
                            <div class="row mb-3" style="height: 400px; position:relative;">
                                <div class=" input-group spontaneous" style="position:absolute; max-height:100%;overflow:auto;">
                                    <table class="table table-bordered table-hover table-striped table-responsive">
                                        <tbody>
                                        @foreach($spontaneouses as $key =>$spontaneous)
                                            <tr>
                                                <td>
                                                    <div class="form-check form-check-inline" >
                                                        {{ Form::checkbox('spontaneous[]', $key, in_array($key, $spontaneousesAssign) ? true : false, array('class' => 'form-check-input')) }}
                                                        <label class="form-check-label" for="spontaneous"><small>{{ $spontaneous }}</small></label>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row ">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>
@endsection
@section('language-assign-js')
    <script>
        function checkAll(cname, bx) {
            for (var tbls = cname,i=tbls.length; i--; )
                for (var bxs=tbls[i].getElementsByTagName("input"),j=bxs.length; j--; )
                    if (bxs[j].type=="checkbox")
                        bxs[j].checked = bx.checked;
        }

       /* $('#directed-all-select').click(function () {
            $('input[type=checkbox]').not(this).prop('checked', this.checked);
        });
        $("#spontaneous-all-select").click(function(){
            $('input[id=spontaneous]').prop('checked', this.checked);

        });*/
//        notification-object hide fade out
        // error message show on toast
        @if ($errors->any())
        @foreach ($errors->all() as $error)
            // pogressbarError
            toastr.error('{{ $error }}', 'Error', {
                closeButton: true,
                progressBar: true,
                "positionClass": "toast-top-center",
                "showMethod" : "slideDown",
                "hideMethod" : "slideUp"
            });
        @endforeach
        @endif

    </script>
@endsection

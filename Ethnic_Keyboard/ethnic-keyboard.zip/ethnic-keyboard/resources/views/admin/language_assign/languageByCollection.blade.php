@extends('layouts.app')

@section('title', 'কাজের তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a class="badge bg-success text-decoration-none" href="{{route('admin.language.task_assign',$firstItem->language->id)}}">{{__('Back')}}</a>
                        </li>
                        <li class="breadcrumb-item">
                            <span class="badge bg-info-new"> {{$firstItem->language->name}}</span>
                        </li>
                        <li>
                            @if($firstItem->type_id == 1)
                                <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                            @elseif($firstItem->type_id == 2)
                                <span class="badge bg-success">{{__('স্বতঃস্ফূর্ত')}}</span>
                            @else
                                <span class="badge bg-success">{{__('শব্দ ও ব্যাকরণ')}}</span>
                            @endif
                        </li>

                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <form action="" method="GET">
                    <input type="hidden" id="type_id" value="{{$type}}">
                    <div class="row mb-3" id="clear" >
                        <div class="col-md-2">
                            <select class="form-select" name="district_id" id="district_id">
                                <option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>
                                @foreach($districts as $disItem)
                                    <option value="{{$disItem->district->id}}" {{ $disItem->district->id == $selected_id['district_id'] ? 'selected' : '' }}>{{$disItem->district->name}}</option>
                                @endforeach
                            </select>

                        </div>
                        @if(Auth::user()->user_type != 4)
                            <div class="col-md-2">
                                <select class="form-select" name="collector_id" id="collector_id">
                                    <option value="">{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}</option>
                                    @foreach($collectors as $collectorItem)
                                        <option value="{{$collectorItem->collector->id}}" {{ $collectorItem->collector->id == $selected_id['collector_id'] ? 'selected' : '' }}>{{$collectorItem->collector->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif
                        <div class="col-md-2 ">
                            <div class="input-group">
                                @if($firstItem->dcSpontaneous)
                                    <a class="btn bg-danger" id="remove" href="{{route('admin.language-spontaneous-collections',$firstItem->language->id)}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="display: none; margin-left: -23px; z-index: 100;">
                                        <svg class="icon me-2 text-white">
                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                        </svg>
                                    </a>
                                @endif
                                @if($firstItem->dcDirected)
                                    <a class="btn bg-danger" id="remove" href="{{route('admin.language-directed-collections',$firstItem->language->id)}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="display: none; margin-left: -23px; z-index: 100;">
                                        <svg class="icon me-2 text-white">
                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                        </svg>
                                    </a>
                                @endif
                                @if($firstItem->dcWord)
                                    <a class="btn bg-danger" id="remove" href="{{route('admin.language-word-collections',$firstItem->language->id)}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="display: none; margin-left: -23px; z-index: 100;">
                                        <svg class="icon me-2 text-white">
                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                        </svg>
                                    </a>
                                @endif
                            </div>

                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="data-collection-work">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                            <th scope="col">{{__('জেলা/কালেক্টর')}}</th>
                            {{--<th scope="col">{{__('টাইপ')}}</th>--}}
                            <th scope="col">{{__('শব্দ/বিষয়/টপিক')}}</th>
                            <th scope="col">{{__('অডিও')}}</th>
                            @if($firstItem->dcDirected || $firstItem->dcWord)
                                <th scope="col">{{__('অনুবাদ')}}</th>
                                <th scope="col">{{__('আইপিএ')}}</th>
                                <th scope="col">{{__('স্ট্যাটাস')}}</th>
                            @endif
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $dataCollection)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td class="small">
                                    <div class="badge bg-dark" data-toggle="tooltip" data-placement="top" title="{{ __('ডাটা কালেক্টর') }}">
                                        {{$dataCollection->district->name}}
                                    </div>
                                    <div class="text-medium-emphasis ">
                                        <span data-toggle="tooltip" data-placement="top" title="{{ __('ডাটা কালেক্টর') }}">
                                            {{$dataCollection->collector->name}}
                                        </span>
                                    </div>
                                </td>
                                {{--<td class="collectionType">
                                    @if($dataCollection->type_id == 1)
                                        <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                                    @elseif($dataCollection->type_id == 2)
                                        <span class="badge bg-success">{{__('স্বতঃস্ফূর্ত')}}</span>
                                    @else
                                        <span class="badge bg-success">{{__('শব্দ ও ব্যাকরণ')}}</span>
                                    @endif
                                </td>--}}
                                @if($dataCollection->dcSpontaneous)
                                    <td {{--class="topic"--}}>
                                        <div class="d-flex justify-content-between">
                                            <div class="topic">
                                                <span class="badge bg-info-new " data-toggle="tooltip" data-placement="top" title="{{__('স্বতঃস্ফূর্ত টপিক')}}">
                                                {{$dataCollection->dcSpontaneous->spontaneous->word?? ''}}({{count($dataCollection->dcSpontaneous->trimAudios)}})
                                            </span>
                                            </div>
                                            @if(count($dataCollection->dcSpontaneous->trimAudios)>0)
                                                <span class="btn btn-sm bg-info-new" id="showButton{{$dataCollection->dcSpontaneous->id}}"  onclick="trimShow({{$dataCollection->dcSpontaneous->id}})" data-toggle="tooltip" data-placement="top" title="{{__('সস্বতঃস্ফূর্ত ট্রিমের অংশ')}}">
                                                    <svg class="icon text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-arrow-bottom')}}"></use>
                                                    </svg>
                                                 </span>
                                                <span class="btn btn-sm bg-info-new" id="hideButton{{$dataCollection->dcSpontaneous->id}}"  style="display: none" onclick="trimHide({{$dataCollection->dcSpontaneous->id}})" data-toggle="tooltip" data-placement="top" title="{{__('সস্বতঃস্ফূর্ত ট্রিমের অংশ')}}">
                                                    <svg class="icon text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-arrow-top')}}"></use>
                                                    </svg>
                                                 </span>
                                            @endif
                                        </div>
                                        @if(count($dataCollection->dcSpontaneous->trimAudios)>0)
                                            <table class="table table-bordered table-hover" id="trimRow{{$dataCollection->dcSpontaneous->id}}" style="display: none">
                                                <thead class="table-info">
                                                    <th>{{__('বাংলা')}}</th>
                                                    <th>{{__('উচ্চারণ')}}</th>
                                                    <th>{{__('ট্রিম অডিও')}}</th>
                                                    <th>{{__('স্ট্যাটাস')}}</th>
                                                </thead>
                                                <tbody>
                                                @foreach($dataCollection->dcSpontaneous->trimAudios as $trimAudio)
                                                    @php
                                                        $audio = explode('/', $trimAudio->audio);
                                                        $uniqueCode=substr(end($audio), 0, -4);
                                                    @endphp
                                                    <tr>
                                                        <td class="w-25">
                                                            <span class="small">{{@$trimAudio->bangla}}</span>
                                                        </td>
                                                        <td class="w-25">
                                                            <span class="small">{{@$trimAudio->transcription}}</span>
                                                        </td>
                                                        <td class="align-middle text-start w-25 " style="width: 14rem" >
                                                            <button style="display: none;" class="myTrim" onclick="waveSurferView({{ $trimAudio??'' }})"></button>
                                                            <div id="waveform{{$uniqueCode??''}}"></div>
                                                            <div id="waveform-time-indicator" class="justify-content-between">
                                                                <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                                                <span id="total-time" class="time{{$uniqueCode??''}}"></span>
                                                                <button class="btn btn-light btn-sm mb-1" value="{{$trimAudio->audio}}" onclick="dowonloadFile()" >
                                                                    {{__('ডাউনলোড')}}
                                                                </button>
                                                            </div>
                                                        </td>
                                                        <td class="w-auto">
                                                            @if($trimAudio->status == 0)
                                                                <i class="fa fa-times text-danger"></i>
                                                            @elseif($trimAudio->status == 2)
                                                                <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                                            @elseif($trimAudio->status == 1)
                                                                <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                                            @elseif($trimAudio->status == 3)
                                                                <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>

                                            </table>
                                        @else

                                        @endif

                                    </td>
                                @endif
                                @if(isset($dataCollection->dcDirected->dcSentence->directed))
                                    <td class="sentence">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('নির্দেশিত বিষয়')}}">
                                            {{$dataCollection->dcDirected->topic->name?? ''}}
                                        </span>
                                        <div class="text-medium-emphasis">
                                            <span data-toggle="tooltip" data-placement="top" title="{{ __('নির্দেশিত বাক্য') }}">
                                                {{$dataCollection->dcDirected->dcSentence->directed->sentence?? ''}}
                                            </span>
                                        </div>
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection->word))
                                    <td class="word">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('শব্দ ও ব্যাকরণ')}}">
                                            {{$dataCollection->dcWord->topicWord->name?? ''}}
                                        </span>
                                        <div class="text-medium-emphasis">
                                            <span data-toggle="tooltip" data-placement="top" title="{{ __('শব্দ বাক্য') }}">
                                                {{$dataCollection->dcWord->dcWordCollection->word->sentence?? ''}}
                                            </span>
                                        </div>
                                    </td>
                                @endif


                                @if($dataCollection->dcWord)
                                    @php
                                        $audio = explode('/', $dataCollection->dcWord->dcWordCollection->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 14rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcWord->dcWordCollection??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcWord->dcWordCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif
                                @if($dataCollection->dcDirected)
                                    @php
                                        $audio = explode('/', $dataCollection->dcDirected->dcSentence->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss " >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcDirected->dcSentence??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcDirected->dcSentence->audio}}" onclick="dowonloadFile()">
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif
                                @if($dataCollection->dcSpontaneous)
                                    @php
                                        $audio = explode('/', $dataCollection->dcSpontaneous->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss " >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcSpontaneous??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcSpontaneous->audio}}" onclick="dowonloadFile()">
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif

                                @if(isset($dataCollection->dcDirected->dcSentence))
                                    <td class="">
                                        {{$dataCollection->dcDirected->dcSentence->english?? $dataCollection->dcDirected->dcSentence->directed->english}}
                                    </td>
                                    <td class="">
                                        {{$dataCollection->dcDirected->dcSentence->transcription?? ''}}
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection))
                                    <td class="">
                                        {{$dataCollection->dcWord->dcWordCollection->english?? $dataCollection->dcWord->dcWordCollection->word->english}}
                                    </td>
                                    <td class="">
                                        {{$dataCollection->dcWord->dcWordCollection->transcription?? ''}}
                                    </td>
                                @endif

                                @if(isset($dataCollection->dcDirected->dcSentence))
                                    <td>
                                        @if($dataCollection->dcDirected->dcSentence->status === null)
                                            <i class="fa fa-times text-danger"></i>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 2)
                                            <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 0)
                                            <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                        @endif
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection))
                                    <td>
                                        @if($dataCollection->dcWord->dcWordCollection->status === null)
                                            <i class="fa fa-times text-danger"></i>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 2)
                                            <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 0)
                                            <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                        @endif
                                    </td>
                                @endif
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="card-footer clearfix">
                    {{$dataCollections->appends(request()->input())->links('vendor.pagination.custom')}}
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })
        $(document).ready(function() {

            $('.sentence').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.topic').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.word').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.collectionType').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-success').removeClass('bg-danger');
            });

            // var target = $('option:selected').val();
            var language = $('#language_id option:selected').val();
            var district = $('#district_id option:selected').val();
            var collector = $('#collector_id option:selected').val();
            var speaker = $('#speaker_id option:selected').val();
            var x = document.getElementById("remove");
            if(language || district || collector || speaker){
                x.style.display = "block";
            }

            $('select').on('change', function() {
                var value =this.value;
                var x = document.getElementById("remove");
                if(value){
                    x.style.display = "block";
                }
            });
        });

        $('#clear').on('change', function() {
            var district_id = $('#district_id').val();
            var collector_id = $('#collector_id').val();
            var type_id = $('#type_id').val();
            if(type_id == 'directed'){
                var url = "{{ route('admin.language-directed-collections',$firstItem->language->id) }}";
                var url = url + '?district_id=' + district_id + '&collector_id=' + collector_id;
                window.location.href = url;
            }else if(type_id == 'spontaneous'){
                var url = "{{ route('admin.language-spontaneous-collections', $firstItem->language->id) }}";
                var url = url + '?district_id=' + district_id + '&collector_id=' + collector_id;
                window.location.href = url;
            }else{
                var url = "{{ route('admin.language-word-collections', $firstItem->language->id) }}";
                var url = url + '?district_id=' + district_id + '&collector_id=' + collector_id;
                window.location.href = url;
            }
        });


        $('#district_id').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#collector_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}",
            allowClear: true
        });

        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }



        function trimShow(id) {
            // page refresh
            $('.myTrim').trigger('click');
            var trimCollections = document.getElementById("trimRow"+id);
            if (trimCollections.style.display === "none") {
                trimCollections.style.display = "block";
            } else {
                trimCollections.style.display = "none";
            }

            var hideButton = document.getElementById("hideButton"+id);
            var showButton = document.getElementById("showButton"+id);
            if (hideButton.style.display === "none") {
                hideButton.style.display = "block";
                showButton.style.display = "none";
            }
        }

        function trimHide(id) {
            var trimCollections = document.getElementById("trimRow"+id);
            if (trimCollections.style.display === "none") {
                trimCollections.style.display = "block";
            } else {
                trimCollections.style.display = "none";
            }
            var hideButton = document.getElementById("hideButton"+id);
            var showButton = document.getElementById("showButton"+id);
            if (showButton.style.display === "none") {
                showButton.style.display = "block";
                hideButton.style.display = "none";
            }
            var url = window.location.href;
            var url = url + '?trim=' + id;
            window.location.href = url;
        }



    </script>

@endsection

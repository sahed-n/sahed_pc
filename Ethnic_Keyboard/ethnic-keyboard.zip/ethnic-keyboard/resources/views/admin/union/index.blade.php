@extends('layouts.app')

@section('title', 'ইউনিয়ন তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('messages.ইউনিয়ন তালিকা')}}</li>
                    <li class="nav-item"><a class="btn btn-success text-white btn-sm" href="{{route('admin.unions.create')}}">
                            <svg class="icon me-2 text-white">
                                <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                            </svg>{{__('messages.নতুন')}}</a>
                    </li>
                </ul>
            </div>
            <div class="card-body" >
                <form action="{{route('admin.unions.index')}}" method="GET">
                    <div class="row mb-3" id="search-button">
                        <div class="col-md-3">
                            <div class="input-group">
                                <input type="text" id="search"  name="search" class="form-control" placeholder="Search" value="{{request()->search}}" autofocus>
                                {{--<button class="btn btn-light text-dark" type="button">
                                    <i class="fa fa-search text-dark"></i>
                                    --}}{{--Filter--}}{{--
                                </button>--}}
                            </div>
                        </div>
                        {{--<div class="col-md-1 ">
                            <div class="input-group">
                                <a class="btn bg-danger" id="remove" href="{{route('admin.unions.index')}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="/*display: none;*/ margin-left: -23px; z-index: 100;">
                                    <svg class="icon me-2 text-white">
                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                    </svg>
                                </a>
                            </div>
                        </div>--}}
                        {{--<div class="col-md-2">
                            <select class="form-select" name="upazila" id="upazila_id">
                                <option value="all">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                @foreach($upazilas as $key =>$upazila)
                                    <option value="{{$key}}"  {{ $key == $selected_id['upazila'] ? 'selected' : '' }}>{{$upazila}}</option>
                                @endforeach
                            </select>

                        </div>--}}
                    </div>
                </form>
                <div id="unionTable">

                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>
        // alertify delete
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });


        // keyup and on change

        $('#search-button').on('keyup change', function(){
            search();
        });
        search();
        function search(){
            var search = $('#search').val();
            var upazila = $('#upazila_id').val();
            $.ajax({
                url:"{{ route('admin.unions.search') }}",
                method:"GET",
                data:{search:search, upazila:upazila},
                success:function(data) {
                    $('#unionTable').html(data);
                }
            })
        }

    </script>
@endsection


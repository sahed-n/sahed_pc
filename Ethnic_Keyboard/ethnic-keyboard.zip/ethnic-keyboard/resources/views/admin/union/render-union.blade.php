
<div class="table-responsive">
    <table class="table table-hover table-bordered" {{--id="union"--}}>
        <thead class="table-dark">
        <tr>
            <th scope="col">{{__('messages.ক্রমিক নং')}}</th>
            <th scope="col">{{__('messages.ইউনিয়ন নাম')}}</th>
            <th scope="col">{{__('messages.উপজেলার নাম')}}</th>
            <th scope="col" class="text-center">{{__('messages.অ্যাকশন')}}</th>
        </tr>
        </thead>
        <tbody>
        @foreach($unions as $key=>$union)
            <tr>
                <td>{{ $loop->iteration }}</td>
                @if(App::getLocale() == 'bn')
                    <td>{{$union->bn_name}}</td>
                    <td>{{$union->upazila->bn_name}}</td>
                @else
                    <td>{{$union->name}}</td>
                    <td>{{$union->upazila->name}}</td>
                @endif
                <td class="text-center">
                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                        <a class="btn btn-purple btn-sm" href="{{route('admin.unions.edit', $union->id)}}">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="{{ route('admin.unions.destroy', $union->id) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger btn-sm show_confirm">
                                <svg class="icon  text-white">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                </svg>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
{{ $unions->links('vendor.pagination.custom') }}

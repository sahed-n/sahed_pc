@extends('layouts.app')
@section('title', __('শব্দ ও ব্যাকরণ বিষয়ের তালিকা'))
@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('শব্দ ও ব্যাকরণ বিষয়ের তালিকা')}}</li>
                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item me-4">
                            <form action="{{ route('admin.word.file-import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="input-group">
                                    <span id="bulk-import-preview" class="input-group-text">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-question-circle rounded-circle bg-warning" viewBox="0 0 16 16">
                                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                                        <path d="M5.255 5.786a.237.237 0 0 0 .241.247h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286zm1.557 5.763c0 .533.425.927 1.01.927.609 0 1.028-.394 1.028-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94z"/>
                                                    </svg>
                                                </span>
                                    <input type="file" name="file" class="form-control form-control-sm" id="inputWordSentence" required>
                                    <button class="btn btn-primary btn-sm" id="inputWordSentence">Import data</button>
                                </div>
                            </form>
                        </li>
                        <li class="nav-item">
                            <button class="btn btn-success btn-sm text-white" type="button" data-coreui-toggle="modal" data-coreui-target="#wordForm">
                                <svg class="icon me-2 text-white">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                                </svg>{{__('messages.নতুন')}}
                            </button>
                        </li>
                    </ul>
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                {{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="wordDataForm">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col"  style="width: 7rem;">{{__('messages.ক্রমিক নং')}}</th>
                            <th scope="col">{{__('messages.বিষয়')}}</th>
                            {{-- <th scope="col">{{__('Created At')}}</th> --}}
                            <th scope="col" class="text-center">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>

                        <tbody>

                        @foreach($wordTopics as $key=> $wordTopic)
                            <tr>
                                <td>{{  ++ $key }}</td>
                                <td class="">
                                    {{$wordTopic->name}}
                                </td>
                                {{-- <td class="">
                                    {{$wordTopic->created_at}}
                                </td> --}}
                                <td class="text-center">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        <a class="btn btn-success btn-sm" href="{{route('admin.word_sentence.index', $wordTopic->id)}}">
                                            <i class="text-white far fa-plus"></i>
                                        </a>
                                        <button class="btn btn-purple btn-sm editbtn" type="button" value="{{$wordTopic->id}}" data-coreui-toggle="modal" data-coreui-target="#wordEditForm">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        {{-- <form action="" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger btn-sm show_confirm">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                </svg>
                                            </button>
                                        </form> --}}
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                {{--{{ $directeds->links('vendor.pagination.custom') }}--}}
            </div>
        </div>
    </div>

    @include('admin.word.bulk-import-preview-modal')
    {{--    edit modal --}}
    @include('admin.word.edit')

    <!-- directed create modal-->
    @include('admin.word.create')

@endsection

@section('language-filter-js')
    <script>
        $(document).ready(function() {
            $('#wordDataForm').DataTable();
        } );
        // alertify delete
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete? All releated data will be deleted',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        @if (count($errors) > 0)
        {{-- $( document ).ready(function() {
             $('#wordForm').modal('show');
         });--}}
        setTimeout(function() {
            $('.notification-object').css('display', 'none');
        }, 5000);
        @endif


        // add more input field
        $(document).ready(function () {
            var maxField = 10; // Total 5 product fields we add
            var addButton = $('.add_button'); // Add more button selector
            var wrapper = $('.field_wrapper'); // Input fields wrapper
            var fieldHTML = `<div class="row">
                        <div class="col-md-11">
                            <div class="mb-3 row">
                                <label class="col-sm-3 col-form-label" for="name">{{__('messages.বিষয়')}}</label>
                                <div class="col-sm-9">
                                    <input class="form-control" id="name" name="name[]" type="text" placeholder="{{__('messages.বিষয়')}}"  required>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1 remove_button">
                            <a href="javascript:void(0);" class="btn btn-success btn-sm rounded-circle ">
                                <svg class="icon" style="width:0.5rem">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-minus')}}"></use>
                                </svg>
                            </a>
                        </div>
                    </div>`; //New input field html

            var x = 1; //Initial field counter is 1

            $(addButton).click(function () {
                //Check maximum number of input fields
                if (x < maxField) {
                    x++; //Increment field counter
                    $(wrapper).append(fieldHTML);
                }
            });
            //Once remove button is clicked
            $(wrapper).on('click', '.remove_button', function (e) {
                e.preventDefault();
                $(this).parent('div').remove();
                x--; //Decrement field counter
            });
        });



        $(document).ready(function (){
            $(document).on('click', '.editbtn', function (){
                var topicID = $(this).val();
                // alert(directedID);

                $('#wordEditForm').modal('show');

                $.ajax({
                    type: "GET",
                    url: "/admin/words/"+topicID+"/edit",
                    dataType: 'json',
                    success:function (response){
                        console.log(response)
                        $('#topic_word_id').val(response.topic_word.id);
                        $('#name').val(response.topic_word.name);
                    }
                })
            })
        })

        // word import
        $(document).ready(function () {
            $('#bulk-import-preview').click(function () {
                $('#bulk-import-preview-modal').modal('show');
            });

            // on mouse to cursor pointer and #bulk-import-preview tooltip show with background color
            $('#bulk-import-preview').hover(function () {
                $(this).css('cursor', 'pointer');
                $(this).tooltip('show');
            });
            $('#bulk-import-preview').attr('data-bs-toggle', 'tooltip');
            $('#bulk-import-preview').attr('data-bs-placement', 'top');
            $('#bulk-import-preview').attr('title', 'Preview');

        });

    </script>
@endsection


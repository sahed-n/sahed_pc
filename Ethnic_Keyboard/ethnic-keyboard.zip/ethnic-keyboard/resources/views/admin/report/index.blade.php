@extends('layouts.app')
@section('title', 'ডাটা রিপোর্ট')
@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('ডাটা রিপোর্ট')}}</li>
                </ul>
            </div>
            <div class="card-body">
                <form action="{{route('admin.collection-work-details.index')}}" method="GET">
                    <div class="row mb-3" id="clear" >
                        <div class="col-md-3">
                            <select class="form-select" name="language_id" id="language_id">
                                <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                @foreach($languages as $lanItem)
                                    <option value="{{$lanItem->language->id}}" {{ $lanItem->language->id == $selected_id['language_id'] ? 'selected' : '' }}>{{$lanItem->language->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </form>

                <div class="table-responsive" id="dataCollection-render">
                    <table class="table table-hover table-bordered" id="data-collection">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 4rem;">{{__('ক্রমিক নং')}}</th>
                            <th scope="col">{{__('ডাটা টাইপ')}}</th>
                            <th scope="col">{{__('জেলা')}}</th>
                            <th scope="col">{{__('ডাটা কালেক্টর')}}</th>
                            <th scope="col">{{__('স্পিকার')}}</th>
                            <th scope="col">{{__('বিষয়/টপিক')}}</th>
                            <th scope="col">{{__('শব্দ ও ব্যাকরণ/বাংলা বাক্য')}}</th>
                            <th scope="col">{{__('অনুবাদ')}}</th>
                            <th scope="col">{{__('আইপিএ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td colspan="9" class="text-center">{{__('কোন ডাটা নেই')}}</td>
                        </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">

        $('#language_id').on('change',function () {
            var language_id = $('#language_id').val();
            $.ajax({
                url:"{{route('admin.reports.render')}}",
                method:"GET",
                data:{language_id:language_id},

                beforeSend: function () {
                    $('#dataCollection-render').html('<div class="text-center mt-5"><i class="fa fa-spinner fa-spin fa-3x fa-fw"></i></div>');
                },

                success:function (data) {
                    $('#dataCollection-render').html(data);
                },
                complete: function () {
                    $('#data-collection').DataTable({
                        dom: 'Bfrtip',
                        buttons: [
                            {
                                extend: 'excel',
                                title: 'ডাটা রিপোর্ট অফ ' + $('#language_id option:selected').text(),
                            },
                            /*{
                                extend: 'csv',
                                title: 'ডাটা রিপোর্ট অফ ' + $('#language_id option:selected').text(),
                            },*/

                        ],
                    });
                }
            })
        });

        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
    </script>

@endsection

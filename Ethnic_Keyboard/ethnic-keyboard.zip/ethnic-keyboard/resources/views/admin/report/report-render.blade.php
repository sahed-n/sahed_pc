<input type="hidden" id="languageName" value="{{$languageName->name}}">
<table class="table table-hover table-bordered" id="data-collection">
    <thead class="table-dark">
    <tr>
        <th scope="col" style="width: 4rem;">{{__('ক্রমিক নং')}}</th>
        <th scope="col">{{__('ডাটা টাইপ')}}</th>
        <th scope="col">{{__('জেলা')}}</th>
        <th scope="col">{{__('ডাটা কালেক্টর')}}</th>
        <th scope="col">{{__('স্পিকার')}}</th>
        <th scope="col">{{__('বিষয়/টপিক')}}</th>
        <th scope="col">{{__('শব্দ ও ব্যাকরণ/বাংলা বাক্য')}}</th>
        <th scope="col">{{__('অনুবাদ')}}</th>
        <th scope="col">{{__('আইপিএ')}}</th>
    </tr>
    </thead>
    <tbody>
    @foreach($results as $result)
        <tr>
            <td>{{ $result['serial_no'] }}</td>
            <td class="small">{{$result['type']}}</td>
            <td class="small">{{$result['district']}}</td>
            <td class="small">{{$result['collector']}}</td>
            <td class="small">{{$result['speaker']}}</td>
            <td class="small">{{$result['topic']?? ''}}</td>
            <td class="small">{{$result['sentence']?? ''}}</td>
            <td class="small">{{$result['english']??''}}</td>
            <td class="small">{{$result['ipa']??''}}</td>
        </tr>
    @endforeach
    </tbody>
</table>

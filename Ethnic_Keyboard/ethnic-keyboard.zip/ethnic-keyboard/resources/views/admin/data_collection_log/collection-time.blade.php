@extends('layouts.app')

@section('title', 'ডাটা সংগ্রহের সময়')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('ডাটা সংগ্রহের সময়')}}</li>
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <div class="table-responsive">
                    <table class="table table-hover table-bordered mb-0" id="colection-time">
                        <thead class="table-info fw-semibold">
                        <tr class="align-middle">
                            <th>{{__('##')}}</th>
                            <th>{{__('ডাটা কালেক্টর')}}</th>
                            <th>{{__('ভাষা')}}</th>
                            <th>{{__('নির্দেশিত')}}</th>
                            <th>{{__('স্বতঃস্ফূর্ত')}}</th>
                            <th>{{__('শব্দ')}}</th>
                            <th>{{__('মোট সংগ্রহ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($collectionTimes as $key =>$collectionTime)
                            <tr class="align-middle">
                                <td>{{$loop->iteration}}</td>
                                <td>
                                    <div>
                                        @if(isset($collectionTime[1][0]))
                                        {{$collectionTime[1][0]->collector}}
                                        @elseif(isset($collectionTime[2][0]))
                                                {{$collectionTime[2][0]->collector}}
                                        @else
                                            {{$collectionTime[0][0]->collector}}
                                        @endif

                                    </div>
                                </td>
                                <td>
                                    <div>
                                        @if(isset($collectionTime[1][0]))
                                            {{$collectionTime[1][0]->language}}
                                        @elseif(isset($collectionTime[2][0]))
                                            {{$collectionTime[2][0]->language}}
                                        @else
                                            {{$collectionTime[0][0]->language}}
                                        @endif
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        @php
                                            $seconds= round($collectionTime[1][0]->sum_of_length??0, 2);
                                            $directed_minutes = floor($seconds / 60);
                                            $directed_seconds = $seconds % 60;

                                        @endphp
                                        {{ (int)$directed_minutes }} {{__('মিনিট')}} {{ (int)$directed_seconds }} {{__('সেকেন্ড')}}
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        @php
                                            $seconds= round($collectionTime[2][0]->sum_of_length??0, 2);
                                            $spontaneous_minutes = floor($seconds / 60);
                                            $spontaneous_seconds = $seconds % 60;

                                        @endphp
                                        {{ (int)$spontaneous_minutes??0 }} {{__('মিনিট')}} {{ (int)$spontaneous_seconds??0 }} {{__('সেকেন্ড')}}
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        @php
                                            $seconds= round($collectionTime[0][0]->sum_of_length??0, 2);
                                            $word_minutes = floor($seconds / 60);
                                            $word_seconds = $seconds % 60;

                                        @endphp
                                        {{ (int)$word_minutes }} {{__('মিনিট')}} {{ (int)$word_seconds }} {{__('সেকেন্ড')}}
                                    </div>
                                </td>

                                <td >
                                    <div>
                                        @php
                                        $total_seconds = round($collectionTime[0][0]->sum_of_length??0, 2) + round($collectionTime[1][0]->sum_of_length??0, 2) + round($collectionTime[2][0]->sum_of_length??0, 2);
                                        $total_minutes = floor($total_seconds / 60);
                                        $total_secs = $total_seconds % 60;
                                        @endphp
                                        {{ (int)$total_minutes }} {{__('মিনিট')}} {{ (int)$total_secs }} {{__('সেকেন্ড')}}
                                    </div>
                                </td>

                                {{--<td>
                                    <div class="clearfix">
                                        <div class="float-start">
                                            <div class="fw-semibold">50%</div>
                                        </div>
                                        <div class="float-end"><small class="text-medium-emphasis">Jun 11, 2020 - Jul 10, 2020</small></div>
                                    </div>
                                    <div class="progress progress-thin">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </td>--}}
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
            // datatable
            $(document).ready(function() {
                $('#colection-time').DataTable({
                   order:false,
                    "language": {
                        "lengthMenu": "Display _MENU_ records per page",
                        "info": "Showing page _PAGE_ of _PAGES_",
                        "infoEmpty": "No records available",
                        "infoFiltered": "(filtered from _MAX_ total records)",
                        "search": "অনুসন্ধান",
                        "paginate": {
                            "first":      "প্রথম",
                            "last":       "শেষ",
                            "next":       "পরবর্তী",
                            "previous":   "আগের"
                        },
                    }
                });
            });
    </script>

@endsection

@extends('layouts.app')
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{route('admin.data-collection-log.index')}}">{{__('ডাটা লগ')}}</a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('দেখুন')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('সংগৃহীত ডাটার তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('টপিক') }}</th>
                                <td>{{ $dataCollection->dcSpontaneous->spontaneous->word?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('অডিও') }}</th>
                                <td>
                                    <input type="hidden" id="audio" value="{{$dataCollection->dcSpontaneous->audio}}">
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('টাইপ') }}</th>
                                <td>
                                    @if(App::getLocale() == 'bn')
                                        {{($dataCollection->type_id == 1)? 'নির্দেশিত':'স্বতঃস্ফূর্ত'}}
                                    @else
                                        {{($dataCollection->type_id == 1)? 'Directed':'Spontaneous'}}
                                    @endif
                                </td>

                            </tr>
                            <tr>
                                <th>{{ __('ভাষা') }}</th>
                                <td>
                                    {{$dataCollection->language->name?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('অবস্থান') }}</th>
                                <td>
                                    {{$dataCollection->district->name?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('সংগ্রহের তারিখ') }}</th>
                                <td>
                                    {{showDate($dataCollection->created_at?? '')}}
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-5 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('কালেক্টর তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('গ্রুপের নাম') }}</th>
                                <td>
                                    {{$dataCollection->taskAssign->group->name ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('কালেক্টর নাম') }}</th>
                                <td>
                                    {{$dataCollection->collector->name ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ইমেইল') }}</th>
                                <td>
                                    {{$dataCollection->collector->email ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('জাতীয় পরিচয়পত্র') }}</th>
                                <td>
                                    {{$dataCollection->collector->nid ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>
                                    {{$dataCollection->collector->phone ?? ''}}
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <hr>
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('স্পিকারের তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('স্পিকার নাম') }}</th>
                                <td>
                                    {{ $dataCollection->speaker->name ?? '' }}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('লিঙ্গ') }}</th>
                                <td>
                                    @if($dataCollection->speaker->gender == 0)
                                        {{__('messages.পুরুষ')}}
                                    @elseif($dataCollection->speaker->gender== 1)
                                        {{__('messages.মহিলা')}}
                                    @else
                                        {{__('messages.অন্যান্য')}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>{{ $dataCollection->speaker->phone?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('বয়স') }}</th>
                                <td>{{ $dataCollection->speaker->age?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('পেশা') }}</th>
                                <td>{{ $dataCollection->speaker->occupation?? ''}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>

    </div>
@endsection
@section('language-js')
    <script>
    </script>

@endsection

@extends('layouts.app')

@section('title', 'ডাটা কালেক্টর তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{route('admin.data-collection-log.index')}}">{{__('ডাটা লগ')}}</a>
                        </li>
                        @if(!empty($firstItem))
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->language->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->district->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->collector->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->speaker->name}}</li>
                        @endif
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 5rem;">{{__('##')}}</th>
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col">{{__('অডিও')}}</th>
                            <th scope="col" style="width: 14rem;">{{__('বাক্য')}}</th>
                            <th scope="col">{{__('সংগ্রহের তারিখ')}}</th>
                            {{--<th scope="col">{{__('স্ট্যাটাস')}}</th>--}}
                            <th scope="col">{{__('অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $key=>$dataCollection)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td class="">
                                    @if($dataCollection->type_id == 1)
                                        {{__('নির্দেশিত')}}
                                    @endif
                                </td>
                                @if($dataCollection->dcDirected)
                                    @php
                                        $audio = explode('/', $dataCollection->dcDirected->dcSentence->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss ">
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcDirected->dcSentence??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}">00:00:00</span>
                                        </div>
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcDirected->dcSentence->directed))
                                    <td class="sentence" style="width: 12rem">
                                        <span class="badge-custom {{--bg-info-new position-relative--}}" data-toggle="tooltip" data-placement="top" title="{{__('বাক্য')}}">
                                            {{$dataCollection->dcDirected->dcSentence->directed->sentence?? ''}}
                                        </span>
                                    </td>
                                @endif
                                <td class="small">{{showDate($dataCollection->created_at)}}</td>
                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-start">
                                        <a class="btn btn-info btn-sm" href="{{ route('admin.collection-work-details.show', ['type'=>'directed', 'id'=>$dataCollection->id]) }}">
                                            <i class="text-white far fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        // alertify delete notification
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
        $('.sentence').hover(function() {
            $(this).find('.badge-custom').addClass('bg-danger');
        }, function() {
            $(this).find('.badge-custom').removeClass('bg-danger');
        });

        // .sentence background color none

    </script>

@endsection


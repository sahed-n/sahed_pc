@extends('layouts.app')

@section('title', __('নির্দেশিত বাক্য তালিকা'))

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item"><a href="{{route('admin.directeds.index')}}">{{__('নির্দেশিত বাক্য তালিকা')}}</a></li>/
                        <li class="nav-item">{{isset($firstItem->topics)? $firstItem->topics->name:$topic->name}}</li>
                    </ul>

                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item me-4">
                            <form action="{{ route('admin.directed-file-import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="input-group">
                                    <span id="bulk-import-preview" class="input-group-text">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-question-circle rounded-circle bg-warning" viewBox="0 0 16 16">
                                                        <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
                                                        <path d="M5.255 5.786a.237.237 0 0 0 .241.247h.825c.138 0 .248-.113.266-.25.09-.656.54-1.134 1.342-1.134.686 0 1.314.343 1.314 1.168 0 .635-.374.927-.965 1.371-.673.489-1.206 1.06-1.168 1.987l.003.217a.25.25 0 0 0 .25.246h.811a.25.25 0 0 0 .25-.25v-.105c0-.718.273-.927 1.01-1.486.609-.463 1.244-.977 1.244-2.056 0-1.511-1.276-2.241-2.673-2.241-1.267 0-2.655.59-2.75 2.286zm1.557 5.763c0 .533.425.927 1.01.927.609 0 1.028-.394 1.028-.927 0-.552-.42-.94-1.029-.94-.584 0-1.009.388-1.009.94z"/>
                                                    </svg>
                                                </span>
                                    <input type="file" name="file" class="form-control form-control-sm" id="inputGroupSentence" required>
                                    <button class="btn btn-primary btn-sm" id="inputGroupSentence">Import data</button>
                                </div>
                            </form>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-success btn-sm text-white" href="{{route('admin.directed_sentence.create', isset($firstItem->topic_id)? $firstItem->topic_id:$topic->id)}}">
                                <svg class="icon me-2 text-white">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                                </svg>{{__('messages.নতুন')}}
                            </a>
                        </li>
                    </ul>
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="directedSentence">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 7rem;">{{__('messages.ক্রমিক নং')}}</th>
                            <th scope="col">{{__('messages.বাংলা বাক্য')}}</th>
                            <th scope="col">{{__('messages.ইংরেজী বাক্য')}}</th>
                            <th scope="col" class="text-center">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($directedSentences as $key=>$directedSentence)
                            <tr>
                                <td>{{ ++ $key }}</td>
                                <td>
                                    {{$directedSentence->sentence}}
                                </td>
                                <td>
                                    {{$directedSentence->english}}
                                </td>
                                <td class="text-center">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        <a class="btn btn-purple btn-sm" href="{{route('admin.directed_sentence.edit', $directedSentence->id)}}">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="{{ route('admin.directed_sentence.destroy', $directedSentence->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger btn-sm show_confirm">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                        @endforelse
                        </tbody>
                    </table>
                </div>
                {{--{{ $languages->links('vendor.pagination.custom') }}--}}
            </div>
        </div>
    </div>
    @include('admin.directed_sentence.bulk-import-preview-modal')
@endsection

@section('language-filter-js')
    <script>
        $('body').on('click', '.show_confirm', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি এই বাক্য মুছে ফেলতে চান ?')}}",
                text: "{{__('যদি এটি মুছে ফেলেন তাহলে বাক্য এবং তার ডাটা চিরতরে মুছে যাবে !')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '28px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });
        $(document).ready(function() {
            $('#directedSentence').DataTable( {
                "stateSave": true,
                "ordering": false,
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend:'print',
                        title: '{{$firstItem->topics->name}}',
                    }
                ],
            } );
        } );



        $(document).ready(function () {
            $('#bulk-import-preview').click(function () {
                $('#bulk-import-preview-modal').modal('show');
            });

            // on mouse to cursor pointer and #bulk-import-preview tooltip show with background color
            $('#bulk-import-preview').hover(function () {
                $(this).css('cursor', 'pointer');
                $(this).tooltip('show');
            });
            $('#bulk-import-preview').attr('data-bs-toggle', 'tooltip');
            $('#bulk-import-preview').attr('data-bs-placement', 'top');
            $('#bulk-import-preview').attr('title', 'Preview');

        });
    </script>
@endsection


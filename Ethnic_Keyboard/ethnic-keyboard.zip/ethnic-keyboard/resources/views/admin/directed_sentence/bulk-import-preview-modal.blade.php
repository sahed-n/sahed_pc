<div class="modal fade" id="bulk-import-preview-modal" data-coreui-backdrop="static" data-coreui-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Please Follow This Instruction</h5>
                <button type="button" class="btn-close" data-coreui-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <ol class="list-group list-group-numbered mb-3">
                    <li class="list-group-item">First row will be sentence , topic and english <em class="text-danger">(Not allowed missmatch title name.) </em></li>
                    <li class="list-group-item">Sentence column can't be null</li>
                    <li class="list-group-item">Topic name must be same as topic</li>
                    <li class="list-group-item">English column can be null</li>
                </ol>
                <div class="card">
                    <div class="card-title">
                        <h5 class="text-center">Example</h5>
                    </div>
                    <img src="{{asset('assets/coreui/assets/img/sentencepreview.png')}}" {{--class="img-fluid"--}} alt="">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-coreui-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

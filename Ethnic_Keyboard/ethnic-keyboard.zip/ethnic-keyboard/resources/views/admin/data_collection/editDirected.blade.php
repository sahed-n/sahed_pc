@extends('layouts.app')
<style>
    .table-responsive {
        overflow-y:scroll;
        height:550px;
    }
</style>
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.directed.language.tasks.list', $directedLanguages->taskAssign->id)}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">{{__('messages.নির্দেশিত')}}</li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Language">
                            {{$directedLanguages->taskAssign->language->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="District">
                            {{$directedLanguages->taskAssign->district->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Sentence">
                            {{ $directedLanguages->topic->name }}
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                @foreach ($taskBySentences as $taskBySentence)
                    @php
                        $directedID = $taskBySentence->id;
                        $directedAudios=\App\Models\DCDirectedSentence::where('directed_id', $directedID)
                                       ->with('dcDirected.collection')
                                       ->whereHas('dcDirected', function ($q) use ($taskBySentence){
                                           $q->where('topic_id',$taskBySentence->topic_id);
                                       })
                                       ->whereHas('dcDirected.collection', function ($s) use ( $directedLanguages){
                                           return $s->where('task_assign_id',  $directedLanguages->task_assign_id);

                                       })->first();
                    @endphp
                    <div class="row">
                        <div class="col-md-5 col-sm-12">
                            <form action="" id="sentence_form" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <input type="hidden" value="{{ $directedLanguages->task_assign_id }}" name="task_assign_id" id="taskID">
                                <input type="hidden" value="{{ $taskBySentence->topic_id}}" name="topic_id" id="topicID">
                                @if(isset($directedAudios))
                                    <div class="row mb-3">
                                        <div class="">
                                            <input type="hidden"  id="audio" value="">
                                            <input type="hidden" id="audio-exist" value="{{$directedAudios->audio}}">
                                            <div id="wavetrim"></div>
                                            <div id="waveform-time-indicator" class="justify-content-between">
                                                <input type="button" id="btn-play" value="Play"/>
                                                <span class="time">00:00:00</span>
                                            </div>
                                        </div>
                                    </div>
                                @else
                                    <div class="row mb-2">
                                        <label class="" ><strong>{{__('অডিও')}}</strong></label>
                                        <div class="input-group">
                                            <textarea class="form-control text-danger" cols="30" rows="1" readonly="">{{ __('এখনও  অডিও কালেকশন হয়নি ।') }}</textarea>
                                        </div>
                                    </div>
                                @endif
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('বাংলা')}}</strong></label>
                                    <div class="input-group">
                                        <textarea class="form-control" cols="30" rows="3" readonly="">{{ $taskBySentence->sentence }}</textarea>

                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('ইংরেজী')}}</strong> </label>
                                    <div class="input-group">
                                        <textarea class="form-control" name="english" id="english" cols="30" rows="3"> {{ $directedAudios->english?? $taskBySentence->english}}</textarea>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('উচ্চারণ')}}</strong> </label>
                                    <div class=" input-group">
                                        <textarea class="form-control" name="transcription" id="transcription" cols="30" rows="3">{{$directedAudios->transcription??''}}</textarea>
                                    </div>
                                </div>


                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('সংগৃহীত বাক্যের পরিবর্তিত রূপ (যদি থাকে)')}} </strong></label>
                                    <div class=" input-group">
                                        <textarea class="form-control" name="modified_sentence" id="modified_sentence" cols="30" rows="3">{{$directedAudios->modified_sentence??''}}</textarea>
                                    </div>
                                </div>

                                <div class="row mb-2">
                                    <div class="text-end m-1 ">
                                        <a href="{{ $taskBySentences->nextPageUrl() != null ? $taskBySentences->nextPageUrl() : ''  }}" style="display: none"  id="next_page"></a>
                                        @if($taskBySentences->previousPageUrl() != null)
                                            <a href="{{ $taskBySentences->previousPageUrl() }}" class="btn btn-success text-white float-start">Previous</a>
                                        @endif
                                        <button type="submit" class="btn btn-success text-white custom-tooltip" id="save_form">{{ $taskBySentences->nextPageUrl() != null ? 'Submit & Next' : 'Submit' }}</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-7 px-0">
                            <div class="col-md-12 col-sm-12">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-bordered" id="data-collection">
                                            <thead class="table-dark">
                                            <tr>
                                                <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('বাংলা')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('অনুবাদ')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('উচ্চারণ')}}</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach ($sentenceList as $key=>$sentenceTask)
                                                @php
                                                    $dcDirectedCollection=\App\Models\DCDirectedSentence::where('directed_id', $sentenceTask->id)
                                                           ->with('dcDirected.collection')
                                                           ->whereHas('dcDirected', function ($q) use ($sentenceTask){
                                                               $q->where('topic_id',$sentenceTask->topic_id);
                                                           })
                                                           ->whereHas('dcDirected.collection', function ($s) use ( $directedLanguages){
                                                               return $s->where('task_assign_id',  $directedLanguages->task_assign_id);

                                                           })
                                                           ->first();
                                                    $keySer = ++$key;
                                                @endphp
                                                <tr data-sentence-id="{{ $keySer }}">
                                                    <td>
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($loop->iteration)}})
                                                        @else
                                                            {{ $loop->iteration}}
                                                        @endif
                                                    </td>

                                                    <td class="">
                                                        <a href="{{ url()->current() }}?page={{ $keySer }}" class="nav-link text-dark">
                                                            {{ $sentenceTask->sentence }}
                                                        </a>
                                                    </td>
                                                    <td class="">
                                                        <a href="{{ url()->current() }}?page={{ $keySer }}" class="nav-link text-dark">
                                                            @if(isset($dcDirectedCollection->english) || $sentenceTask->english )
                                                                <i class="fa fa-check text-success"></i>
                                                            @else
                                                                <i class="fa fa-times text-danger"></i>
                                                            @endif
                                                        </a>
                                                    </td>
                                                    <td class="">
                                                        <a href="{{ url()->current() }}?page={{ $keySer }}" class="nav-link text-dark">
                                                            @if(isset($dcDirectedCollection->transcription))
                                                                <i class="fa fa-check text-success"></i>
                                                            @else
                                                                <i class="fa fa-times text-danger"></i>
                                                            @endif
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
@section('language-js')
    <script>
        $(document).ready(function () {
            // directed sentence active
            $(function($) {
                let url = window.location.href;
                const queryString = window.location.search;
                const urlParams = new URLSearchParams(queryString);
                const pageNo = urlParams.get('page');
                var speakerIdUrl = urlParams.get('speaker');

                if (pageNo === null){
                    $("#data-collection tbody").children(":first").addClass('collection-active');
                }

                $('#data-collection tbody tr td a').each(function() {
                    if (this.href === url) {
                        $(this).closest('tr').addClass('collection-active');

                        //  start  -- scroll to selected tr
                        var container = $('.table-responsive');
                        var scrollTo = $(".collection-active");

                        // Calculating new position  of scrollbar
                        var position = scrollTo.offset().top
                            - container.offset().top
                            + container.scrollTop();

                        // Animating scrolling effect
                        container.animate({
                            scrollTop: position
                        });
                    }else if (speakerIdUrl !== null)
                    {
                        if ($(this).closest('tr').attr('data-sentence-id') === pageNo)
                        {
                            $(this).closest('tr').addClass('collection-active');

                            var $container = $('.table-responsive'),
                                $scrollTo = $('.collection-active')
                            $container.scrollTop(
                                $scrollTo.offset().top - $container.offset().top + $container.scrollTop()
                            );
                        }
                    }
                });
            });
        });

    </script>


    <script>
        $('#sentence_form').on('submit',function(e){
            e.preventDefault();
            directedUpdate();
        });

        $(document).ready(function () {
            var page  = $('#next_page').attr('href');
            if (page == undefined) {
                $('#save_form').html('Submit');
            }
        });
    </script>

    <script>
        function directedUpdate() {
            $('#save_form').attr('disabled',true);
            var form     = document.getElementById("sentence_form")
            var formData = new FormData(form);
            page = $('#next_page').attr('href');
            submit = document.getElementById("save_form").innerHTML;
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },

                type:'post',
                url: "{{route('admin.data_collections.directed.update', $directedAudios->id ?? 0)}}",
                data: formData,
                processData: false,
                contentType: false,
                dataType:'json',
                async :true,
                success: function (data) {
                    toastr.success(data.msg);
                    if (page == undefined) {
                        window.location.href = document.location.origin;
                    }else if(submit == 'Submit'){
                        var task_assign_id= $('#taskID').val();
                        var topic_id= $('#topicID').val();
                        let path = document.location.origin+'/admin/directed/language/topic/'+task_assign_id+'/'+topic_id+'/list';
                        window.location.href =  path;
                    }else{

                        window.location.href = $('#next_page').attr('href');
                    }
                },
                error: function (data) {
                    var errors = data.responseJSON;
                    var error = errors.errors;
                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "progressBar": true,
                        "positionClass": "toast-top-center",
                        "showMethod" : "slideDown",
                        "hideMethod" : "slideUp"
                    }
                    $.each(error, function (key, value) {
                        toastr.error(value[0]);
                    });
                    $('#save_form').attr('disabled',false);
                }

            });


        }
    </script>
@endsection

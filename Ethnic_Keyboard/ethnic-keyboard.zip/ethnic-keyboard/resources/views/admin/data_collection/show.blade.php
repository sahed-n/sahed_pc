@extends('layouts.app')
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.data_collections.index')}}">{{__('messages.তথ্য সংগ্রহ')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">
                            @if($type == 'directed')
                                {{__('নির্দেশিত')}}
                            @elseif($type == 'spontaneous')
                                {{__('স্বতঃস্ফূর্ত ট্রিমিং')}}
                            @else
                                {{__('শব্দ')}}
                            @endif
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-7 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('সংগৃহীত ডাটার তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                @if(isset($audio->dcDirected->topic->name))
                                    <th>{{ __('বিষয়') }}</th>
                                    <td>{{ $audio->dcDirected->topic->name ?? ''}}</td>
                                @endif
                                @if(isset($audio->spontaneous->word))
                                    <th>{{ __('টপিক') }}</th>
                                    <td>{{ $audio->spontaneous->word?? ''}}</td>
                                @endif
                                @if(isset($audio->dcWord->dcWordCollection->word))
                                    <th>{{ __('শব্দ ও ব্যাকরণ') }}</th>
                                    <td>{{ $audio->dcWord->topicWord->name?? ''}}</td>
                                @endif
                            </tr>
                            <tr>
                                <th>{{ __('অডিও') }}</th>
                                <td>
                                    @if(isset($audio->audio))
                                        <input type="hidden" id="audio" value="{{$audio->audio?? ''}}">
                                    @endif
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                        <button class="btn btn-light btn-sm mb-1" value="{{$audio->audio}}" onclick="dowonloadFile()" >
                                            {{__('ডাউনলোড')}}
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('টাইপ') }}</th>
                                <td class="">
                                    @if(isset($audio->dcDirected))
                                        <span class="badge bg-success"> {{__('নির্দেশিত')}}</span>
                                    @elseif(isset($audio->dcWord))
                                        <span class="badge bg-success"> {{__('শব্দ ও ব্যাকরণ')}}</span>
                                    @else
                                        <span class="badge bg-success"> {{__('স্বতঃস্ফূর্ত')}}</span>
                                    @endif
                                </td>

                            </tr>
                            <tr>
                                <th>{{ __('বাংলা') }}</th>
                                <td>
                                    @if(isset($audio->dcDirected->dcSentence->directed->sentence))
                                        {{$audio->dcDirected->dcSentence->directed->sentence ?? ''}}
                                    @elseif(isset($audio->dcWord->dcWordCollection->word->sentence))
                                        {{$audio->dcWord->dcWordCollection->word->sentence ?? ''}}
                                    @else
                                        {{$audio->dcSpontaneous->bangla?? ''}}
                                    @endif

                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ইংরেজী') }}</th>
                                <td>
                                    @if(isset($audio->dcDirected->dcSentence->directed->english))
                                        {{$audio->dcDirected->dcSentence->directed->english ?? ''}}
                                    @elseif(isset($audio->dcWord->dcWordCollection->word->english))
                                        {{$audio->dcWord->dcWordCollection->word->english ?? ''}}
                                    @else
                                        {{$audio->dcSpontaneous->english?? ''}}
                                    @endif
                                </td>
                            </tr>

                            <tr>
                                <th>{{ __('উচ্চারণ') }}</th>
                                <td>
                                    @if(isset($audio->dcDirected->dcSentence->transcription))
                                        {{$audio->dcDirected->dcSentence->transcription ??''}}
                                    @elseif(isset($audio->dcWord->dcWordCollection->transcription))
                                        {{$audio->dcWord->dcWordCollection->transcription ??''}}
                                    @else
                                        {{$audio->dcSpontaneous->transcription?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ভাষা') }}</th>
                                <td>
                                    @if(isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->language->name ??''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->language->name ??''}}
                                    @else
                                        {{$audio->collection->language->name?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('অবস্থান') }}</th>
                                <td>
                                    @if(isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->district->name ??''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->district->name ??''}}
                                    @else
                                        {{$audio->collection->district->name?? ''}}
                                    @endif
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-5 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('কালেক্টর তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('গ্রুপের নাম') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        {{ $audio->dcDirected->collection->taskAssign->group->name?? ''}}
                                    @elseif (isset($audio->dcWord))
                                        {{ $audio->dcWord->collection->taskAssign->group->name?? ''}}
                                    @else
                                        {{$audio->collection->taskAssign->group->name?? ''}}
                                    @endif
                                    {{$audio->taskAssign->group->name ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('কালেক্টর নাম') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->collector->name?? ''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->collector->name??''}}
                                    @else
                                        {{$audio->collection->collector->name?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ইমেইল') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->collector->email?? ''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->collector->email??''}}
                                    @else
                                        {{$audio->collection->collector->email?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('জাতীয় পরিচয়পত্র') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->collector->nid?? ''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->collector->nid??''}}
                                    @else
                                        {{$audio->collection->collector->nid?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->collector->phone?? ''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->collector->phone??''}}
                                    @else
                                        {{$audio->collection->collector->phone?? ''}}
                                    @endif
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <hr>
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('স্পিকারের তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('স্পিকার নাম') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->speaker->name?? ''}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->speaker->name??''}}
                                    @else
                                        {{$audio->collection->speaker->name?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('লিঙ্গ') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        @if($audio->dcDirected->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->dcDirected->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @elseif(isset($audio->dcWord))
                                        @if($audio->dcWord->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->dcWord->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @else
                                        @if($audio->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->speaker->phone}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->speaker->phone}}
                                    @else
                                        {{$audio->collection->speaker->phone}}
                                    @endif

                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('বয়স') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->speaker->age}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->speaker->age}}
                                    @else
                                        {{$audio->collection->speaker->age}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('পেশা') }}</th>
                                <td>
                                    @if (isset($audio->dcDirected))
                                        {{$audio->dcDirected->collection->speaker->occupation}}
                                    @elseif(isset($audio->dcWord))
                                        {{$audio->dcWord->collection->speaker->occupation}}
                                    @else
                                        {{$audio->collection->speaker->occupation}}
                                    @endif
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
                @if(count($trims)>0)
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered" id="trim-collection">
                                    @if($audio->d_c_directed_id == $audio->id)
                                        <input class="form-check-input" id="d_c_directed_sentences_id" name ="d_c_directed_sentences_id"  type="hidden" value="{{$audio->id}}">
                                    @else
                                        <input class="form-check-input" id="d_c_spontaneouses_id" name ="d_c_spontaneouses_id"  type="hidden" value="{{$audio->id}}">
                                    @endif
                                    <thead class="table-info">
                                    <tr class="table-dark">
                                        <th colspan="7">{{__('messages.অডিও ট্রিমিং এর তালিকা')}}</th>
                                    </tr>
                                    <tr>
                                        <th scope="col">{{__('ক্রমিক')}}</th>
                                        <th scope="col">{{__('messages.অডিও ট্রিম')}}</th>
                                        <th scope="col">{{__('messages.বাংলা')}} </th>
                                        <th scope="col">{{__('messages.ইংরেজী')}}</th>
                                        <th scope="col">{{__('messages.উচ্চারণ')}} </th>
                                        <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                                    </tr>
                                    </thead>
                                    <tbody id="tbody">
                                    @foreach($trims as $key =>$trim)
                                        @php
                                            $audio = explode('/', $trim->audio);
                                            $uniqueCode=substr(end($audio), 0, -4);
                                        @endphp
                                        <tr>
                                            <td>{{$loop->iteration}}</td>
                                            <td class="align-middle text-center" >
                                                <button style="display: none;" class="myLink" onclick="waveSurferView({{ $trim }})"></button>
                                                <div id="waveform{{$uniqueCode}}"></div>
                                                <div id="waveform-time-indicator" class="justify-content-between">
                                                    <input type="button" id="play-pause{{$uniqueCode}}" value="Play"/>
                                                    <span id="total-time" class="time{{$uniqueCode}}">00:00:00</span>
                                                    <button class="btn btn-light btn-sm mb-1" value="{{$trim->audio}}" onclick="dowonloadFile()" >
                                                        {{__('ডাউনলোড')}}
                                                    </button>
                                                </div>
                                            </td>
                                            <td>{{$trim->bangla}}</td>
                                            <td>{{$trim->english}}</td>
                                            <td>{{$trim->transcription}}</td>
                                            @if(isset($trim))
                                                @if($trim->status == 0)
                                                    <td class="">
                                                        <i class="fa fa-times text-danger"></i>
                                                    </td>
                                                @elseif($trim->status == 2)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                                    </td>
                                                @elseif($trim->status == 1)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                                    </td>
                                                @elseif($trim->status == 3)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                                    </td>
                                                @endif

                                            @else
                                                <td>
                                                    <i class="fa fa-times text-danger"></i>
                                                </td>
                                            @endif
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                @endif
            </div>
        </div>
    </div>

@endsection
@section('language-js')
    <script>
        // aletify delete notification
        $(document).on('click', '.show_confirm', function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }

    </script>

@endsection

@extends('layouts.app')

@section('front-css')
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-ios.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intro.js/2.9.3/introjs.min.css">
@endsection

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                       {{-- <li class="breadcrumb-item"><a href="">{{__('messages.তথ্য সংগ্রহ')}}</a></li>--}}
                        <li class="breadcrumb-item active" aria-current="page">{{__('নির্দেশিত অডিও ট্রিমিং')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('সংগৃহীত ডাটার তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                @if (isset($audio->directed))
                                    <input type="hidden" id="audioType" value="directed">
                                    <th>{{ __('বিষয়') }}</th>
                                    <td>{{$audio->dcDirected->topic->name}}</td>
                                @endif
                                @if(isset($audio->spontaneous))
                                    <input type="hidden" id="audioType" value="spontaneous">
                                    <th>{{ __('টপিক') }}</th>
                                    <td>{{ $audio->spontaneous->word }}</td>
                                @endif
                            </tr>
                            <tr>
                                <th>{{ __('অডিও') }}</th>
                                <td>
                                    @php
                                        $audio_src  = file_get_contents($audio->audio);
                                        $audio_file = base64_encode($audio_src);
                                    @endphp
                                    <input type="hidden" id="audio" value="{{$audio->audio}}">
                                    <input type="hidden" id="audio_blob" value="{{$audio_file}}">
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                    </div>
                                </td>
                            </tr>
                            @if (isset($audio->directed))
                                <tr>
                                    <th>{{ __('বাংলা') }}</th>
                                    <td>{{$audio->directed->sentence}}</td>
                                </tr>
                                <tr>
                                    <th>{{ __('ইংরেজী') }}</th>
                                    <td>{{$audio->directed->english}}</td>
                                </tr>
                                <tr>
                                    <th>{{ __('উচ্চারণ') }}</th>
                                    <td>{{$audio->transcription}}</td>
                                </tr>
                            @endif
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-5 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('স্পিকারের তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('স্পিকার নাম') }}</th>
                                <td>
                                    {{$audio->dcDirected->collection->speaker->name??''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('লিঙ্গ') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        @if($audio->dcDirected->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->dcDirected->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>{{$audio->dcDirected->collection->speaker->phone??''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('বয়স') }}</th>
                                <td>
                                    {{$audio->dcDirected->collection->speaker->age?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('পেশা') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        {{$audio->dcDirected->collection->speaker->occupation}}
                                    @else
                                        {{$audio->collection->speaker->occupation}}
                                    @endif
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    {{--audiofly test start--}}
                    <div class="col-md-12 mb-4">
                        <div class="card card-body">
                            <div class="w3-container">
                                <div class="row">
                                    <div class="col-sm-7">
                                    </div>
                                    <div class="col-sm-1">
                                    </div>
                                    <div class="col-sm-3" data-toggle="tooltip" data-placement="top" title="{{__('জুম করতে হলে মিনিমাম ৫ সেকেন্ডের অডিও হতে হবে')}}">
                                        <input data-action="zoom" type="range" min="1" max="200" value="0" style="width: 100%" />
                                        {{-- <span>-</span> --}}
                                    </div>
                                    <div class="col-sm-1">
                                    </div>
                                </div>
                                <br>
                                <div id="waveform" class="w3-border w3-round-large"
                                     data-step="3" data-intro="Click and drag to select section">
                                </div>
                                <div id="wave-timeline">
                                </div>

                                <br>
                                <div class="w3-row">
                                    <div class="w3-half w3-container w3-hide" id="audio-buttons">
                                        <button class="w3-button w3-border w3-border-green w3-round-xlarge" onClick="playAndPause()">
                                            <i id="play-pause-icon" class="fa fa-play"></i>
                                        </button>
                                        <b id="time-current">0.00</b> / <b id="time-total">0.00</b><b>&nbsp Sec</b>
                                    </div>
                                    <div class="w3-half w3-container text-end">
                                        <span id="trim_audio" class="btn btn-success trim text-white" onClick="trimming()">{{__('messages.ট্রিম অডিও')}}</span>
                                        <div id="myImg">

                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div id="merge-option" class="w3-hide">
                                    <br><br>
                                    <div class="w3-row w3-hide" id="merged-track-div">
                                        <b class="w3-col l1 w3-text-olive"><i>Merged Audio : </i></b>
                                        <audio controls="controls" class="w3-col l11" id="merged-track">
                                            <source src="" type="">
                                        </audio>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div data-step="4" data-intro="Would you like to know how to merge tracks. Click Next.">
                                    <table class="w3-table-all w3-card-4" id="audio-tracks"
                                           data-step="5" data-intro="Select atleast 2 checkboxes for merging. Click Next.">
                                        <thead>
                                        <tr class="w3-border w3-border-teal w3-text-teal">
                                            <th></th>
                                            <th>{{__('messages.শুরুর সময়')}}</th>
                                            <th>{{__('messages.শেষের সময়')}}</th>
                                            <th>{{__('messages.অডিও শুনুন')}}</th>
                                            <th>{{__('messages.অ্যাকশন')}}</th>
                                        </tr>
                                        </thead>
                                        <tbody id="tableBody"></tbody>
                                        <tfoot></tfoot>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12">
                                <form action="{{ route('admin.replace-parent-trim-audio') }}" method="post" id="trimAudio">
                                    @csrf
                                    <div class="">
                                        <div id="form-hidden">
                                            <input type="hidden" name="audio_id" value="{{ $audio->id }}" />
                                            <input type="hidden" name="directed_id" value="{{ isset($audio->directed) ? $audio->directed->id : '' }}" />
                                        </div>
                                        <input type="hidden" name="type" value="{{ $type }}">
                                        <input type="hidden" name="spontaneous_id" value="{{ isset($audio->spontaneous) ? $audio->spontaneous_id : '' }}" />
                                        <input type="hidden" name="skip_time" id="skipTimeValue{{ $audio->id }}">
                                        <input type="hidden" name="audio_duration" id="audioDurationValue{{ $audio->id }}">
                                        <input type="hidden" id="trimTableId">
                                        <input type="hidden" name="is_directed" value="{{ isset($audio->directed) ? 1 : 0 }}">
                                        <input type="hidden" name="is_spontaneous" value="{{ isset($audio->spontaneous) ? 1 : 0 }}">
                                    </div>
                                    <div class="float-end mt-3">
                                        <input type="submit"  class="btn  btn-success show-submit trim-submit text-white" data-id="{{ $audio->id }}"  value="{{__('messages.জমা দিন')}}">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection
@section('language-js')
    <script>
        const timeString = '23:54:43';
        const other = '12:30:00';
        const withoutSeconds = '10:30';
        function countSeconds (str) {
            const [ mm = '0', ss = '0'] = (str || '0:0').split(':');
            const minute = parseInt(mm, 10) || 0;
            const second = parseInt(ss, 10) || 0;
            return  (minute*60) + (second);
        }
        var baseUrl = {!! json_encode(url('/')) !!}+ '/';

        $(document).ready(function (){
            $('.show-submit').css('display', 'none');
        })
        var audioId = {!! json_encode($audio->id) !!}
        $(document).on('click', 'input[data-checkbox="true"]', function (){
            var tdId = $(this).attr('data-id');
            $('#skipTime'+audioId).val('0:'+Math.round($('#'+tdId+1).text()));
            $('#audioDuration'+audioId).val('0:'+Math.round($('#'+tdId+2).text()));
            $('#trimTableId').val(tdId);
            $('#loader').show();
        })
    </script>

    <!-- Audio Trim Scripts -->
    <script>
        $(window).on('load',function (){
            var  get_file = $('#audio_blob').val();
            var  blob_file = urlB64ToUint8Array(get_file)
            loadAudio(blob_file);
            $('#trim_audio').text('রিফ্রেশ করুন');
            $('#trim_audio').removeClass('btn-success');
            $('#trim_audio').addClass('btn-danger');
        })

        function trimming(){
            var  get_file = $('#audio_blob').val();
            var  blob_file = urlB64ToUint8Array(get_file)
            loadAudio(blob_file);
            $('#trim_audio').text('রিফ্রেশ করুন');
            $('#trim_audio').removeClass('btn-success');
            $('#trim_audio').addClass('btn-danger');
        }

        function urlB64ToUint8Array(base64){
            var arr = base64.split(',');
            if (arr.length != 2) {
                bstr = atob(base64);
                var ourputArray = new Uint8Array(bstr.length);
                for (let i = 0; i < bstr.length; i++) {
                    ourputArray[i] = bstr.charCodeAt(i);
                }
                const blob = new Blob([ourputArray], {type: 'audio/mp3'});
                return blob;
            }else{
                mime = arr[0].match(/:(.*?);/)[1];
                bstr = atob(arr[1]);
                var ourputArray = new Uint8Array(bstr.length);
                for (let i = 0; i < bstr.length; i++) {
                    ourputArray[i] = bstr.charCodeAt(i);
                }
                const blob = new Blob([ourputArray], {type: 'audio/mp3'});
                return blob;
            }
        }
    </script>
    <style>
        .show-me {
            display: contents!important;
        }
    </style>
    <script>
        $(document).on('click',function () {
            $('.w3-table-all tbody tr').css('display', 'none')
            $('.w3-table-all>tbody>tr:first').addClass('show-me');
        })
    </script>
    <script>
        $('body').on('click', '.trim-submit', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি অডিওটি পরিবর্তন করে নতুন অডিওটি সেভ করতে চান ? নতুন অডিওটি সেভ করলে আগের অডিওটি মুছে যাবে ।')}}",
                text: "{{__('আপনি কি নিশ্চিত যে নতুন অডিওটি সেভ করবেন ?')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '28px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });
    </script>
@endsection

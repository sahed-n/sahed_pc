@extends('layouts.app')
@section('title', 'অনুমোদিত ডাটার তালিকা')
@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('অনুমোদিত ডাটা')}}</li>
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                {{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="data-collection">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">{{__('ক্রমিক')}}</th>
                            <th scope="col">{{__('ভাষা')}}</th>
                            <th scope="col">{{__('কালেক্টর')}}</th>
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col">{{__('শব্দ/টপিক/বাক্য')}}</th>
                            <th scope="col">{{__('অডিও')}}</th>
                            <th scope="col">{{__('স্ট্যাটাস')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $key=>$dataCollection)
                            <tr>
                                <td>{{$loop->iteration }}</td>
                                <td class="small">
                                    <div class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{ __('ভাষা') }}">
                                        @if(isset($dataCollection->dcSpontaneous->collection->language))
                                            {{$dataCollection->dcSpontaneous->collection->language->name}}
                                        @endif
                                        @if(isset($dataCollection->dcDirected->collection->language->name))
                                            {{$dataCollection->dcDirected->collection->language->name}}
                                        @endif
                                        @if(isset($dataCollection->dcWord->collection->language))
                                            {{$dataCollection->dcWord->collection->language->name}}
                                        @endif
                                    </div>
                                    <div class="text-medium-emphasis">
                                        <span data-toggle="tooltip" data-placement="top" title="{{ __('অবস্থান') }}">
                                             @if(isset($dataCollection->dcSpontaneous->collection->district))
                                                {{$dataCollection->dcSpontaneous->collection->district->name}}
                                            @endif
                                            @if(isset($dataCollection->dcDirected->collection->district))
                                                {{$dataCollection->dcDirected->collection->district->name}}
                                            @endif
                                            @if(isset($dataCollection->dcWord->collection->district))
                                                {{$dataCollection->dcWord->collection->district->name}}
                                            @endif
                                        </span>
                                    </div>
                                    <div class="text-medium-emphasis">
                                        <span data-toggle="tooltip" data-placement="top" title="{{ __('স্পিকার') }}">
                                            @if(isset($dataCollection->dcSpontaneous->collection->speaker))
                                                {{$dataCollection->dcSpontaneous->collection->speaker->name}}
                                            @endif
                                            @if(isset($dataCollection->dcDirected->collection->speaker))
                                                {{$dataCollection->dcDirected->collection->speaker->name}}
                                            @endif
                                            @if(isset($dataCollection->dcWord->collection->speaker))
                                                {{$dataCollection->dcWord->collection->speaker->name}}
                                            @endif
                                        </span>

                                    </div>
                                </td>
                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous->collection->collector))
                                        {{$dataCollection->dcSpontaneous->collection->collector->name}}
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection->collector))
                                        {{$dataCollection->dcDirected->collection->collector->name}}
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection->collector))
                                        {{$dataCollection->dcWord->collection->collector->name}}
                                    @endif
                                </td>
                                <td class="small collectionType">
                                    @if(isset($dataCollection->dcSpontaneous->collection))
                                        @if($dataCollection->dcSpontaneous->collection->type_id == 2)
                                            <span class="badge bg-success">{{__('স্বতঃস্ফূর্ত')}}</span>
                                        @endif
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection))
                                        @if($dataCollection->dcDirected->collection->type_id == 1)
                                            <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                                        @endif
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection))
                                        @if($dataCollection->dcWord->collection->type_id == 0)
                                            <span class="badge bg-success">{{__('শব্দ ও ব্যাকরণ')}}</span>
                                        @endif
                                    @endif
                                </td>

                                <td class="small">
                                    @if(isset($dataCollection->dcSpontaneous))

                                        <div class="small badge bg-primary-new  mb-1" data-toggle="tooltip" data-placement="top" title="{{ __('টপিক') }}">{{$dataCollection->dcSpontaneous->spontaneous->word}}</div>
                                        <div class="">
                                            <span class="" data-toggle="tooltip" data-placement="top" title="{{ __('স্বতঃস্ফূর্ত ট্রিমের অংশ') }}">{{$dataCollection->bangla}}</span>
                                        </div>
                                    @endif
                                    @if(isset($dataCollection->dcDirected->collection))

                                        <div class="small badge bg-primary-new  mb-1" data-toggle="tooltip" data-placement="top" title="{{ __('বিষয়') }}">{{$dataCollection->dcDirected->topic->name}}</div>
                                        <div class="">
                                            <span class="" data-toggle="tooltip" data-placement="top" title="{{ __('নির্দেশিত বাক্য') }}">{{$dataCollection->directed->sentence}}</span>
                                        </div>
                                    @endif
                                    @if(isset($dataCollection->dcWord->collection))
                                        <div class="small badge bg-primary-new  mb-1" data-toggle="tooltip" data-placement="top" title="{{ __('শব্দ') }}">{{$dataCollection->dcWord->topicWord->name}}</div>
                                        <div class="">
                                            <span class="" data-toggle="tooltip" data-placement="top" title="{{ __('বাক্য') }}">{{$dataCollection->word->sentence}}</span>
                                        </div>

                                    @endif
                                </td>
                                @if(isset($dataCollection))
                                    @php
                                        $audio = explode('/', $dataCollection->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                        $uniqueCode= str_replace('.', '', $uniqueCode);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 14rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif
                                <td class="small">
                                    <span class="badge rounded-pill bg-success">{{__('অনুমোদিত')}}</span>
                                </td>

                                {{--<td class="align-middle">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">

                                        @if($dataCollection->collection)
                                            <a class="btn btn-info btn-sm" href="{{route('admin.data_collections.show', $dataCollection->id)}}">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-low-vision')}}"></use>
                                                </svg>
                                            </a>
                                        @else
                                            <a class="btn btn-info btn-sm" href="{{route('admin.data_collections.directed.show', $dataCollection->id)}}">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-low-vision')}}"></use>
                                                </svg>
                                            </a>
                                        @endif
                                        @if($dataCollection->collection)
                                            --}}{{-- <a class="btn btn-purple btn-sm" href="{{route('admin.data_collections.edit', $dataCollection->id)}}">
                                                 <svg class="icon  text-white">
                                                     <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-check')}}"></use>
                                                 </svg>
                                             </a>--}}{{--
                                            <form action="{{ route('admin.data_collections.destroy', $dataCollection->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-danger btn-sm show_confirm">
                                                    <svg class="icon  text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                    </svg>
                                                </button>
                                            </form>
                                        @else
                                            --}}{{--<a class="btn btn-purple btn-sm" href="{{route('admin.data_collections.directed.edit', $dataCollection->id)}}">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-check')}}"></use>
                                                </svg>
                                            </a>--}}{{--
                                            <form action="{{ route('admin.data_collections.directed.destroy', $dataCollection->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-danger btn-sm show_confirm">
                                                    <svg class="icon  text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                    </svg>
                                                </button>
                                            </form>
                                        @endif


                                    </div>
                                </td>--}}
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">

        // alertify delete notification
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        // tooltip
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        })

        $('.collectionType').hover(function() {
            $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
        }, function() {
            $(this).find('.badge').addClass('bg-success').removeClass('bg-danger');
        });

        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }
    </script>
@endsection


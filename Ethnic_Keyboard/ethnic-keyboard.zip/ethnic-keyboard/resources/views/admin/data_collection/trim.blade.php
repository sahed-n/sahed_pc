@extends('layouts.app')

@section('front-css')
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-colors-ios.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intro.js/2.9.3/introjs.min.css">
@endsection

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header pb-0">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{ URL::previous() }}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('অডিও ট্রিমিং')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('সংগৃহীত ডাটার তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                @if (isset($audio->directed))
                                    <input type="hidden" id="audioType" value="directed">
                                    <th>{{ __('বিষয়') }}</th>
                                    <td>{{$audio->dcDirected->topic->name}}</td>
                                @endif
                                @if(isset($audio->spontaneous))
                                    <input type="hidden" id="audioType" value="spontaneous">
                                    <th>{{ __('টপিক') }}</th>
                                    <td>{{ $audio->spontaneous->word }}</td>
                                @endif
                            </tr>
                            <tr>
                                <th>{{ __('অডিও') }}</th>
                                <td>
                                    @php
                                        $audio_src  = file_get_contents($audio->audio);
                                        $audio_file = base64_encode($audio_src);
                                    @endphp
                                    <input type="hidden" id="audio" value="{{$audio->audio}}">
                                    <input type="hidden" id="audio_blob" value="{{$audio_file}}">
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                    </div>
                                </td>
                            </tr>
                            {{--<tr>
                                <th>{{ __('টাইপ') }}</th>
                                <td class="">{{__('স্বতঃস্ফূর্ত')}}</td>
                            </tr>--}}
                            @if (isset($audio->directed))
                                <tr>
                                    <th>{{ __('বাংলা') }}</th>
                                    <td>{{$audio->directed->sentence}}</td>
                                </tr>
                                <tr>
                                    <th>{{ __('ইংরেজী') }}</th>
                                    <td>{{$audio->directed->english}}</td>
                                </tr>
                                <tr>
                                    <th>{{ __('উচ্চারণ') }}</th>
                                    <td>{{$audio->transcription}}</td>
                                </tr>
                            @endif
                            {{-- <tr>
                                 <th>{{ __('সংগ্রহের তারিখ') }}</th>
                                 <td>{{showDate($audio->created_at?? '')}}</td>
                             </tr>--}}
                            </tbody>
                        </table>

                    </div>
                    <div class="col-md-5 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('স্পিকারের তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('স্পিকার নাম') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        {{$audio->dcDirected->collection->speaker->name}}
                                    @else
                                        {{$audio->collection->speaker->name}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('লিঙ্গ') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        @if($audio->dcDirected->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->dcDirected->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @else
                                        @if($audio->collection->speaker->gender == 0)
                                            {{__('messages.পুরুষ')}}
                                        @elseif($audio->collection->speaker->gender== 1)
                                            {{__('messages.মহিলা')}}
                                        @else
                                            {{__('messages.অন্যান্য')}}
                                        @endif
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>{{ $dataCollection->speaker->phone?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('বয়স') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        {{$audio->dcDirected->collection->speaker->age}}
                                    @else
                                        {{$audio->collection->speaker->age}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('পেশা') }}</th>
                                <td>
                                    @if (isset($audio->directed))
                                        {{$audio->dcDirected->collection->speaker->occupation}}
                                    @else
                                        {{$audio->collection->speaker->occupation}}
                                    @endif
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="row">
                    {{--audiofly test start--}}
                    <div class="col-md-12 mb-4">
                        <div class="card card-body">
                            <div class="w3-container">
                                <div class="row">
                                    <div class="col-sm-7">
                                    </div>
                                    <div class="col-sm-1">
                                    </div>
                                    <div class="col-sm-3" data-toggle="tooltip" data-placement="top" title="{{__('জুম করতে হলে মিনিমাম ৫ সেকেন্ডের অডিও হতে হবে')}}">
                                        <input data-action="zoom"  type="range" min="1" max="200" value="0" style="width: 100%" />
                                    </div>
                                    <div class="col-sm-1">
                                    </div>
                                </div>
                                <br>
                                <div id="waveform" class="w3-border w3-round-large"
                                     data-step="3" data-intro="Click and drag to select section">
                                </div>
                                <div id="wave-timeline"></div>
                                <br>
                                <div class="w3-row">
                                    <div class="w3-half w3-container w3-hide" id="audio-buttons">
                                        <button class="w3-button w3-border w3-border-green w3-round-xlarge" onClick="playAndPause()">
                                            <i id="play-pause-icon" class="fa fa-play"></i>
                                        </button>

                                        <b id="time-current">0.00</b> / <b id="time-total">0.00</b><b>&nbsp Sec</b>
                                    </div>
                                    <div class="w3-half w3-container text-end">
                                        <span id="trim_audio" class="btn btn-success {{--trim--}} text-white" onClick="trimming()">{{__('messages.ট্রিম অডিও')}}</span>
                                        <div id="myImg">

                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div id="merge-option" class="w3-hide">
                                    <br><br>
                                    <div class="w3-row w3-hide" id="merged-track-div">
                                        <b class="w3-col l1 w3-text-olive"><i>Merged Audio : </i></b>
                                        <audio controls="controls" class="w3-col l11" id="merged-track">
                                            <source src="" type="">
                                        </audio>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{--audiofly test end--}}
                </div>
                <div class="card mb-3">
                    <div class="card-body">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <div class="alert alert-danger print-error-msg" style="display:none">
                            <ul></ul>
                        </div>
                        <div class="row">
                            <div class="col-md-7 col-sm-12">
                                <div data-step="4" data-intro="Would you like to know how to merge tracks. Click Next.">
                                    <table class="w3-table-all w3-card-4" id="audio-tracks"
                                           data-step="5" data-intro="Select atleast 2 checkboxes for merging. Click Next.">
                                        <thead>
                                        <tr class="w3-border w3-border-teal w3-text-teal">
                                            <th></th>
                                            <th>{{__('messages.শুরুর সময়')}}</th>
                                            <th>{{__('messages.শেষের সময়')}}</th>
                                            <th>{{__('messages.অডিও শুনুন')}}</th>
                                            {{--<th>Download</th>--}}
                                            <th>{{__('messages.অ্যাকশন')}}</th>
                                        </tr>
                                        </thead>
                                        <tbody></tbody>
                                        <tfoot></tfoot>
                                    </table>
                                </div>
                            </div>

                            <div class="col-md-5 col-sm-12">
                                <form action="{{ route('trim-audio') }}" method="post" id="trimAudio">
                                    @csrf
                                    <div class="">
                                        <div id="form-hidden">
                                            <input type="hidden" name="audio_id" value="{{ $audio->id }}" />
                                            <input type="hidden" name="directed_id" value="{{ isset($audio->directed_id) ? $audio->directed_id : '' }}" />
                                        </div>

                                        <input type="hidden" name="spontaneous_id" value="{{ isset($audio->spontaneous_id) ? $audio->spontaneous_id : '' }}" />
                                        <input type="hidden" name="skip_time" id="skipTimeValue{{ $audio->id }}">
                                        <input type="hidden" name="audio_duration" id="audioDurationValue{{ $audio->id }}">
                                        <input type="hidden" id="trimTableId">
                                        <input type="hidden" id="audioStartTime" name="start_time">
                                    </div>
                                    <div class="row mb-2">
                                        <label for="">{{__('messages.বাংলা')}}<span class="text-danger">*</span></label>
                                        <div class="input-group ">
                                            <textarea name="bangla" class="form-control" id="banglaInput" cols="30" rows="2" ></textarea>
                                        </div>

                                        <span class="text-danger error-text bangla_err"></span>
                                    </div>
                                    <div class="row mb-2">
                                        <label  for="">{{__('messages.অনুবাদ')}} <span class="text-danger"></span></label>
                                        <div class="input-group ">
                                            <textarea name="english" class="form-control" id="englishInput" cols="30" rows="2" ></textarea>
                                        </div>
                                        <span class="text-danger error-text english_err"></span>
                                    </div>
                                    <div class="row mb-2">
                                        <label for="">{{__('messages.উচ্চারণ')}} <span class="text-danger"></span></label>
                                        <div class="input-group  ">
                                            <textarea name="transcription" class="form-control" id="transcriptionInput" cols="30" rows="2"></textarea>
                                        </div>
                                        <span class="text-danger error-text transcription_err"></span>
                                    </div>
                                    <div class="float-end">
                                        <input type="submit"  class="btn  btn-success trim trim-submit show-submit text-white" data-id="{{ $audio->id }}" value="{{__('messages.ট্রিম')}}">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <form action="{{route('admin.send.trim.pending', $audio->id)}}" method="post" >
                            @csrf
                            @method("PUT")
                            <table class="table table-bordered table-hover table-responsive" id="trim-collection">
                                @if($audio->d_c_directed_id != null)
                                    <input class="form-check-input" id="d_c_directed_sentences_id" name ="d_c_directed_sentences_id"  type="hidden" value="{{$audio->id}}">
                                @else
                                    <input class="form-check-input" id="d_c_spontaneouses_id" name ="d_c_spontaneouses_id"  type="hidden" value="{{$audio->id}}">
                                @endif
                                <thead class="table-info">
                                <tr class="table-dark">
                                    <th colspan="7">{{__('messages.অডিও ট্রিমিং এর তালিকা')}}</th>
                                </tr>
                                <tr>
                                    <th scope="col" style="width: 8rem;">
                                        <input class="form-check-input" id="all-trim-select"  type="checkbox">
                                        {{__('সব নির্বাচন')}}
                                    </th>
                                    <th scope="col">{{__('messages.অডিও ট্রিম')}} </th>
                                    <th scope="col">{{__('শুরুর সময়')}} </th>
                                    <th scope="col">{{__('messages.বাংলা')}} </th>
                                    <th scope="col">{{__('messages.উচ্চারণ')}} </th>
                                    <th scope="col">{{__('messages.মেসেজ')}} </th>
                                    <th scope="col">{{__('messages.অ্যাকশন')}}</th>
                                </tr>
                                </thead>
                                <tbody id="tbody">

                                </tbody>
                            </table>
                            <div class="row " id="trim-button" style="display: none;">
                                <div class="col-12 text-end">
                                    <button class="btn btn-success text-white" type="submit">
                                        <svg class="icon  text-white">
                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-check')}}"></use>
                                        </svg>
                                        {{__('messages.জমা দিন')}}
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="updateTrimModal" tabindex="-1" aria-labelledby="updateTrimModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <form action="{{ url('/update-audio-trim') }}" method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="updateTrimModalLabel">{{ __('ট্রিম আপডেট') }}</h5>
                        <button type="button" class="btn-close modal-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        @csrf
                        <input type="hidden" name="audio_trim_id" id="audioTrimId" />
                        <div class="row mb-3">
                            <label for="">{{__('messages.বাংলা')}}<span class="text-danger">*</span></label>
                            <div class="input-group ">
                                <textarea name="bangla" class="form-control" id="banglaInputModal" cols="30" rows="3" ></textarea>
                            </div>
                            <span class="text-danger error-text bangla_err"></span>
                        </div>
                        <div class="row mb-3">
                            <label  for="">{{__('messages.অনুবাদ')}}</label>
                            <div class="input-group ">
                                <textarea name="english" class="form-control" id="englishInputModal" cols="30" rows="3" ></textarea>
                            </div>
                            <span class="text-danger error-text english_err"></span>
                        </div>
                        <div class="row mb-3">
                            <label for="">{{__('messages.উচ্চারণ')}}</label>
                            <div class="input-group  ">
                                <textarea name="transcription" class="form-control" id="transcriptionInputModal" cols="30" rows="3"></textarea>
                            </div>
                            <span class="text-danger error-text transcription_err"></span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger modal-close" data-bs-dismiss="modal">{{__('বন্ধ করুন')}}</button>
                        <button type="submit" class="btn btn-primary">{{__('আপডেট')}}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('language-js')

    <script>

        $(document).ready(function (){
            $('.show-submit').css('display', 'none');
        })

        $(document).on('change', "input[type='checkbox'].trim-checked", function() {
            var a = $("input[type='checkbox'].trim-checked");
            if(a.length == a.filter(":checked").length){
                $('input:checkbox').not(this).prop('checked', this.checked);
                var x = document.getElementById("trim-button");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
            }
            if (a.length !== a.filter(":checked").length){
                var x = document.getElementById("trim-button");
                x.style.display = "none";
            }

        });

        $("#all-trim-select").on('click', function(){
            $('input:checkbox').not(this).prop('checked', this.checked);
            var a = $("input[type='checkbox'].trim-checked");
            if(a.length == a.filter(":checked").length) {
                var x = document.getElementById("trim-button");
                if (x.style.display === "none") {
                    x.style.display = "block";
                } else {
                    x.style.display = "none";
                }
            }
            if (a.length !== a.filter(":checked").length){
                var x = document.getElementById("trim-button");
                x.style.display = "none";
            }
        });

        const timeString = '23:54:43';
        const other = '12:30:00';
        const withoutSeconds = '10:30';
        function countSeconds (str) {
            const [ mm = '0', ss = '0'] = (str || '0:0').split(':');
            const minute = parseInt(mm, 10) || 0;
            const second = parseInt(ss, 10) || 0;
            return  (minute*60) + (second);
        }
        var baseUrl = {!! json_encode(url('/')) !!}+ '/';

        var audioId = {!! json_encode($audio->id) !!}
        $(document).on('click', 'input[data-checkbox="true"]', function (){
            var tdId = $(this).attr('data-id');
            $('#skipTime'+audioId).val('0:'+Math.round($('#'+tdId+1).text()));
            $('#audioDuration'+audioId).val('0:'+Math.round($('#'+tdId+2).text()));
            $('#trimTableId').val(tdId);
            var checkedInputTrSelector = $('input[name="checkbox"]:checked').data('id');
            var trimAudioStartTime = $('#'+checkedInputTrSelector+'1').text();
            $('#audioStartTime').val(trimAudioStartTime);
            $('#loader').show();
        })

        // delete Alert message
        $('body').on('click', '.show_confirm', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি  এই ট্রিম অডিও টি মুছে ফেলতে চান ?')}}",
                text: "{{__('যদি এটি মুছে ফেলেন তাহলে অডিওটি চিরতরে মুছে যাবে !')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '28px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });
        $(document).ready(function() {
            $(".trim").click(function(e){
                e.preventDefault();
                var audioId = $(this).data('id');
                var skipTime = $('#skipTime'+audioId).val();
                var x = countSeconds(skipTime);
                $('#skipTimeValue'+audioId).val(countSeconds(skipTime));
                var audioTrim = $('#audioDuration'+audioId).val();
                var y = countSeconds(audioTrim);
                $('#audioDurationValue'+audioId).val(y-x);
                var audio_id = $('input[name="audio_id"]').val();
                var directed_id = $('input[name="directed_id"]').val();
                var spontaneous_id = $('input[name="spontaneous_id"]').val();
                var skip_time = $('input[name="skip_time"]').val();
                var audio_duration = $('input[name="audio_duration"]').val();
                var bangla = $('textarea[name="bangla"]').val();
                var english = $('textarea[name="english"]').val();
                var transcription = $('textarea[name="transcription"]').val();
                var trimRowId = $('#trimTableId').val();
                var get_audio_base64 = $('#trim_base64').val();
                $('#loader').show();
                // set start time
                var checkedInputTrSelector = $('input[name="checkbox"]:checked').data('id');
                var trimAudioStartTime = $('#'+checkedInputTrSelector+'1').text();

                $.ajax({
                    url: "{{ route('trim-audio') }}",
                    method: 'POST',
                    dataType: 'JSON',
                    data: {bangla:bangla,english:english,transcription:transcription,audio_id:audio_id,directed_id:directed_id,spontaneous_id:spontaneous_id,
                        skip_time:skip_time,audio_duration:audio_duration,audio_file:get_audio_base64,start_time:trimAudioStartTime},
                    success: function (data) {
                        //console.log(data);
                        toastr.success(data.msg);
                        if($.isEmptyObject(data.error)){
                            $('#banglaInput').val('');
                            $('#englishInput').val('');
                            $('#transcriptionInput').val('');
                            $('.start-time-input').val('');
                            $('.end-time-input').val('');
                            $('#trim_base64').remove();
                            $('#'+trimRowId).remove();
                        }
                    },
                    complete: function(){
                        $('#loader').hide();
                    },
                    error: function (data) {
                        var errors = data.responseJSON;
                        var error = errors.errors;
                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "progressBar": true,
                            "positionClass": "toast-top-center",
                            "showMethod" : "slideDown",
                            "hideMethod" : "slideUp"
                        }
                        $.each(error, function (key, value) {
                            toastr.error(value[0]);
                        });
                    }
                })
            })
            function printErrorMsg (msg) {
                $.each( msg, function( key, value ) {
                    $('.'+key+'_err').text(value);
                });
            }
        } );

        $(document).ready(function(event) {
            var audioID = $('input[name="audio_id"]').val();
            var Type = $('#audioType').val();
            console.log(audioID)
            console.log(Type)
            function ajax(){
                $('#loader').show();
                $.ajax({
                    type : 'GET',
                    dataType: "json",
                    url  : "{{ route('get-trim-audios') }}",
                    data : {id: audioID, type:Type},
                    success : function (res) {
                        table_audios_row(res);
                    },
                    complete: function(){
                        $('#loader').hide();
                    },
                });
            }
            ajax();
            $(document).on('click','.trim', function() {
                setTimeout(function(e) {
                    ajax();
                }, 3000);
            });

            // table row with ajax
            function table_audios_row(res){
                let htmlView = '';
                if(res.audios.length <= 0){
                    htmlView+= `
                    <tr class="text-center">
                      <td colspan="7">{{__('কোন ডাটা নেই।')}}</td>
                     </tr>`;
                }
                for(let i = 0; i < res.audios.length; i++){
                    htmlView += `
          <tr>
             <td><input class="form-check-input trim-checked" type="checkbox" name="status[]" value="`+res.audios[i].id+`"> `+ (i+1) +`</td>
             <td class="align-middle text-center" >
                <audio src="`+baseUrl+res.audios[i].audio+`" controls>
                     <source src="`+baseUrl+res.audios[i].audio+`" type="audio/*">
                </audio>
             </td>
             <td class=" text-center badge bg-dark text-white text-hover">`+res.audios[i].start_time+`</td>
             <td class="badge-custom text-hover">`+res.audios[i].bangla+`</td>`

              if(res.audios[i].transcription == null){
                        htmlView += `<td></td>`
                }else {
                    htmlView += `<td class="badge-custom text-hover">`+res.audios[i].transcription+`</td>`
                }
                if(res.audios[i].comment == null){
                    htmlView += `<td></td>`
                }else {
                    htmlView += `<td>`+res.audios[i].comment+`</td>`
                }
                htmlView += `
                <td>
                    <div class="d-grid gap-2 d-md-flex justify-content-start">
                         <button type="button" class="btn btn-primary btn-sm" id="modalBtn" data-audio-trim-id="`+res.audios[i].id+`" data-bs-toggle="modal" data-bs-target="#updateTrimModal">
                      <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                        <form action="`+baseUrl+`delete-trim-audios/`+res.audios[i].id+`" method="post">
                            @csrf
                            <button class="btn btn-danger btn-sm show_confirm">
                                <svg class="icon  text-white">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                </svg>
                            </button>
                        </form>
                    </div>

                </td>
            </tr>
            `;
                }
                $('#tbody').html(htmlView);
            }
        });

        $(document).on('click', '#modalBtn', function () {
            var audioTrimId = $(this).attr('data-audio-trim-id');
            $('#audioTrimId').val(audioTrimId);
            $.ajax({
                url: "{{ url('/get-audio-trim-data') }}/"+audioTrimId,
                dataType: "JSON",
                method: "GET",
                success: function (data) {
                    /*console.log(data.bangla);*/
                    $('#banglaInputModal').val(data.bangla);
                    $('#englishInputModal').val(data.english);
                    $('#transcriptionInputModal').val(data.transcription);
                    $('#updateTrimModal').modal('show');
                }
            })

        })

        $(document).on('click', '.modal-close', function () {
            $('#updateTrimModal').modal('hide');
        })

        $(window).on('load',function (){
            var audioUrl = baseUrl+{!! json_encode($audio->audio) !!};
            var rootUrl = {!! json_encode(asset('/')) !!};
            // window.location.href = audioUrl;
            /* var link = document.createElement('a');
             document.body.appendChild(link);
             link.href=audioUrl;
             link.download= "file_"+new Date() +'.mp3';
             link.click();
             link.remove();*/
        })

    </script>

    <!-- Audio Trim Scripts -->
    <script>
        $(window).on('load',function (){
            var  get_file = $('#audio_blob').val();
            var  blob_file = urlB64ToUint8Array(get_file)
            loadAudio(blob_file);

            $('#trim_audio').text('রিফ্রেশ করুন');
            $('#trim_audio').removeClass('btn-success');
            $('#trim_audio').addClass('btn-danger');
        })

        function trimming(){
            var  get_file = $('#audio_blob').val();
            var  blob_file = urlB64ToUint8Array(get_file)
            loadAudio(blob_file);

            $('#trim_audio').text('রিফ্রেশ করুন');
            $('#trim_audio').removeClass('btn-success');
            $('#trim_audio').addClass('btn-danger');
        }

        function urlB64ToUint8Array(base64){

            var arr = base64.split(',');

            if (arr.length != 2) {

                bstr = atob(base64);
                var ourputArray = new Uint8Array(bstr.length);

                for (let i = 0; i < bstr.length; i++) {

                    ourputArray[i] = bstr.charCodeAt(i);
                }

                const blob = new Blob([ourputArray], {type: 'audio/mp3'});
                return blob;
            }else{

                mime = arr[0].match(/:(.*?);/)[1];
                bstr = atob(arr[1]);
                var ourputArray = new Uint8Array(bstr.length);

                for (let i = 0; i < bstr.length; i++) {

                    ourputArray[i] = bstr.charCodeAt(i);
                }

                const blob = new Blob([ourputArray], {type: 'audio/mp3'});
                return blob;
            }

        }

        @if ($errors->any())
        @foreach ($errors->all() as $error)
        toastr.error('{{ $error }}', 'Error', {
            closeButton: true,
            progressBar: true,
            "positionClass": "toast-top-center",
            "showMethod" : "slideDown",
            "hideMethod" : "slideUp"
        });
        @endforeach
        @endif
    </script>
@endsection

@extends('layouts.app')

@section('title', 'ডাটা কালেক্টর তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.data_collections.index')}}">{{__('messages.তথ্য সংগ্রহ')}}</a></li>
                        @if(!empty($firstItem))
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->language->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->district->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->collector->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->speaker->name}}</li>
                        @endif
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 4rem;">{{__('messages.ক্রমিক নং')}}</th>
                            <th scope="col">{{__('messages.টাইপ')}}</th>
                            <th scope="col">{{__('messages.অডিও')}}</th>
                            <th scope="col" style="width: 14rem;">{{__('শব্দ/টপিক/বাক্য')}}</th>
                            <th scope="col">{{__('সংগ্রহের তারিখ')}}</th>
                            {{--<th scope="col">{{__('messages.স্ট্যাটাস')}}</th>--}}
                            <th scope="col">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $key=>$dataCollection)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td class="collectionType">
                                    @if($dataCollection->type_id == 1)
                                        <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                                    @elseif($dataCollection->type_id == 2)
                                        <span class="badge bg-success"> {{__('স্বতঃস্ফূর্ত')}}</span>
                                    @else
                                        <span class="badge bg-success"> {{__('শব্দ ও ব্যাকরণ')}}</span>
                                    @endif
                                </td>
                                @if($dataCollection->dcDirected)
                                    @php
                                        if($dataCollection->dcDirected->dcSentence->audio != null){
                                            $audio = explode('/', $dataCollection->dcDirected->dcSentence->audio);
                                            $uniqueCode=substr(end($audio), 0, -4);
                                            $uniqueCode= str_replace('.', '', $uniqueCode);
                                        }
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 10rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcDirected->dcSentence??'' }})"></button>
                                        <div id="waveform{{$uniqueCode}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcDirected->dcSentence->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>

                                        </div>
                                    </td>
                                @elseif(isset($dataCollection->dcWord))
                                    @php
                                        $audio = explode('/', $dataCollection->dcWord->dcWordCollection->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                        $uniqueCode= str_replace('.', '', $uniqueCode);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 10rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcWord->dcWordCollection??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcWord->dcWordCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @else
                                    @php

                                        if(isset($dataCollection->dcSpontaneous)){
                                                        $audio = explode('/', $dataCollection->dcSpontaneous->audio);
                                                $uniqueCode=substr(end($audio), 0, -4);
                                                    }
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 13rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcSpontaneous??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time{{$uniqueCode}}" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcSpontaneous->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>

                                        </div>
                                    </td>
                                @endif

                                @if(isset($dataCollection->dcSpontaneous))
                                    @if(Auth::user()->user_type == 4)
                                        <td class="topic badge-custom text-hover" data-toggle="tooltip" data-placement="top" title="{{__('টপিক')}}">
                                            {{$dataCollection->dcSpontaneous->spontaneous->word?? ''}}
                                            {{-- <a href="{{route('admin.data_collections.spontaneous.edit', $dataCollection->dcSpontaneous->id)}}"><i class="fas fa-edit"></i></a>--}}
                                        </td>
                                    @else
                                        <td class="topic badge-custom text-hover" data-toggle="tooltip" data-placement="top" title="{{__('টপিক')}}">
                                            {{$dataCollection->dcSpontaneous->spontaneous->word?? ''}}
                                        </td>
                                    @endif
                                @elseif(isset($dataCollection->dcDirected->dcSentence->directed))
                                    @if(Auth::user()->user_type == 4)
                                        <td class="sentence">
                                            <span class="badge-custom" data-toggle="tooltip" data-placement="top" title="{{__('বাক্য')}}">
                                            {{$dataCollection->dcDirected->dcSentence->directed->sentence?? ''}}
                                            </span>
                                            {{--<a href="{{route('admin.data_collections.directed.edit', $dataCollection->dcDirected->dcSentence->id)}}"><i class="fas fa-edit"></i></a>--}}
                                        </td>
                                    @else
                                        <td class="sentence">
                                            <span class="badge-custom" data-toggle="tooltip" data-placement="top" title="{{__('বাক্য')}}">
                                            {{$dataCollection->dcDirected->dcSentence->directed->sentence?? ''}}
                                            </span>
                                        </td>
                                    @endif
                                @else
                                    <td class="word badge-custom text-hover" data-toggle="tooltip" data-placement="top" title="{{__('শব্দ')}}">
                                        {{$dataCollection->dcWord->dcWordCollection->word->sentence??''}}
                                    </td>
                                @endif
                                <td class="small">{{showDate($dataCollection->created_at)}}</td>
                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-start">
                                        @if(isset($dataCollection->dcDirected))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.data_collections.trim.show',['type'=>isset($dataCollection->dcDirected) ? 'directed' : '', 'id' => $dataCollection->dcDirected->dcSentence->id]) }}">
                                                <i class="text-white far fa-eye"></i>
                                            </a>
                                        @endif
                                        @if(isset($dataCollection->dcSpontaneous))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.data_collections.trim.show',['type'=>isset($dataCollection->dcSpontaneous) ? 'spontaneous' : '', 'id' => $dataCollection->dcSpontaneous->id]) }}">
                                                <i class="text-white far fa-eye"></i>
                                            </a>
                                        @endif
                                        @if(isset($dataCollection->dcWord))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.data_collections.trim.show',['type'=>isset($dataCollection->dcWord) ? 'word' : '', 'id' => $dataCollection->dcWord->dcWordCollection->id]) }}">
                                                <i class="text-white far fa-eye"></i>
                                            </a>
                                        @endif
                                        {{--@if(isset($dataCollection->dcDirected->dcSentence))
                                            @if($dataCollection->dcDirected->dcSentence->status == null && $dataCollection->dcDirected->dcSentence->approved_by == null)
                                                @if(Auth::user()->user_type == 4)
                                                    <a class="btn btn-purple btn-sm text-white" href="{{ route('trim-page',['type'=>($dataCollection->type_id == 1) ? 'directed' : '', 'id' => $dataCollection->dcDirected->dcSentence->id]) }}">
                                                        <i class="fa-solid fa-scissors"></i>
                                                    </a>
                                                @endif
                                            @endif
                                        @else
                                            @if($dataCollection->dcSpontaneous)
                                                @if($dataCollection->dcSpontaneous->status == null && $dataCollection->dcSpontaneous->approved_by == null)
                                                    @if(Auth::user()->user_type == 4)
                                                        <a class="btn btn-purple btn-sm text-white" href="{{ route('trim-page',['type'=>($dataCollection->type_id == 2) ? 'spontaneous' : '', 'id' => $dataCollection->dcSpontaneous->id]) }}">
                                                            <i class="fa-solid fa-scissors"></i>
                                                        </a>
                                                    @endif
                                                @endif
                                            @endif
                                        @endif--}}
                                        @if(isset($dataCollection->dcSpontaneous))
                                            <form action="{{ route('admin.data_collections.destroy', $dataCollection->dcSpontaneous->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button class="btn btn-danger btn-sm show_confirm">
                                                    <svg class="icon  text-white">
                                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                    </svg>
                                                </button>
                                            </form>
                                            @elseif (isset($dataCollection->dcWord))
                                            <form action="{{ route('admin.data_collections.word.destroy', $dataCollection->dcWord->dcWordCollection->id) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-danger btn-sm show_confirm">
                                                        <svg class="icon  text-white">
                                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                        </svg>
                                                    </button>
                                                </form>
                                        @else
                                            @if(isset($dataCollection->dcDirected))
                                                <form action="{{ route('admin.data_collections.directed.destroy', $dataCollection->dcDirected->dcSentence->id) }}" method="post">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-danger btn-sm show_confirm">
                                                        <svg class="icon  text-white">
                                                            <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                        </svg>
                                                    </button>
                                                </form>
                                            @endif
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        // delete Alert message
        $('body').on('click', '.show_confirm', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি এই ডাটা মুছে ফেলতে চান ?')}}",
                text: "{{__('যদি এটি মুছে ফেলেন তাহলে ডাটা চিরতরে মুছে যাবে !')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '25px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });



        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
        $('.sentence').hover(function() {
            $(this).find('.badge-custom').addClass('bg-danger');
        }, function() {
            $(this).find('.badge-custom').removeClass('bg-danger');
        });

        $('.collectionType').hover(function() {
            $(this).find('.bg-success').addClass('bg-danger');
        }, function() {
            $(this).find('.bg-success').removeClass('bg-danger');
        });

        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }
    </script>

@endsection


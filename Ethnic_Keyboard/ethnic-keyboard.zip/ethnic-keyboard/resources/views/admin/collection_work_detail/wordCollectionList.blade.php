@extends('layouts.app')

@section('title', 'ডাটা কালেক্টর তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            @if($type=='all')
                                <a href="{{route('admin.collection-work-details.index')}}">{{__('কাজের তালিকা')}}</a>
                            @else
                                <a href="{{route('admin.collection-works.today')}}">{{__('আজকের কাজের তালিকা')}}</a>
                            @endif
                        </li>
                        @if(!empty($firstItem))
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->language->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->district->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->collector->name}}</li>
                            <li class="breadcrumb-item " aria-current="page">{{$firstItem->speaker->name}}</li>
                        @endif
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col" style="width: 14rem;">{{__('অডিও')}}</th>
                            <th scope="col">{{__('শব্দ')}}</th>
                            <th scope="col">{{__('সংগ্রহের তারিখ')}}</th>
                            {{--<th scope="col">{{__('স্ট্যাটাস')}}</th>--}}
                            <th scope="col" class="text-center">{{__('অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $key=>$dataCollection)
                            <tr>
                                <td>{{ ++$key }}</td>
                                <td class="">
                                    @if($dataCollection->type_id == 0)
                                        {{__('শব্দ')}}
                                    @endif
                                </td>
                                @if($dataCollection->dcWord)
                                    @php
                                        $audio = explode('/', $dataCollection->dcWord->dcWordCollection->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 14rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $dataCollection->dcWord->dcWordCollection??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcWord->dcWordCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection->word))
                                    <td class="word">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('শব্দ')}}">
                                            {{$dataCollection->dcWord->dcWordCollection->word->sentence?? ''}}
                                        </span>
                                    </td>
                                @endif
                                <td class="small">{{showDate($dataCollection->created_at)}}</td>
                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-start">
                                        <a class="btn btn-info btn-sm" href="{{ route('admin.collection-work-details.show', ['type'=>$type, 'id'=>$dataCollection->id]) }}">
                                            <i class="text-white far fa-eye"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        // alertify delete notification
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
        $('.word').hover(function() {
            $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
        }, function() {
            $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
        });


        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }
    </script>
@endsection


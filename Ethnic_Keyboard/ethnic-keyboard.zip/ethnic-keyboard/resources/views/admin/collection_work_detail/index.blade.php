@extends('layouts.app')

@section('title', 'কাজের তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('কাজের তালিকা')}}</li>
                </ul>
            </div>
            <div class="card-body">
                <form action="{{route('admin.collection-work-details.index')}}" method="GET">
                    <div class="row mb-3" id="clear" >
                        <div class="col-md-2">
                            <select class="form-select" name="language_id" id="language_id">
                                <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                @foreach($languages as $lanItem)
                                    <option value="{{$lanItem->language->id}}" {{ $lanItem->language->id == $selected_id['language_id'] ? 'selected' : '' }}>{{$lanItem->language->name}}</option>
                                @endforeach
                            </select>

                        </div>
                        <div class="col-md-2">
                            <select class="form-select" name="district_id" id="district_id">
                                <option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>
                                @foreach($districts as $disItem)
                                    <option value="{{$disItem->district->id}}" {{ $disItem->district->id == $selected_id['district_id'] ? 'selected' : '' }}>{{$disItem->district->name}}</option>
                                @endforeach
                            </select>

                        </div>
                        @if(Auth::user()->user_type != 4)
                            <div class="col-md-2">
                                <select class="form-select" name="collector_id" id="collector_id">
                                    <option value="">{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}</option>
                                    @foreach($collectors as $collectorItem)
                                        <option value="{{$collectorItem->collector->id}}" {{ $collectorItem->collector->id == $selected_id['collector_id'] ? 'selected' : '' }}>{{$collectorItem->collector->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif
                        <div class="col-md-2 ">
                            <div class="input-group">
                                <a class="btn bg-danger" id="remove" href="{{route('admin.collection-work-details.index')}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="display: none; margin-left: -23px; z-index: 100;">
                                    <svg class="icon me-2 text-white">
                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                    </svg>
                                </a>
                            </div>

                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="data-collection-work">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                            <th scope="col">{{__('ভাষা')}}</th>
                            <th scope="col">{{__('জেলা')}}</th>
                            <th scope="col">{{__('ডাটা কালেক্টর')}}</th>
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col">{{__('শব্দ/বিষয়/টপিক')}}</th>
                            <th scope="col">{{__('সংগ্রহের তারিখ')}}</th>
                            <th scope="col">{{__('পদক্ষেপ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($dataCollections as $dataCollection)
                            <tr>
                                <td>{{ $dataCollection->serial_no }}</td>
                                <td class="small">{{$dataCollection->language_name}}</td>
                                <td class="small">{{$dataCollection->district_name}}</td>
                                <td class="small">{{$dataCollection->collector_name}}</td>
                                <td class="collectionType">
                                    @if($dataCollection->type_id == 1)
                                        <span class="badge bg-success">{{__('নির্দেশিত')}}</span>
                                    @elseif($dataCollection->type_id == 2)
                                        <span class="badge bg-success">{{__('স্বতঃস্ফূর্ত')}}</span>
                                    @else
                                        <span class="badge bg-success">{{__('শব্দ ও ব্যাকরণ')}}</span>
                                    @endif
                                </td>
                                @if($dataCollection->type_id == 2)
                                    <td class="topic">
                                        <span class="badge bg-info-new " data-toggle="tooltip" data-placement="top" title="{{__('স্বতঃস্ফূর্ত টপিক')}}">
                                            {{$dataCollection->spontaneous_name}}
                                        </span>
                                    </td>
                                @endif
                                @if($dataCollection->type_id == 1)
                                    <td class="sentence">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('নির্দেশিত বিষয়')}}">
                                            {{$dataCollection->topic_name?? ''}}
                                        </span>
                                    </td>
                                @endif
                                @if($dataCollection->type_id == 0)
                                    <td class="word">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('শব্দ ও ব্যাকরণ')}}">
                                            {{$dataCollection->topic_word_name?? ''}}
                                        </span>
                                    </td>
                                @endif
                                <td class="small">{{showDateTime($dataCollection->created_at)}}</td>
                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        @if($dataCollection->type_id == 2)
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.collection-work-details.show', ['type'=>'all', 'id'=>$dataCollection->id]) }}">
                                                <i class="text-white fa fa-tasks"></i>
                                            </a>
                                         @endif
                                        @if($dataCollection->type_id == 1)
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.collections.list.show', ['type'=>'all', 'task_assign_id'=>$dataCollection->task_assign_id, 'topic_id'=>$dataCollection->topic_id]) }}">
                                                <i class="text-white fa fa-tasks"></i>
                                            </a>
                                        @endif
                                        @if($dataCollection->type_id == 0)
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.word.collections.list.show', ['type'=>'all', 'task_assign_id'=>$dataCollection->task_assign_id, 'topic_word_id'=>$dataCollection->topic_word_id]) }}">
                                                <i class="text-white fa fa-tasks"></i>
                                            </a>
                                        @endif

                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center">{{__('কোন কিছু পাওয়া যায়নি')}}</td>
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                    <div class="card-footer clearfix">
                        {{$dataCollections->links('vendor.pagination.custom')}}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">
        $(document).ready(function() {

            /*$('#data-collection-work').DataTable({
            });
*/
            $('.sentence').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.topic').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.word').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.collectionType').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-success').removeClass('bg-danger');
            });

            // var target = $('option:selected').val();
            var language = $('#language_id option:selected').val();
            var district = $('#district_id option:selected').val();
            var collector = $('#collector_id option:selected').val();
            var speaker = $('#speaker_id option:selected').val();
            var x = document.getElementById("remove");
            if(language || district || collector || speaker){
                x.style.display = "block";
            }

            $('select').on('change', function() {
                var value =this.value;
                var x = document.getElementById("remove");
                if(value){
                    x.style.display = "block";
                }
            });
        });

        // language & district & collector filter on change three filter
        $('#clear').on('change', function() {
            var language_id = $('#language_id').val();
            var district_id = $('#district_id').val();
            var collector_id = $('#collector_id').val();
            if(collector_id){
                var url = "{{ route('admin.collection-work-details.index') }}";
                var url = url + '?language_id=' + language_id + '&district_id=' + district_id + '&collector_id=' + collector_id;
                window.location.href = url;
            }else {
                var url = "{{ route('admin.collection-work-details.index') }}";
                var url = url + '?language_id=' + language_id + '&district_id=' + district_id;
                window.location.href = url;
            }
        });


        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#district_id').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#collector_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#speaker_id').select2({
            width: '100%',
            placeholder: "{{__('messages.স্পিকার নির্বাচন করুন')}}",
            allowClear: true
        });

    </script>

@endsection

@extends('layouts.app')
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            @if($type=='all')
                                <a href="{{route('admin.collection-work-details.index')}}">{{__('কাজের তালিকা')}}</a>
                            @else
                                <a href="{{route('admin.collection-works.today')}}">{{__('আজকের কাজের তালিকা')}}</a>
                            @endif

                        </li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('দেখুন')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-7 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('সংগৃহীত ডাটার তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                @if(isset($dataCollection->dcDirected->topic->name))
                                    <th>{{ __('বিষয়') }}</th>
                                    <td>{{ $dataCollection->dcDirected->topic->name ?? ''}}</td>
                                @endif
                                @if(isset($dataCollection->dcSpontaneous))
                                    <th>{{ __('টপিক') }}</th>
                                    <td>{{ $dataCollection->dcSpontaneous->spontaneous->word?? ''}}</td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection->word))
                                    <th>{{ __('শব্দ') }}</th>
                                    <td>{{ $dataCollection->dcWord->topicWord->name?? ''}}</td>
                                @endif
                            </tr>
                            <tr>
                                <th>{{ __('অডিও') }}</th>
                                <td>
                                    @if(isset($dataCollection->dcDirected->dcSentence->audio))
                                        <input type="hidden" id="audio" value="{{$dataCollection->dcDirected->dcSentence->audio?? ''}}">
                                    @endif
                                    @if(isset($dataCollection->dcSpontaneous->audio))
                                        <input type="hidden" id="audio" value="{{$dataCollection->dcSpontaneous->audio?? ''}}">
                                    @endif
                                    @if(isset($dataCollection->dcWord->dcWordCollection->audio))
                                        <input type="hidden" id="audio" value="{{$dataCollection->dcWord->dcWordCollection->audio??''}}">
                                    @endif
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                        <button class="btn btn-light btn-sm mb-1" onclick="dowonloadFile()">{{__('ডাউনলোড')}}</button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('টাইপ') }}</th>
                                <td class="">
                                    @if($dataCollection->type_id == 1)
                                        {{__('নির্দেশিত')}}
                                    @elseif($dataCollection->type_id == 2)
                                        {{__('স্বতঃস্ফূর্ত')}}
                                    @else
                                        {{__('শব্দ')}}
                                    @endif
                                </td>

                            </tr>
                            <tr>
                                <th>{{ __('বাংলা') }}</th>
                                <td>
                                    @if(isset($dataCollection->dcDirected->dcSentence->directed->sentence))
                                        {{$dataCollection->dcDirected->dcSentence->directed->sentence ?? ''}}
                                    @elseif(isset($dataCollection->dcWord->dcWordCollection->word->sentence))
                                        {{$dataCollection->dcWord->dcWordCollection->word->sentence ?? ''}}
                                    @else
                                        {{$dataCollection->dcSpontaneous->bangla?? ''}}
                                    @endif

                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ইংরেজী') }}</th>
                                <td>
                                    @if(isset($dataCollection->dcDirected->dcSentence->directed->english))
                                        {{$dataCollection->dcDirected->dcSentence->directed->english ?? ''}}
                                    @elseif(isset($dataCollection->dcWord->dcWordCollection->word->english))
                                        {{$dataCollection->dcWord->dcWordCollection->word->english ?? ''}}
                                    @else
                                        {{$dataCollection->dcSpontaneous->english?? ''}}
                                    @endif
                                </td>
                            </tr>

                            <tr>
                                <th>{{ __('উচ্চারণ') }}</th>
                                <td>
                                    @if(isset($dataCollection->dcDirected->dcSentence->transcription))
                                        {{$dataCollection->dcDirected->dcSentence->transcription ??''}}
                                    @elseif(isset($dataCollection->dcWord->dcWordCollection->transcription))
                                        {{$dataCollection->dcWord->dcWordCollection->transcription ??''}}
                                    @else
                                        {{$dataCollection->dcSpontaneous->transcription?? ''}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ভাষা') }}</th>
                                <td>
                                    {{$dataCollection->language->name?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('অবস্থান') }}</th>
                                <td>
                                    {{$dataCollection->district->name?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('সংগ্রহের তারিখ') }}</th>
                                <td>
                                    {{showDate($dataCollection->created_at?? '')}}
                                </td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-5 col-sm-12">
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('কালেক্টর তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('গ্রুপের নাম') }}</th>
                                <td>
                                    {{$dataCollection->taskAssign->group->name ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('কালেক্টর নাম') }}</th>
                                <td>
                                    {{$dataCollection->collector->name ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ইমেইল') }}</th>
                                <td>
                                    {{$dataCollection->collector->email ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('জাতীয় পরিচয়পত্র') }}</th>
                                <td>
                                    {{$dataCollection->collector->nid ?? ''}}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>
                                    {{$dataCollection->collector->phone ?? ''}}
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <hr>
                        <table class="table table-bordered table-hover table-striped table-responsive">
                            <thead class="table-info">
                            <tr class="text-center">
                                <th colspan="2">{{__('স্পিকারের তথ্য')}}</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th>{{ __('স্পিকার নাম') }}</th>
                                <td>
                                    {{ $dataCollection->speaker->name ?? '' }}
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('লিঙ্গ') }}</th>
                                <td>
                                    @if($dataCollection->speaker->gender == 0)
                                        {{__('messages.পুরুষ')}}
                                    @elseif($dataCollection->speaker->gender== 1)
                                        {{__('messages.মহিলা')}}
                                    @else
                                        {{__('messages.অন্যান্য')}}
                                    @endif
                                </td>
                            </tr>
                            <tr>
                                <th>{{ __('ফোন') }}</th>
                                <td>{{ $dataCollection->speaker->phone?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('বয়স') }}</th>
                                <td>{{ $dataCollection->speaker->age?? ''}}</td>
                            </tr>
                            <tr>
                                <th>{{ __('পেশা') }}</th>
                                <td>{{ $dataCollection->speaker->occupation?? ''}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                @if(count($trims)>0)
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered" id="trim-collection">
                                    <thead class="table-info">
                                    <tr class="table-dark">
                                        <th colspan="7">{{__('messages.অডিও ট্রিমিং এর তালিকা')}}</th>
                                    </tr>
                                    <tr>
                                        <th scope="col">{{__('ক্রমিক')}}</th>
                                        <th scope="col">{{__('messages.অডিও ট্রিম')}}</th>
                                        <th scope="col">{{__('messages.বাংলা')}} </th>
                                        <th scope="col">{{__('messages.ইংরেজী')}}</th>
                                        <th scope="col">{{__('messages.উচ্চারণ')}} </th>
                                        <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                                    </tr>
                                    </thead>
                                    <tbody id="tbody">
                                    @foreach($trims as $key =>$trim)
                                        @php
                                            $audio = explode('/', $trim->audio);
                                            $uniqueCode=substr(end($audio), 0, -4);
                                            $uniqueCode= str_replace('.', '', $uniqueCode);
                                        @endphp
                                        <tr>
                                            <td>{{$loop->iteration}}</td>
                                            <td class="align-middle text-center" >
                                                <button style="display: none;" class="myLink" onclick="waveSurferView({{ $trim }})"></button>
                                                <div id="waveform{{$uniqueCode}}"></div>
                                                <div id="waveform-time-indicator" class="justify-content-between">
                                                    <input type="button" id="play-pause{{$uniqueCode}}" value="Play"/>
                                                    <span id="total-time" class="time{{$uniqueCode}}">00:00:00</span>
                                                </div>
                                            </td>
                                            <td>{{$trim->bangla}}</td>
                                            <td>{{$trim->english}}</td>
                                            <td>{{$trim->transcription}}</td>
                                            @if(isset($trim))
                                                @if($trim->status == 0)
                                                    <td class="">
                                                        <i class="fa fa-times text-danger"></i>
                                                    </td>
                                                @elseif($trim->status == 2)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                                    </td>
                                                @elseif($trim->status == 1)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                                    </td>
                                                @elseif($trim->status == 3)
                                                    <td class="">
                                                        <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                                    </td>
                                                @endif

                                            @else
                                                <td>
                                                    <i class="fa fa-times text-danger"></i>
                                                </td>
                                            @endif
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                @endif

            </div>
        </div>

    </div>
@endsection
@section('language-js')
    <script>

        function dowonloadFile() {
            let path = $('#audio').val();
            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            //window.open(audioPath, '_blank');

            var link = document.createElement("a");
            link.download = 'audio';
            link.href = audioPath;
            link.click();
        }

    </script>
@endsection

@extends('layouts.app')

@section('title', 'আজকের কাজের তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('আজকের কাজের তালিকা')}}</li>
                    {{--@if(Auth::user()->user_type == 4)
                        <li class="nav-item"><a class="btn btn-success btn-sm text-white" href="{{route('admin.data_collections.create')}}">
                                <svg class="icon me-2 text-white">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                                </svg>{{__('messages.নতুন')}}</a>
                        </li>
                    @endif--}}
                </ul>
            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <form action="{{route('admin.collection-works.today')}}" method="GET">
                    <div class="row mb-3" id="clear">
                        <div class="col-md-2">
                            <select class="form-select" name="language_id" id="language_id">
                                <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                @foreach($languages as $lanItem)
                                    <option value="{{$lanItem->language->id}}" {{ $lanItem->language->id == $selected_id['language_id'] ? 'selected' : '' }}>{{$lanItem->language->name}}</option>
                                @endforeach
                            </select>

                        </div>
                        <div class="col-md-2">
                            <select class="form-select" name="district_id" id="district_id">
                                <option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>
                                @foreach($districts as $disItem)
                                    <option value="{{$disItem->district->id}}" {{ $disItem->district->id == $selected_id['district_id'] ? 'selected' : '' }}>{{$disItem->district->name}}</option>
                                @endforeach
                            </select>

                        </div>
                        @if(Auth::user()->user_type != 4)
                            <div class="col-md-2">
                                <select class="form-select" name="collector_id" id="collector_id">
                                    <option value="">{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}</option>
                                    @foreach($collectors as $collectorItem)
                                        <option value="{{$collectorItem->collector->id}}" {{ $collectorItem->collector->id == $selected_id['collector_id'] ? 'selected' : '' }}>{{$collectorItem->collector->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        @endif
                        {{--<div class="col-md-3">
                            <select class="form-select" name="speaker_id" id="speaker_id">
                                <option value="">{{__('messages.স্পিকার নির্বাচন করুন')}}</option>
                                @foreach($speakers as $speakerItem)
                                    <option value="{{$speakerItem->speaker->id}}" {{ $speakerItem->speaker->id == $selected_id['speaker_id'] ? 'selected' : '' }}>{{$speakerItem->speaker->name}}</option>
                                @endforeach
                            </select>
                        </div>--}}
                        <div class="col-md-2 ">
                            <div class="input-group">
                                <a class="btn bg-danger" id="remove" href="{{route('admin.collection-works.today')}}"  data-toggle="tooltip" data-placement="top" title="Clear" style="display: none; margin-left: -23px; z-index: 100;">
                                    <svg class="icon me-2 text-white">
                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-x-circle')}}"></use>
                                    </svg>
                                </a>
                                {{--<button class="btn btn-success text-white" type="submit">
                                    <svg class="icon me-2 text-white">
                                        <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-search')}}"></use>
                                    </svg>
                                </button>--}}
                            </div>

                        </div>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="data-collection-work">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                            <th scope="col">{{__('ভাষা')}}</th>
                            <th scope="col">{{__('অবস্থান')}}</th>
                            <th scope="col">{{__('ডাটা কালেক্টর')}}</th>
                            <th scope="col">{{__('টাইপ')}}</th>
                            <th scope="col">{{__('শব্দ/বিষয়/টপিক')}}</th>
                            <th scope="col">{{__('শুরুর তারিখ')}}</th>
                            <th scope="col">{{__('শেষ তারিখ')}}</th>
                            <th scope="col">{{__('সংগ্রহের তারিখ')}}</th>
                            <th scope="col">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($dataCollections as $dataCollection)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td class="">{{$dataCollection->language->name}}</td>
                                <td class="">{{$dataCollection->district->name}}</td>
                                @if(isset($dataCollection->collector))
                                    <td class="">{{$dataCollection->collector->name}}</td>
                                @endif
                                <td class="">
                                    @if($dataCollection->type_id == 1)
                                        {{__('নির্দেশিত')}}
                                    @elseif($dataCollection->type_id == 2)
                                        {{__('স্বতঃস্ফূর্ত')}}
                                    @else
                                        {{__('শব্দ')}}
                                    @endif
                                </td>
                                @if($dataCollection->dcSpontaneous)
                                    <td class="topic">
                                        <span class="badge bg-info-new " data-toggle="tooltip" data-placement="top" title="{{__('স্বতঃস্ফূর্ত টপিক')}}">
                                            {{$dataCollection->dcSpontaneous->spontaneous->word?? ''}}
                                        </span>
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcDirected->dcSentence->directed))
                                    <td class="sentence">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('নির্দেশিত বিষয়')}}">
                                            {{$dataCollection->dcDirected->topic->name?? ''}}
                                        </span>
                                    </td>
                                @endif
                                @if(isset($dataCollection->dcWord->dcWordCollection->word))
                                    <td class="word">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('শব্দ')}}">
                                            {{$dataCollection->dcWord->topicWord->name?? ''}}
                                        </span>
                                    </td>
                                @endif
                                <td class="small">{{showDate($dataCollection->taskAssign->start_date)}}</td>
                                <td class="small">{{showDate($dataCollection->taskAssign->end_date)}}</td>
                                <td class="small">{{showDate($dataCollection->created_at)}}</td>
                                <td class="">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        @if(isset($dataCollection->dcSpontaneous))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.collection-work-details.show', ['type'=>'today', 'id'=>$dataCollection->id]) }}">
                                                <i class="text-white far fa-eye"></i>
                                            </a>
                                        @endif
                                        @if(isset($dataCollection->dcDirected->dcSentence->directed))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.collections.list.show', ['type'=>'today', 'task_assign_id'=>$dataCollection->task_assign_id, 'topic_id'=>$dataCollection->dcDirected->topic_id]) }}">
                                                <i class="text-white fa fa-tasks"></i>
                                            </a>
                                        @endif
                                        @if(isset($dataCollection->dcWord->dcWordCollection->word))
                                            <a class="btn btn-info btn-sm" href="{{ route('admin.word.collections.list.show', ['type'=>'today', 'task_assign_id'=>$dataCollection->task_assign_id, 'topic_word_id'=>$dataCollection->dcWord->topic_word_id]) }}">
                                                <i class="text-white fa fa-tasks"></i>
                                            </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script type="text/javascript">

        $(document).ready(function() {
            //datatable
            $('#data-collection-work').DataTable({
                order:false,
                "language": {
                    "info": "{{__('Showing page')}} _PAGE_ of _PAGES_",
                    "infoEmpty": "কোন ডাটা নেই।",
                    "infoFiltered": "(filtered from _MAX_ total records)",
                    "search": "{{__('অনুসন্ধান')}}",
                    "paginate": {
                        "first":      "{{__('প্রথম')}}",
                        "last":       "{{__('শেষ')}}",
                        "next":       "{{__('পরবর্তী')}}",
                        "previous":   "{{__('আগের')}}"
                    },
                }
            });


            $('.sentence').tooltip({
                selector: "[data-toggle=tooltip]",
                container: "body",
            });
            $('.topic').tooltip({
                selector: "[data-toggle=tooltip]",
                container: "body",
            });
            $('.word').tooltip({
                selector: "[data-toggle=tooltip]",
                container: "body",
            });

            $('.sentence').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.topic').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });
            $('.word').hover(function() {
                $(this).find('.badge').addClass('bg-danger').removeClass('bg-info-new');
            }, function() {
                $(this).find('.badge').addClass('bg-info-new').removeClass('bg-danger');
            });


            // var target = $('option:selected').val();
            var language = $('#language_id option:selected').val();
            var district = $('#district_id option:selected').val();
            var collector = $('#collector_id option:selected').val();
            var speaker = $('#speaker_id option:selected').val();
            var x = document.getElementById("remove");
            if(language || district || collector || speaker){
                x.style.display = "block";
            }

            $('select').on('change', function() {
                var value =this.value;
                var x = document.getElementById("remove");
                if(value){
                    x.style.display = "block";
                }
            });
        });

        // language & district & collector filter on change three filter
        $('#clear').on('change', function() {
            var language_id = $('#language_id').val();
            var district_id = $('#district_id').val();
            var collector_id = $('#collector_id').val();
            // if collector_id is not empty
            if(collector_id){
                var url = "{{ route('admin.collection-works.today') }}";
                var url = url + '?language_id=' + language_id + '&district_id=' + district_id + '&collector_id=' + collector_id;
                window.location.href = url;
            }else {
                var url = "{{ route('admin.collection-works.today') }}";
                var url = url + '?language_id=' + language_id + '&district_id=' + district_id;
                window.location.href = url;
            }
        });


        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#district_id').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#collector_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#speaker_id').select2({
            width: '100%',
            placeholder: "{{__('messages.স্পিকার নির্বাচন করুন')}}",
            allowClear: true
        });



    </script>

@endsection

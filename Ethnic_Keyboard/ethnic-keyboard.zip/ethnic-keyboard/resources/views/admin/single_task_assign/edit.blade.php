@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header pb-0">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.task_assigns.index')}}">{{__('messages.টাস্ক অ্যাসাইন')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.এডিট')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <form action="{{route('admin.single_task_assigns.update', $singleTaskAssign->id)}}" method="post" >
                    @csrf
                    @method("PUT")
                <div class="row">
                    <input id="fcm_token" type="hidden" name="user_token" value="">
                    <div class="col-md-6 col-sm-12">
                        <div class="row mb-2">
                            <label  for="user_id">{{__('messages.ডাটা কালেক্টর')}}  <span class="text-danger">*</span></label>
                            <div class="input-group">
                                @foreach($collectors as $key => $collector)
                                <input id="user_id" type="text" name="user_id" value="{{$key}}" hidden>
                                <input class="form-control @error('user_id') is-invalid @enderror" type="text"  value="{{$collector}}" readonly>
                                @endforeach
                                @error('user_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-2">
                            <label  for="district">{{__('messages.জেলা')}} <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <select class="form-select @error('district') is-invalid @enderror" id="district"  name="district">
                                    <option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>
                                    @foreach($districts as $key => $district)
                                        <option value="{{$key}}" {{($key == $singleTaskAssign->district_id)? 'selected': ''}}>{{$district}}</option>
                                    @endforeach
                                </select>
                                @error('district')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-2">
                            <label  for="upazila">{{__('messages.উপজেলা')}}<span class="text-danger"></span></label>
                            <div class="input-group">
                                <select class="form-select @error('union') is-invalid @enderror" id="union" name="union">
                                    <option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>
                                    @foreach($unions as $key => $union)
                                        <option value="{{$key}}" {{($key == $singleTaskAssign->union_id)? 'selected': ''}}>{{$union}}</option>
                                    @endforeach
                                </select>
                                @error('upazila')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-2">
                            <label  for="union">{{__('messages.ইউনিয়ন')}} <span class="text-danger"></span></label>
                            <div class="input-group">
                                <select class="form-select @error('union') is-invalid @enderror" id="union" name="union">
                                    <option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>
                                    @foreach($unions as $key => $union)
                                        <option value="{{$key}}" {{($key == $singleTaskAssign->union_id)? 'selected': ''}}>{{$union}}</option>
                                    @endforeach
                                </select>
                                @error('union')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-2">
                            <label  for="village">{{__('messages.গ্রাম')}} <span class="text-danger"></span></label>
                            <div class="input-group">
                                <input class="form-control @error('village') is-invalid @enderror" id="village" placeholder="{{__('messages.গ্রাম')}}" type="text" name="village" value="{{$singleTaskAssign->village}}">
                                @error('village')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        {{--<div class="row mb-3">
                            <label  for="total_sample">{{__('messages.মোট নমুনা')}} <span class="text-danger"></span></label>
                            <div class="input-group">
                                <input class="form-control @error('total_sample') is-invalid @enderror" id="total_sample" type="number" name="total_sample" value="{{$singleTaskAssign->total_sample}}">
                                @error('village')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>--}}
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="row mb-2">
                            <label  for="language_id">{{__('messages.ভাষার নাম')}}  <span class="text-danger">*</span></label>
                            <div class=" input-group">
                                <select class="form-select  @error('language_id') is-invalid @enderror"  id="language_id" name="language_id">
                                    <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                    @foreach($languages as $key => $value)
                                        <option value="{{$key}}" {{($key == $singleTaskAssign->language_id)? 'selected': ''}}>{{$value}}</option>
                                    @endforeach
                                </select>
                                @error('language_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-2">
                            <label  for="sub_language_id">{{__('messages.উপভাষা')}} <span class="text-danger"></span></label>
                            <div class="input-group">
                                <select class="form-select @error('sub_language_id') is-invalid @enderror" id="sub_language_id"  name="sub_language_id">
                                    <option value="">{{__('messages.উপভাষা নির্বাচন করুন')}}</option>
                                    @foreach($subLanguages as $key => $subLanguage)
                                        <option value="{{$key}}" {{($key == $singleTaskAssign->sub_language_id)? 'selected': ''}}>{{$subLanguage}}</option>
                                    @endforeach
                                </select>
                                @error('sub_language_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-2">
                            <label  for="start_date">{{__('messages.শুরুর তারিখ')}}<span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input class="form-control @error('start_date') is-invalid @enderror" id="start_date" type="date" name="start_date" value="{{$singleTaskAssign->start_date}}">
                                @error('start_date')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label  for="end_date">{{__('messages.শেষ তারিখ')}} <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input class="form-control @error('end_date') is-invalid @enderror" id="end_date" type="date"  name="end_date" value="{{$singleTaskAssign->end_date}}">
                                @error('end_date')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-2">
                    <div class="card-body">
                        <div class="field_wrapper" id="field_wrapper">
                            <div class="row mb-3">
                                <div class="col-md-4 col-sm-4">
                                    <div class=" input-group" >
                                        <div class="form-check form-check-inline" style="width: 14rem;">
                                            <input class="form-check-input" name="directed" id="directed" type="checkbox" onclick="checkAll(document.getElementsByClassName('directed'),this)">
                                            <label class="form-check-label" for="directed">{{__('messages.নির্দেশিত')}}</label>
                                        </div>
                                    </div>
                                    <div class="row" style="height: 400px; position:relative;">
                                        <div class=" directed" style="position:absolute; max-height:100%;overflow:auto;">
                                            <table class="table table-bordered table-hover table-striped table-responsive">
                                                <tbody>
                                                @foreach($directeds as $key => $directed)
                                                    <tr>
                                                        <td>
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label directed-hover " style="cursor:pointer;">
                                                                    {{ Form::checkbox('topic_id[]', $key, in_array($key, $directedSelected) ? true : false, array('class' => 'form-check-input', 'style'=>'cursor: pointer')) }}
                                                                    <small  class=" text-white bg-info-new badge-new text-hover">{{$directed}}</small>
                                                                </label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class=" input-group" >
                                        <div class="form-check form-check-inline" style="width: 14rem;">
                                            <input class="form-check-input" name="word" id="word" type="checkbox" onclick="checkAll(document.getElementsByClassName('word'),this)">
                                            <label class="form-check-label" for="word">{{__('শব্দ ও ব্যাকরণ')}}</label>
                                        </div>
                                    </div>
                                    <div class="row" style="height: 400px; position:relative;">
                                        <div class=" word" style="position:absolute; max-height:100%;overflow:auto;">
                                            <table class="table table-bordered table-hover table-striped table-responsive">
                                                <tbody>
                                                @foreach($words as $key1 => $word)
                                                    <tr>
                                                        <td>
                                                            <div class="form-check form-check-inline">
                                                                <label class="form-check-label " style="cursor:pointer;">
                                                                    {{ Form::checkbox('topic_word_id[]', $key1, in_array($key1, $wordSelected) ? true : false, array('class' => 'form-check-input', 'style'=>'cursor: pointer')) }}
                                                                    {{--<input class="form-check-input" checked="checked" style="cursor:pointer;" name="topic_word_id[]" type="checkbox" value="{{$key1}}">--}}
                                                                    <small class="badge-new bg-info-new text-hover text-white">{{$word}} </small>
                                                                </label>
                                                            </div><br>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class=" input-group" >
                                        <div class="form-check form-check-inline" style="width: 14rem;">
                                            <input class="form-check-input"  name="spontaneous" id="spontaneous" type="checkbox" onclick="checkAll(document.getElementsByClassName('spontaneous'),this)">
                                            <label class="form-check-label" for="spontaneous">{{__('messages.স্বতঃস্ফূর্ত')}}</label>
                                        </div>
                                    </div>
                                    <div class="row" style="height: 400px; position:relative;">
                                        <div class="spontaneous" style="position:absolute; max-height:100%;overflow:auto;">
                                            <table class="table table-bordered table-hover table-striped table-responsive">
                                                <tbody>
                                                @foreach($spontaneouses as $key2 => $spontaneousItem)
                                                    <tr>
                                                        <td>
                                                            <div class="form-check form-check-inline" >
                                                                <label class="form-check-label spontaneous-hover" style="cursor:pointer;">
                                                                    {{ Form::checkbox('spontaneous_id[]', $key2, in_array($key2, $spontaneousSelected) ? true : false, array('class' => 'form-check-input', 'style'=>'cursor: pointer')) }}
                                                                    <small  class="badge-new bg-info-new text-white text-hover">{{$spontaneousItem}}</small>
                                                                </label>
                                                            </div><br>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="row">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('group-task-assgin-js')
<script src="https://www.gstatic.com/firebasejs/7.23.0/firebase.js"></script>
    <script type="text/javascript">
        // checkbox
        function checkAll(cname, bx) {
            for (var tbls = cname,i=tbls.length; i--; )
                for (var bxs=tbls[i].getElementsByTagName("input"),j=bxs.length; j--; )
                    if (bxs[j].type=="checkbox")
                        bxs[j].checked = bx.checked;
        }

        $('#language_id').on('change', function() {
            var language_id = $(this).val();
            if(language_id) {
                $.ajax({
                    url:"{{url('admin/getLanguageByWordDirectedSpont')}}",
                    type: "GET",
                    data:{language_id:language_id},
                    success:function (data){
                        $('#field_wrapper').html(data);
                    },
                });
            }else{
                $('.directed').empty();
                $('.spontaneous').empty()
                $('.word').empty()
            }
        });


        $(document).ready(function() {
            // select SubLanguage
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getSubLanguage')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            // console.log(data);
                            $('select[name="sub_language_id"]').empty();

                            $('#sub_language_id').append('<option value="">{{__('messages.উপভাষা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="sub_language_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="sub_language_id"]').empty()

                }
            });

            // select Districts
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getDistrict')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="district"]').empty();
                            $('select[name="upazila"]').empty()
                            $('select[name="union"]').empty();
                            $('select[name="village"]').empty();
                            $('#district').append('<option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="district"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="district"]').empty()
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                }
            });

            // select upazila
            $('select[name="district"]').on('change', function() {
                var districtID = $(this).val();
                console.log(districtID);
                if(districtID) {
                    $.ajax({
                        url:"{{url('admin/getUpazila')}}?district_id="+districtID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="upazila"]').empty();
                            $('#upazila').append('<option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="upazila"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                }
            });

            // select Union
            $('select[name="upazila"]').on('change', function() {
                var upazilaID = $(this).val();
                console.log(upazilaID);
                if(upazilaID) {
                    $.ajax({
                        url: "{{url('admin/getUnion')}}?upazila_id="+upazilaID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="union"]').empty();
                            $('#union').append('<option value="">{{__('messages.ইউনিয়ন নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="union"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="union"]').empty();
                }
            });
        });

        $('#user_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}",
            allowClear: true
        });

        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#sub_language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.উপভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#district').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#upazila').select2({
            width: '100%',
            placeholder: "{{__('messages.উপজেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#union').select2({
            width: '100%',
            placeholder: "{{__('messages.ইউনিয়ন নির্বাচন করুন')}}",
            allowClear: true
        });

    </script>
     <script>

        window.onload = function() {
            initFirebaseMessagingRegistration();
        };

        var firebaseConfig = {
            apiKey: "AIzaSyAf8VbB9KukpAFQc-PS1djtgnibSqjvtQ4",
            authDomain: "push-notification-1cd0f.firebaseapp.com",
            projectId: "push-notification-1cd0f",
            storageBucket: "push-notification-1cd0f.appspot.com",
            messagingSenderId: "1027263277408",
            appId: "1:1027263277408:web:d92c18d701a17a4505d605",
            measurementId: "G-9Q38M0HCYE"
        };

        firebase.initializeApp(firebaseConfig);
        const messaging = firebase.messaging();

        function initFirebaseMessagingRegistration() {
                messaging
                .requestPermission()
                .then(function () {
                    return messaging.getToken()

                })
                .then(function(token) {

                    console.log(token);
                    $('#fcm_token').val(token);
                })
                .catch(function (err) {
                    console.log('User Chat Token Error'+ err);
                });
         }

        messaging.onMessage(function(payload) {
            const noteTitle = payload.notification.title;
            const noteOptions = {
                body: payload.notification.body,
                icon: payload.notification.icon,
            };
            new Notification(noteTitle, noteOptions);
        });

    </script>
@endsection

<div class="row mb-2">
    <div class="col-md-4 col-sm-4">
        <div class=" input-group" >
            <div class="form-check form-check-inline" style="width: 14rem;">
                <input class="form-check-input all-directed-checked" name="directed" id="directed" type="checkbox" onclick="checkAll(document.getElementsByClassName('directed'),this)">
                <label class="form-check-label" for="directed">{{__('messages.নির্দেশিত')}}</label>
            </div>
        </div>
        <div class="row" style="height: 400px; position:relative;">
            <div class=" directed" style="position:absolute; max-height:100%;overflow:auto;">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    @foreach($directeds as $key => $directed)
                        <tr>
                            <td>
                                <div class="form-check form-check-inline">
                                    <label class="form-check-label directed-hover " style="cursor:pointer;">
                                        <input class="form-check-input directed-checked" style="cursor:pointer;" name="topic_id[]" type="checkbox" value="{{$key}}">
                                        <small  class=" text-white bg-info-new badge-new text-hover">{{$directed}}</small>
                                    </label>
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-4">
        <div class=" input-group" >
            <div class="form-check form-check-inline" style="width: 14rem;">
                <input class="form-check-input all-word-checked" name="word" id="word" type="checkbox" onclick="checkAll(document.getElementsByClassName('word'),this)">
                <label class="form-check-label" for="word">{{__('শব্দ ও ব্যাকরণ')}}</label>
            </div>
        </div>
        <div class="row" style="height: 400px; position:relative;">
            <div class=" word" style="position:absolute; max-height:100%;overflow:auto;">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    @foreach($topicWords as $key1=>$topicWord)
                        <tr>
                            <td>
                                <div class="form-check form-check-inline">
                                    <label class="form-check-label " style="cursor:pointer;">
                                        <input class="form-check-input word-checked" style="cursor:pointer;" name="topic_word_id[]" type="checkbox" value="{{$key1}}">
                                        <small class="badge-new bg-info-new text-hover text-white"> {{$topicWord}} </small>
                                    </label>
                                </div><br>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-4">
        <div class="input-group" >
            <div class="form-check form-check-inline" style="width: 14rem;">
                <input class="form-check-input all-spontaneous-checked" name="spontaneous" id="spontaneous" type="checkbox" onclick="checkAll(document.getElementsByClassName('spontaneous'),this)">
                <label class="form-check-label" for="spontaneous">{{__('messages.স্বতঃস্ফূর্ত') }}</label>
            </div>
        </div>
        <div class="row" style="height: 400px; position:relative;">
            <div class="spontaneous" style="position:absolute; max-height:100%;overflow:auto;">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    @foreach($spontaneouses as $key2 =>$spontaneous)
                        <tr>
                            <td>
                                <div class="form-check form-check-inline" >
                                    <label class="form-check-label spontaneous-hover" style="cursor:pointer;">
                                        <input class="form-check-input spontaneous-checked" style="cursor: pointer" name="spontaneous_id[]" type="checkbox" value="{{$key2}}">
                                        <small  class="badge-new bg-info-new text-white text-hover">{{$spontaneous}}</small>
                                    </label>
                                </div><br>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

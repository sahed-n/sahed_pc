@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-2">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('admin.task_assigns.index')}}">{{__('messages.টাস্ক অ্যাসাইন')}}</a></li>
                        <li class="breadcrumb-item active" aria-current="page">{{__('messages.নতুন')}}</li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <form action="{{--{{route('admin.single_task_assigns.store')}}--}}" method="post" id="single_task_assign_form">
                    @csrf
                    <div class="row">
                        <input id="fcm_token" type="hidden" name="user_token" value="">
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-2">
                                <label  for="user_id">{{__('messages.ডাটা কালেক্টর')}}  <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <select class="form-select @error('user_id') is-invalid @enderror"  id="user_id" name="user_id">
                                        <option value="">{{__('messages.কালেক্টর নির্বাচন করুন')}}</option>
                                        @foreach($collectors as $key => $collector)
                                            <option value="{{$key}}" {{ old('user_id') == $key ? "selected" : "" }}>{{$collector}}</option>
                                        @endforeach
                                    </select>
                                    @error('user_id')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-2">
                                <label  for="district">{{__('messages.জেলা')}} <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <select class="form-select @error('district') is-invalid @enderror" id="district"  name="district">
                                        {{--<option value="">জেলা নির্বাচন করুন</option>
                                        @foreach($districts as $key => $district)
                                            <option value="{{$key}}">{{$district}}</option>
                                        @endforeach--}}
                                    </select>
                                    @error('district')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label  for="upazila">{{__('messages.উপজেলা')}}<span class="text-danger"></span></label>
                                <div class="input-group">
                                    <select class="form-select @error('upazila') is-invalid @enderror" id="upazila" name="upazila">

                                    </select>
                                    @error('upazila')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label  for="union">{{__('messages.ইউনিয়ন')}} <span class="text-danger"></span></label>
                                <div class="input-group">
                                    <select class="form-select @error('union') is-invalid @enderror" id="union" name="union">
                                    </select>
                                    @error('union')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label  for="village">{{__('messages.গ্রাম')}} <span class="text-danger"></span></label>
                                <div class="input-group">
                                    <input class="form-control @error('village') is-invalid @enderror" id="village" placeholder="{{__('messages.গ্রাম')}}" type="text" name="village">
                                    @error('village')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                            {{--<div class="row mb-2">
                                <label  for="total_sample">{{__('messages.মোট নমুনা')}} <span class="text-danger"></span></label>
                                <div class="input-group">
                                    <input class="form-control @error('village') is-invalid @enderror" id="village" placeholder="{{__('messages.মোট নমুনা')}}" type="text" name="village">
                                    @error('village')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>--}}
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-2">
                                <label  for="language_id">{{__('messages.ভাষার নাম')}}  <span class="text-danger">*</span></label>
                                <div class=" input-group">
                                    <select class="form-select  @error('language_id') is-invalid @enderror"  id="language_id" name="language_id">
                                        <option value="">{{__('messages.ভাষা নির্বাচন করুন')}}</option>
                                        @foreach($languages as $key => $language)
                                            <option value="{{$key}}" {{ old('language_id') == $key ? "selected" : "" }}>{{$language}}</option>
                                        @endforeach
                                    </select>
                                    @error('language_id')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="row mb-2">
                                <label  for="sub_language_id">{{__('messages.উপভাষা')}} <span class="text-danger"></span></label>
                                <div class="input-group">
                                    <select class="form-select @error('sub_language_id') is-invalid @enderror" id="sub_language_id"  name="sub_language_id">

                                    </select>
                                    @error('sub_language_id')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            {{--<div class="row mb-2">
                                <label  for="total_time">{{__('মোট সময় (মিনিট)')}} <span class="text-danger">*</span></label>
                                <div class=" input-group">
                                    <input class="form-control @error('total_time') is-invalid @enderror" name="total_time" id="total_time" type="number" placeholder="{{__('মোট সময় (মিনিট)')}}" value="{{old('total_time')}}">
                                    @error('total_time')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>--}}
                            <div class="row mb-2">
                                <label  for="start_date">{{__('messages.শুরুর তারিখ')}}<span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input class="form-control @error('start_date') is-invalid @enderror" id="start_date" type="date" name="start_date" value="{{old('start_date')}}">
                                    @error('start_date')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label  for="end_date">{{__('messages.শেষ তারিখ')}} <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <input class="form-control @error('end_date') is-invalid @enderror" id="end_date" type="date"  name="end_date" value="{{old('end_date')}}">
                                    @error('end_date')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-2">
                        <div class="card-body">
                            <div class="row mb-2">
                                <div class="col-md-4 col-sm-4">
                                    <div class=" input-group" >
                                        <div class="@error('topic_id') is-invalid @enderror"></div>
                                        @error('topic_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class=" input-group" >
                                        <div class="@error('topic_word_id') is-invalid @enderror"></div>
                                        @error('topic_word_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="input-group" >
                                        <div class="@error('spontaneous_id') is-invalid @enderror"></div>
                                        @error('spontaneous_id')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>
                            </div>
                            <div class="field_wrapper" id="field_wrapper">

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-end">
                            <button class="btn btn-success text-white single-submit" type="submit">{{__('messages.জমা দিন')}}</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('group-task-assgin-js')
    <script src="https://www.gstatic.com/firebasejs/7.23.0/firebase.js"></script>
    <script type="text/javascript">
        // checkbox
        function checkAll(cname, bx) {
            for (var tbls = cname,i=tbls.length; i--; )
                for (var bxs=tbls[i].getElementsByTagName("input"),j=bxs.length; j--; )
                    if (bxs[j].type=="checkbox")
                        bxs[j].checked = bx.checked;
        }


        $(document).on('change', "input[type='checkbox'].directed-checked", function() {
            var a = $("input[type='checkbox'].directed-checked");
            if(a.length == a.filter(":checked").length){
                $('.all-directed-checked').not(this).prop('checked', this.checked);
            }else {
                $('.all-directed-checked').not(this).prop('checked', false);
            }
        });
        $(document).on('change', "input[type='checkbox'].word-checked", function() {
            var a = $("input[type='checkbox'].word-checked");
            if(a.length == a.filter(":checked").length){
                $('.all-word-checked').not(this).prop('checked', this.checked);
            }else {
                $('.all-word-checked').not(this).prop('checked', false);
            }
        });
        $(document).on('change', "input[type='checkbox'].spontaneous-checked", function() {
            var a = $("input[type='checkbox'].spontaneous-checked");
            if(a.length == a.filter(":checked").length){
                $('.all-spontaneous-checked').not(this).prop('checked', this.checked);
            }else {
                $('.all-spontaneous-checked').not(this).prop('checked', false);
            }
        });


        $('#language_id').on('change', function() {
            var language_id = $(this).val();
            if(language_id) {
                $.ajax({
                    url:"{{url('admin/getLanguageByWordDirectedSpont')}}",
                    type: "GET",
                    data:{language_id:language_id},
                    success:function (data){
                        $('#field_wrapper').html(data);
                    },
                });
            }else{
                $('.directed').empty();
                $('.spontaneous').empty()
                $('.word').empty()
            }
        });

        $(document).ready(function() {
            // select SubLanguage
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getSubLanguage')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            // console.log(data);
                            $('select[name="sub_language_id"]').empty();
                            $('#sub_language_id').append('<option value="">{{__('messages.উপভাষা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="sub_language_id"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="sub_language_id"]').empty()

                }
            });

            // select Districts
            $('select[name="language_id"]').on('change', function() {
                var languageID = $(this).val();
                console.log(languageID);
                if(languageID) {
                    $.ajax({
                        url:"{{url('admin/getDistrict')}}?language_id="+languageID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="district"]').empty();
                            $('select[name="upazila"]').empty()
                            $('select[name="union"]').empty();
                            $('#district').append('<option value="">{{__('messages.জেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                // select Districts old value
                                if(key == "{{old('district')}}"){
                                    $('select[name="district"]').append('<option value="'+ key +'" selected>'+ value +'</option>');
                                }else{
                                    $('select[name="district"]').append('<option value="'+ key +'" >'+ value +'</option>');
                                }

                            });
                        }
                    });
                }else{
                    $('select[name="district"]').empty()
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                }
            });

            // select upazila
            $('select[name="district"]').on('change', function() {
                var districtID = $(this).val();
                console.log(districtID);
                if(districtID) {
                    $.ajax({
                        url:"{{url('admin/getUpazila')}}?district_id="+districtID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="upazila"]').empty();
                            $('#upazila').append('<option value="">{{__('messages.উপজেলা নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="upazila"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="upazila"]').empty()
                    $('select[name="union"]').empty();
                    $('select[name="village"]').empty();
                }
            });

            // select Union
            $('select[name="upazila"]').on('change', function() {
                var upazilaID = $(this).val();
                console.log(upazilaID);
                if(upazilaID) {
                    $.ajax({
                        url: "{{url('admin/getUnion')}}?upazila_id="+upazilaID,
                        type: "GET",
                        dataType: "json",
                        success:function(data) {
                            $('select[name="union"]').empty();
                            $('#union').append('<option value="">{{__('messages.ইউনিয়ন নির্বাচন করুন')}}</option>');
                            $.each(data, function(key, value) {
                                $('select[name="union"]').append('<option value="'+ key +'">'+ value +'</option>');
                            });
                        }
                    });
                }else{
                    $('select[name="union"]').empty();
                    $('select[name="village"]').empty();
                }
            });
        });



        $('#user_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ডাটা কালেক্টর নির্বাচন করুন')}}",
            allowClear: true
        });

        $('#language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.ভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#sub_language_id').select2({
            width: '100%',
            placeholder: "{{__('messages.উপভাষা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#district').select2({
            width: '100%',
            placeholder: "{{__('messages.জেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#upazila').select2({
            width: '100%',
            placeholder: "{{__('messages.উপজেলা নির্বাচন করুন')}}",
            allowClear: true
        });
        $('#union').select2({
            width: '100%',
            placeholder: "{{__('messages.ইউনিয়ন নির্বাচন করুন')}}",
            allowClear: true
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // onclick submit ajax post method
        $(document).ready(function() {
            $(".single-submit").click(function(e) {
                e.preventDefault();
                $.ajax({
                    url: "{{route('admin.single_task_assigns.store')}}",
                    method: 'POST',
                    data: $('#single_task_assign_form').serialize(),
                    success: function (data) {
                        $(".single-submit"). attr("disabled", false);
                        document.getElementById("single_task_assign_form").reset();
                        toastr.success(data.msg);
                        let path = document.location.origin+'/admin/task_assigns';
                        window.location.href =  path;
                    },
                    error: function (data) {
                        console.log(data);
                        var errors = data.responseJSON;
                        var error = errors.errors;
                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "progressBar": true,
                            "positionClass": "toast-top-center",
                            "showMethod" : "slideDown",
                            "hideMethod" : "slideUp"
                        }
                        $.each(error, function (key, value) {
                            toastr.error(value[0]);
                        });
                    }
                })

            });
        });



    </script>
    <script>

        window.onload = function() {
            initFirebaseMessagingRegistration();
        };

        var firebaseConfig = {
            apiKey: "AIzaSyAf8VbB9KukpAFQc-PS1djtgnibSqjvtQ4",
            authDomain: "push-notification-1cd0f.firebaseapp.com",
            projectId: "push-notification-1cd0f",
            storageBucket: "push-notification-1cd0f.appspot.com",
            messagingSenderId: "1027263277408",
            appId: "1:1027263277408:web:d92c18d701a17a4505d605",
            measurementId: "G-9Q38M0HCYE"
        };

        firebase.initializeApp(firebaseConfig);
        const messaging = firebase.messaging();

        function initFirebaseMessagingRegistration() {
            messaging
                .requestPermission()
                .then(function () {
                    return messaging.getToken()

                })
                .then(function(token) {

                    console.log(token);
                    $('#fcm_token').val(token);
                })
                .catch(function (err) {
                    console.log('User Chat Token Error'+ err);
                });
        }

        messaging.onMessage(function(payload) {
            const noteTitle = payload.notification.title;
            const noteOptions = {
                body: payload.notification.body,
                icon: payload.notification.icon,
            };
            new Notification(noteTitle, noteOptions);
        });

       {{-- @if ($errors->any())
        @foreach ($errors->all() as $error)
        toastr.error('{{ $error }}', 'Error', {
            closeButton: true,
            progressBar: true,
            "positionClass": "toast-top-center",
            "showMethod" : "slideDown",
            "hideMethod" : "slideUp"
        });
        @endforeach
        @endif--}}
    </script>
@endsection

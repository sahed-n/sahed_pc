@extends('layouts.app')

@section('title', 'টাস্ক অ্যাসাইন তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('messages.টাস্ক অ্যাসাইন')}}</li>
                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item me-2"><a class="btn btn-success text-white btn-sm" href="{{route('admin.task_assigns.create')}}">
                                <svg class="icon me-2">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                                </svg>{{__('messages.নতুন গ্রুপ টাস্ক')}}</a>
                        </li>
                        <li class="nav-item"><a class="btn btn-success text-white btn-sm" href="{{route('admin.single_task_assigns.create')}}">
                                <svg class="icon me-2">
                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-plus')}}"></use>
                                </svg>{{__('messages.নতুন একক টাস্ক')}}</a>
                        </li>
                    </ul>
                </ul>

            </div>
            <div class="card-body">
                @if($errors->count() > 0)
                    <ul class="list-group notification-object">
                        @foreach($errors->all() as $error)
                            <li class="list-group-item text-danger">
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                @endif
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="task-assign">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 2rem;">{{__('##')}}</th>
                            <th scope="col" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা কালেক্টর')}}">{{__('কালেক্টর')}}</th>
                            <th scope="col">{{__('messages.ভাষা')}}</th>
                            <th scope="col">{{__('messages.নির্দেশিত')}}</th>
                            <th scope="col">{{__('শব্দ ও ব্যাকরণ')}}</th>
                            <th scope="col">{{__('messages.স্বতঃস্ফূর্ত')}}</th>
                            <th scope="col">{{__('messages.অবস্থান')}}</th>
                            <th scope="col" class="text-center">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($taskAssigns as $key=>$taskAssign)
                            <tr>
                                <td>{{ ++ $key }}</td>
                                <td class="">
                                    <div class="small badge bg-primary-new" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা কালেক্টর')}}">{{$taskAssign->collector->name?? ''}}</div>
                                    <div class="small text-medium-emphasis">
                                        <span class="badge bg-info-new" data-toggle="tooltip" data-placement="top" title="{{__('গ্রুপ')}}">{{$taskAssign->group->name??''}}</span>
                                    </div>
                                </td>
                                <td class="small">{{isset($taskAssign->language->name)? $taskAssign->language->name:''}}</td>
                                <td class="directed-viev">
                                    @foreach($taskAssign->topics as $topic)
                                        @php
                                            $directedCollection=\App\Models\DataCollection::where('task_assign_id',$taskAssign->id)
                                                                ->whereHas('dcDirected',function ($query) use ($topic){
                                                                    $query->where('topic_id',$topic->id);
                                                                })->first();
                                        @endphp
                                        @if($directedCollection)
                                            <div class="badge bg-success text-hover" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা সংগ্রহ শুরু')}}">{{$topic->name}}</div>
                                        @else
                                            <div class="badge bg-info-new text-hover" >{{$topic->name}}</div>
                                        @endif
                                    @endforeach
                                </td>
                                <td class="">
                                    @foreach($taskAssign->topicWords as $topicWord)
                                        @php
                                            $wordCollection=\App\Models\DataCollection::where('task_assign_id',$taskAssign->id)
                                                                ->whereHas('dcWord',function ($query) use ($topicWord){
                                                                    $query->where('topic_word_id',$topicWord->id);
                                                                })->first();
                                        @endphp
                                        @if($wordCollection)
                                            <div class="badge bg-success text-hover" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা সংগ্রহ শুরু')}}">{{$topicWord->name}}</div>
                                        @else
                                            <div class="badge bg-info-new text-hover" >{{$topicWord->name}}</div>
                                        @endif
                                    @endforeach
                                </td>
                                <td class="">
                                    @foreach($taskAssign->spontaneouses as $spontaneous)
                                        @php
                                            $spontaneousCollection=\App\Models\DataCollection::where('task_assign_id',$taskAssign->id)
                                                                ->whereHas('dcSpontaneous',function ($query) use ($spontaneous){
                                                                    $query->where('spontaneous_id',$spontaneous->id);
                                                                })->first();
                                        @endphp
                                        @if($spontaneousCollection)
                                            <div class="badge bg-success text-hover" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা সংগৃহীত')}}">{{$spontaneous->word}}</div>
                                        @else
                                            <div class="badge bg-info-new text-hover" >{{$spontaneous->word}}</div>
                                        @endif
                                    @endforeach
                                </td>
                                <td class="small">{{$taskAssign->district->name}}</td>
                                <td class="text-center">
                                    <div class="d-grid gap-2 d-md-flex justify-content-center">
                                        {{--<a class="btn btn-info btn-sm" href="{{route('admin.task_assigns.show', $taskAssign->id)}}">
                                            <svg class="icon  text-white">
                                                <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-low-vision')}}"></use>
                                            </svg>
                                        </a>--}}
                                        @if(!empty($taskAssign->user_id) && $taskAssign->group_id == null)
                                            <a class="btn btn-purple btn-sm" href="{{route('admin.single_task_assigns.edit', $taskAssign->id)}}">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @else
                                            <a class="btn btn-purple btn-sm" href="{{route('admin.task_assigns.edit', $taskAssign->id)}}">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                        @endif
                                        <form action="{{ route('admin.task_assigns.collection.delete', $taskAssign->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-warning btn-sm show_confirm collection-clear" >
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-clear-all')}}"></use>
                                                </svg>
                                            </button>
                                        </form>
                                        <form action="{{ route('admin.task_assigns.destroy', $taskAssign->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button class="btn btn-danger btn-sm task_confirm task-delete">
                                                <svg class="icon  text-white">
                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-trash')}}"></use>
                                                </svg>
                                            </button>
                                        </form>

                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>

        // show_confirm class tooltip show  data collection delete
        $(document).ready(function(){
            $('.collection-clear').tooltip({
                title: "Only Collection Delete",
                placement: "top"
            });
            $('.task-delete').tooltip({
                title: "Task & Collection Delete",
                placement: "top"
            });
        });

        $('body').on('click', '.show_confirm', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি এই টাস্ক মুছে ফেলতে চান ?')}}",
                text: "{{__('যদি এটি মুছে ফেলেন তাহলে টাস্কের ডাটা চিরতরে মুছে যাবে !')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '28px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });


        $('body').on('click', '.task_confirm', function (event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            swal({
                title:" {{__('আপনি কি এই টাস্ক মুছে ফেলতে চান ?')}}",
                text: "{{__('যদি এটি মুছে ফেলেন তাহলে টাস্ক এবং সংগৃহীত ডাটা  চিরতরে মুছে যাবে !')}}",
                icon: "warning",
                dangerMode: true,
                buttons: ["{{__('বন্ধ করুন')}}", "{{__('ওকে')}}"],
            })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });

            $(".swal-title").css('font-size', '23px');
            $(".swal-icon").css('margin', '28px auto 5px');
            $(".swal-button--danger").css('background-color', '#00a629');
            $(".swal-button--cancel").css('background-color', '#df4740');
            $(".swal-button--cancel").css('color', '#fff');
        });

        $(document).ready(function() {
            $('#task-assign').DataTable( {
                dom: 'Bfrtip',
                lengthChange: false,
                buttons: [
                    'copy', 'csv', 'excel', 'print'
                    // { extend: 'excel', className: 'btn btn-primary' },
                    // { extend: 'csv', className: 'btn btn-success' },
                    // { extend: 'print', className: 'btn btn-warning' }
                ],
                order:false
            } );
            table.buttons().container()
        .appendTo( '#task-assign_wrapper .col-md-6:eq(0)' );

        } );

        // tooltip show
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });


    </script>
@endsection


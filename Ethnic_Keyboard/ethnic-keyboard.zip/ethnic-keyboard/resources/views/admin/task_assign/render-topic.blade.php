<table class="table table-bordered table-hover table-striped table-responsive">
    <tbody>
    @foreach($directeds as $key=> $directed)
        <tr>
            <td>
                <div class="form-check form-check-inline">
                    <label class="form-check-label directed-hover " style="cursor:pointer;">
                        <input class="form-check-input directed-checked @error('topic_id') is-invalid @enderror" style="cursor:pointer;" name="topic_id[]" type="checkbox" value="{{$key}}">
                        <small  class="badge-new bg-info-new text-hover text-white">{{$directed}}</small>

                    </label>
                    @error('topic_id')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

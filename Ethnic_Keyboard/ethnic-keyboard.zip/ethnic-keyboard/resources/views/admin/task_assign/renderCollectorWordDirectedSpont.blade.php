@foreach($collectors as $key =>$collector)
    <div class="row mb-2"  id="topicSelect{{$key}}">
        <div class="row">
            <div class="col-md-2 col-sm-2">
                <input type="hidden" name="user_id[]" id="user_id" value="{{$key}}">
                <label class=" col-form-label" for="user_id" style="font-size:15px">{{$collector}}</label>
            </div>
            <div class="col-md-4 col-sm-5">
                <div class=" input-group" >
                    <div class="form-check form-check-inline" style="width: 14rem;">
                        <input class="form-check-input all-directed-checked" name="directed{{$key}}" id="directed{{$key}}" type="checkbox" onclick="checkAll(document.getElementsByClassName('directed{{$key}}'),this)">
                        <label class="form-check-label" for="directed">{{__('messages.নির্দেশিত')}}</label>
                    </div>
                </div>
                <div class="row" style="height: 350px; position:relative;">
                    <div class="directed directed{{$key}}" id="topic_id{{$key}}" data-id="topic_id{{$key}}" style="position:absolute; max-height:100%;overflow:auto;">
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class=" input-group" >
                    <div class="form-check form-check-inline" style="width: 14rem;">
                        <input class="form-check-input all-word-checked" name="word{{$key}}" id="word{{$key}}" type="checkbox" onclick="checkAll(document.getElementsByClassName('word{{$key}}'),this)">
                        <label class="form-check-label" for="word">{{__('শব্দ ও ব্যাকরণ')}}</label>
                    </div>
                </div>
                <div class="row" style="height: 350px; position:relative;">
                    <div class="word word{{$key}} " id="topic_word_id{{$key}}" data-id="topic_word_id{{$key}}" style="position:absolute; max-height:100%;overflow:auto;">
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-3">
                <div class="input-group" >
                    <div class="form-check form-check-inline" style="width: 14rem;">
                        <input class="form-check-input all-spontaneous-checked" name="spontaneous{{$key}}" id="spontaneous{{$key}}" type="checkbox" onclick="checkAll(document.getElementsByClassName('spontaneous{{$key}}'),this)">
                        <label class="form-check-label" for="spontaneous">{{__('messages.স্বতঃস্ফূর্ত')}}</label>
                    </div>
                </div>
                <div class="row" style="height: 350px; position:relative;">
                    <div class="spontaneous spontaneous{{$key}} " id="spontaneous_id{{$key}}" style="position:absolute; max-height:100%;overflow:auto;">

                    </div>
                </div>

            </div>
        </div>
    </div>
@endforeach

@extends('layouts.app')

@section('title', '')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header pb-0">
                <nav aria-label="breadcrumb" role="navigation">
                    <div class="row">
                        <div class="col-md-6">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                                    <a class="btn btn-sm btn-success" href="{{route('admin.dashboard' )}}">
                                        <i class="fas fa-arrow-left text-white"></i>
                                    </a>
                                </li>
                                <li class="breadcrumb-item">{{__('messages.স্বতঃস্ফূর্ত')}}</li>
                                <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="{{__('ভাষা')}}">
                                    {{$firstItem->taskAssign->language->name}}
                                </li>
                                <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="{{__('জেলা')}}">
                                    {{$firstItem->taskAssign->district->name}}
                                </li>
                            </ol>
                        </div>
                        <div class="col-md-6 text-end">
                            <span class="breadcrumb-item badge bg-info-new text-hover" data-toggle="tooltip" data-placement="top" title="{{__('সময়')}}">
                                <label class="form-check-label" for="total_time">{{__('মোট সংগ্রহ')}} :</label>
                                    @php
                                        $seconds = $collected_time??0;
                                            $minutes = floor($seconds / 60);
                                            $seconds = $seconds % 60;
                                    @endphp
                                @if(app()->getLocale() == 'bn')
                                    {{ Converter::en2bn((int)$minutes) }} {{__('মিনিট')}} {{ Converter::en2bn((int)$seconds) }} {{__('সেকেন্ড')}}
                                @else
                                    {{ (int)$minutes }} {{__('Minutes')}} {{ (int)$seconds }} {{__('Seconds')}}
                                @endif
                            </span>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="spontaneousTopic">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">{{__('messages.কীওয়ার্ড')}}</th>
                            <th scope="col">{{__('messages.অ্যাকশন')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($spontaneousTaskLanguages as $key=> $spontaneousTaskLanguage)
                            @php
                                $taskAssignID =$spontaneousTaskLanguage->task_assign_id;
                                $districtID =$spontaneousTaskLanguage->taskAssign->district->id;
                                $spontaneousID =$spontaneousTaskLanguage->spontaneous_id;

                                $dataCollection =  \App\Models\DataCollection::where('task_assign_id', $taskAssignID)
                                    ->where('district_id', $districtID )
                                    ->where('type_id', 2)
                                    ->with('dcSpontaneous')
                                    ->WhereHas('dcSpontaneous',function($q)use($spontaneousID){
                                        $q->where('spontaneous_id', $spontaneousID);
                                    })
                                    ->first();
                            @endphp
                            <tr>
                                <th scope="row">{{  $loop->iteration }}</th>
                                <td class="">
                                    <span class="badge-new bg-info-new text-white text-hover">{{ $spontaneousTaskLanguage->spontaneous->word }}</span>
                                </td>
                                <td class="text-center">
                                    <div class="d-grid gap-2 d-md-block">
                                        @if(isset($dataCollection))
                                            <a class="btn btn-info btn-sm text-white" data-toggle="tooltip" data-placement="top" title="{{__('বিস্তারিত ট্রিম অডিও')}}" href="{{route('admin.spontaneous.trim.list', $dataCollection->dcSpontaneous->id)}}">
                                                {{__('দেখুন')}}
                                            </a>
                                            {{--@can('Spontaneous-Edit')
                                                <a class="btn btn-primary btn-sm"  href="{{route('admin.data_collections.spontaneous.edit', $dataCollection->dcSpontaneous->id)}}">
                                                    <i class="text-white fas fa-edit"></i>
                                                </a>
                                            @endcan--}}
                                        @endif
                                        @can('Data Collection Show')
                                            <a class="btn btn-purple btn-sm text-white" data-toggle="tooltip" data-placement="top" title="{{__('ডাটা সংগ্রহের পেজ')}}" href="{{route('admin.data_collection.spontaneous.word',['task_assign_id'=>$taskAssignID,'spontaneous_id'=>$spontaneousID])}}">
                                                {{__('ডাটা সংগ্রহ')}}
                                            </a>
                                            @if(isset($dataCollection))
                                                <a class="btn btn-success btn-sm text-white" data-toggle="tooltip" data-placement="top" title="{{__('ট্রিম পেজ')}}" href="{{ route('trim-page', ['type'=>'spontaneous', 'id' =>$dataCollection->dcSpontaneous->id ]) }}">
                                                    {{__('ট্রিম করুন')}}
                                                </a>
                                            @endif

                                        @endcan

                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>
@endsection

@section('language-filter-js')
    <script>
        $(document).ready(function() {
            $('#spontaneousTopic').DataTable({
                order:false,
            });
        } );

        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
            // background color change warning and text color danger
        })
    </script>

@endsection


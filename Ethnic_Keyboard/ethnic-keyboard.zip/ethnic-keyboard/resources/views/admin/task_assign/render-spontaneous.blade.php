<table class="table table-bordered table-hover table-striped table-responsive">
    <tbody>
    @foreach($spontaneouses as $key2 =>$spontaneous)
        <tr>
            <td>
                <div class="form-check form-check-inline">
                    <label class="form-check-label spontaneous-hover" style="cursor:pointer;">
                        <input class="form-check-input spontaneous-checked" style="cursor: pointer" name="spontaneous_id[]" type="checkbox" value="{{$key2}}">
                        <small  class="badge-new bg-info-new text-hover text-white">{{$spontaneous}}</small>
                    </label>
                </div>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

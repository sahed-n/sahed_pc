<table class="table table-bordered table-hover table-striped table-responsive">
    <tbody>
    @foreach($topicWords as $key1=>$topicWord)
        <tr>
            <td>
                <div class="form-check form-check-inline" >
                    <label class="form-check-label" style="cursor:pointer;">
                        <input class="form-check-input word-checked" style="cursor:pointer;" name="topic_word_id[]" type="checkbox" value="{{$key1}}">
                        <small class="badge-new bg-info-new text-white text-hover"> {{$topicWord}}</small>
                    </label>
                </div>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>

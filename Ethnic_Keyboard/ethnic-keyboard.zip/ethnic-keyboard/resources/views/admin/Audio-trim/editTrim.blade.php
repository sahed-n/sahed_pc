{{--
@extends('layouts.app')

@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                --}}
{{--<nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.spontaneous.trim.list', $trimAudio->d_c_spontaneouses_id )}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">{{__('messages.স্বতঃস্ফূর্ত')}}</li>
                        <li class="breadcrumb-item">{{__('messages.ট্রিম')}}</li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Language" >
                            {{$trimAudio->dcSpontaneous->collection->language->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="District">
                            {{$trimAudio->dcSpontaneous->collection->district->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Topic">
                            {{$trimAudio->dcSpontaneous->spontaneous->word}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Group">
                            {{isset($trimAudio->dcSpontaneous->collection->taskAssign->group)? $trimAudio->dcSpontaneous->collection->taskAssign->group->name: ''}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Collector">
                            <a href="{{route('admin.data_collectors.show', $trimAudio->dcSpontaneous->collection->collector->id )}}" class="text-decoration-none" target="_blank">
                                {{$trimAudio->dcSpontaneous->collection->collector->name}}
                            </a>
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Speaker">
                            <a href="{{route('admin.speakers.edit',$trimAudio->dcSpontaneous->collection->speaker->id)}}" class="text-decoration-none" target="_blank">
                                {{$trimAudio->dcSpontaneous->collection->speaker->name}}
                            </a>

                        </li>
                    </ol>
                </nav>--}}{{--

            </div>
            <div class="card-body">
                --}}
{{--@if(Session::has('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
                        <button class="btn-close" type="button" data-coreui-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif--}}{{--

                <form action="--}}
{{--{{route('admin.data_collections.spont.trim.update', $trimAudio->id)}}--}}{{--
" method="post" >
                    @csrf
                    @method("PUT")
                    --}}
{{--<div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="row mb-3">
                                <label for="nid">{{__('messages.সংগৃহীত')}} <span class="text-danger">*</span></label>
                                <div>
                                    <input type="hidden" id="audio" value="{{$trimAudio->audio}}">
                                    <div id="wavetrim"></div>
                                    <div id="waveform-time-indicator" class="justify-content-between">
                                        <input type="button" id="btn-play" value="Play"/>
                                        <span class="time">00:00:00</span>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  for="bangla">{{__('messages.বাংলা')}}</label>
                                <div class="input-group ">
                                    <textarea class="form-control @error('bangla') is-invalid @enderror" name="bangla" id="bangla" cols="30" rows="3">{{$trimAudio->bangla}}</textarea>
                                    @error('bangla')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  for="english">{{__('messages.অনুবাদ')}}</label>
                                <div class="input-group ">
                                    <textarea class="form-control @error('english') is-invalid @enderror" name="english" id="english" cols="30" rows="3">{{$trimAudio->english}}</textarea>
                                    @error('english')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label  for="transcription">{{__('messages.উচ্চারণ')}}</label>
                                <div class="input-group ">
                                    <textarea class="form-control @error('transcription') is-invalid @enderror" name="transcription" id="transcription" cols="30" rows="3">{{$trimAudio->transcription}}</textarea>
                                    @error('transcription')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="text-end">
                                <button class="btn btn-success text-white" type="submit">{{__('messages.জমা দিন')}}</button>
                            </div>
                        </div>
                    </div>--}}{{--

                </form>
            </div>
        </div>
    </div>
@endsection
@section('group-task-assgin-js')
    <script type="text/javascript">
    </script>
@endsection
--}}


@extends('layouts.app')
<style>
    .table-responsive {
        overflow-y:scroll;
        height:550px;
    }
</style>
@section('content')
    <div class="container-fluid pl-0 px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.spontaneous.trim.list', $firtItem->d_c_spontaneouses_id )}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">{{__('messages.স্বতঃস্ফূর্ত')}}</li>
                        <li class="breadcrumb-item">{{__('messages.ট্রিম')}}</li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Language" >
                            {{$firtItem->dcSpontaneous->collection->language->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="District">
                            {{$firtItem->dcSpontaneous->collection->district->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Topic">
                            {{$firtItem->dcSpontaneous->spontaneous->word}}
                        </li>
                        @if(isset($firtItem->dcSpontaneous->collection->taskAssign->group))
                            <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Group">
                                {{$firtItem->dcSpontaneous->collection->taskAssign->group->name?? ''}}
                            </li>
                        @endif
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Collector">
                            <a href="{{route('admin.data_collectors.show', $firtItem->dcSpontaneous->collection->collector->id )}}" class="text-decoration-none" target="_blank">
                                {{$firtItem->dcSpontaneous->collection->collector->name??''}}
                            </a>
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Speaker">
                            <a href="{{route('admin.speakers.edit',$firtItem->dcSpontaneous->collection->speaker->id)}}" class="text-decoration-none" target="_blank">
                                {{$firtItem->dcSpontaneous->collection->speaker->name}}
                            </a>

                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                {{--@foreach ($trimBySpontaneouses as $trimBySpontaneous)--}}
                    <div class="row">
                        <div class="col-md-5 col-sm-12">
                            <form action="" id="sentence_form" method="post" enctype="multipart/form-data">
                                @csrf
                                @method('PUT')
                                <div class="row mb-3">
                                    <div class="">
                                        <input type="hidden"  id="audio" value="">
                                        <input type="hidden" id="audio-exist" value="{{$trimBySpontaneous->audio}}">
                                        <div id="wavetrim"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="btn-play" value="Play"/>
                                            <span class="time">00:00:00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('বাংলা')}}</strong></label>
                                    <div class="input-group">
                                        <textarea class="form-control" name="bangla" id="bangla" cols="30" rows="3">{{ $trimBySpontaneous->bangla }}</textarea>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('অনুবাদ')}}</strong> </label>
                                    <div class="input-group">
                                        <textarea class="form-control" name="english" id="english" cols="30" rows="3"> {{ $trimBySpontaneous->english?? ''}}</textarea>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <label class="" ><strong>{{__('উচ্চারণ')}}</strong> </label>
                                    <div class=" input-group">
                                        <textarea class="form-control" name="transcription" id="transcription" cols="30" rows="3">{{$trimBySpontaneous->transcription??''}}</textarea>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="text-end m-1 ">
                                        {{--<a href="{{ $trimBySpontaneouses->nextPageUrl() != null ? $trimBySpontaneouses->nextPageUrl() : ''  }}" style="display: none"  id="next_page"></a>
                                        @if($trimBySpontaneouses->previousPageUrl() != null)
                                            <a href="{{ $trimBySpontaneouses->previousPageUrl() }}" class="btn btn-success text-white float-start">Previous</a>
                                        @endif
                                        <button type="submit" class="btn btn-success text-white custom-tooltip" id="save_form">{{ $trimBySpontaneouses->nextPageUrl() != null ? 'Submit & Next' : 'Submit' }}</button>--}}
                                        <button class="btn btn-success text-white float-start" id="trim-previous">Previous</button>
                                        <button type="submit" class="btn btn-success text-white custom-tooltip" id="save_form">Submit & Next</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-7 px-0">
                            <div class="col-md-12 col-sm-12">
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-bordered" id="data-collection">
                                            <thead class="table-dark">
                                            <tr>
                                                <th scope="col" style="width: 3rem;">{{__('##')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('বাংলা')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('অনুবাদ')}}</th>
                                                <th scope="col" style="font-size:12px">{{__('উচ্চারণ')}}</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach ($trimAudios as $trimAudio)
                                                <tr data-sentence-id="{{ $loop->iteration }}">
                                                    <td>
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($loop->iteration)}})
                                                        @else
                                                            {{ $loop->iteration}}
                                                        @endif
                                                    </td>

                                                    <td class="">
                                                        <a href="{{ url()->current() }}?audio_trim_id={{$trimAudio->id}}&page={{ $loop->iteration }}" class="nav-link text-dark">
                                                            {{ $trimAudio->bangla }}
                                                        </a>
                                                    </td>
                                                    <td class="">
                                                        <a href="{{ url()->current() }}?audio_trim_id={{$trimAudio->id}}&page={{ $loop->iteration }}" class="nav-link text-dark">
                                                            @if(isset($trimAudio->english))
                                                                <i class="fa fa-check text-success"></i>
                                                            @else
                                                                <i class="fa fa-times text-danger"></i>
                                                            @endif
                                                        </a>
                                                    </td>
                                                    <td class="">
                                                        <a href="{{ url()->current() }}?audio_trim_id={{$trimAudio->id}}&page={{ $loop->iteration }}" class="nav-link text-dark">
                                                            @if(isset($trimAudio->transcription))
                                                                <i class="fa fa-check text-success"></i>
                                                            @else
                                                                <i class="fa fa-times text-danger"></i>
                                                            @endif
                                                        </a>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {{--@endforeach--}}
            </div>
        </div>
    </div>
@endsection
@section('language-js')
    <script>
        $(document).ready(function () {
            // directed sentence active
            $(function($) {
                let url = window.location.href;
                const queryString = window.location.search;
                const urlParams = new URLSearchParams(queryString);
                const pageNo = urlParams.get('page');
                var speakerIdUrl = urlParams.get('speaker');

                if (pageNo === null){
                    $("#data-collection tbody").children(":first").addClass('collection-active');
                }

                $('#data-collection tbody tr td a').each(function() {
                    if (this.href === url) {
                        $(this).closest('tr').addClass('collection-active');
                        $(this).closest('tr').next().addClass('collection-next');
                        $(this).closest('tr').prev().addClass('collection-previous');


                        //  start  -- scroll to selected tr
                        var container = $('.table-responsive');
                        var scrollTo = $(".collection-active");

                        // Calculating new position  of scrollbar
                        var position = scrollTo.offset().top
                            - container.offset().top
                            + container.scrollTop();

                        // Animating scrolling effect
                        container.animate({
                            scrollTop: position
                        });
                    }else if (speakerIdUrl !== null)
                    {
                        if ($(this).closest('tr').attr('data-sentence-id') === pageNo)
                        {
                            $(this).closest('tr').addClass('collection-active');

                            var $container = $('.table-responsive'),
                                $scrollTo = $('.collection-active')
                            $container.scrollTop(
                                $scrollTo.offset().top - $container.offset().top + $container.scrollTop()
                            );
                        }
                    }
                });
            });
        });

    </script>


    <script>
        $('#sentence_form').on('submit',function(e){
            e.preventDefault();
            trimUpdate();
        });

        // trim-previous on click
        $('#trim-previous').on('click',function(e){
            e.preventDefault();
            var previousPagePath= $('.collection-previous').find('a').attr('href');
            window.location.href =  previousPagePath;
        });

        $(document).ready(function () {
            setTimeout(function () {
                var nextPagePath= $('.collection-next').find('a').attr('href');
                if (nextPagePath == undefined) {
                    $('#save_form').html('Submit');
                }
                var previousPagePath= $('.collection-previous').find('a').attr('href');
                if (previousPagePath == undefined) {
                    $('#trim-previous').hide();
                }
            }, 1000);

        });
    </script>

    <script>
        function trimUpdate() {
            $('#save_form').attr('disabled',true);
            var form     = document.getElementById("sentence_form")
            var formData = new FormData(form);
            submit = document.getElementById("save_form").innerHTML;
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },

                type:'post',
                url: "{{route('admin.data_collections.spont.trim.update', $firtItem->id)}}",
                data: formData,
                processData: false,
                contentType: false,
                dataType:'json',
                async :true,
                success: function (data) {
                    toastr.success(data.msg);

                    if(submit == 'Submit'){
                        let path = document.location.origin+'/admin/spontaneous/trim/{{$firtItem->d_c_spontaneouses_id}}/list';
                        window.location.href =  path;
                    }else{
                        var nextPagePath= $('.collection-next').find('a').attr('href');
                        window.location.href =  nextPagePath;
                    }
                },
                error: function (data) {
                    var errors = data.responseJSON;
                    var error = errors.errors;
                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "progressBar": true,
                        "positionClass": "toast-top-center",
                        "showMethod" : "slideDown",
                        "hideMethod" : "slideUp"
                    }
                    $.each(error, function (key, value) {
                        toastr.error(value[0]);
                    });
                    $('#save_form').attr('disabled',false);
                }

            });
        }
    </script>
@endsection


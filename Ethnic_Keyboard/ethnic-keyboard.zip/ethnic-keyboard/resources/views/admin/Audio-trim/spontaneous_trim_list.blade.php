@extends('layouts.app')

@section('title', '')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.spontaneous.language.tasks.list', $firstItem->collection->task_assign_id)}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>

                        <li class="breadcrumb-item">{{__('messages.স্বতঃস্ফূর্ত')}}</li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Language" >
                            {{$firstItem->collection->language->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="District">
                            {{$firstItem->collection->district->name}}
                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Topic">
                            {{$firstItem->spontaneous->word}}
                        </li>
                        @if(isset($firstItem->collection->taskAssign->group))
                            <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Group">
                                {{isset($firstItem->collection->taskAssign->group)? $firstItem->collection->taskAssign->group->name: ''}}
                            </li>
                        @endif

                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Collector">
                            <a href="{{route('admin.data_collectors.show', $firstItem->collection->collector->id )}}" class="text-decoration-none" target="_blank">
                                {{$firstItem->collection->collector->name}}
                            </a>

                        </li>
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Speaker">
                            <a href="{{route('admin.speakers.edit', $firstItem->collection->speaker->id)}}" class="text-decoration-none" target="_blank">
                                {{$firstItem->collection->speaker->name}}
                            </a>

                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">{{__('messages.বাংলা')}}</th>
                            <th scope="col">{{__('messages.উচ্চারণ')}}</th>
                            <th scope="col">{{__('messages.অডিও')}}</th>
                            <th scope="col">{{__('শুরুর সময়')}}</th>
                            <th scope="col">{{__('messages.যাচাইকৃত')}}</th>
                            <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                            @can('Audio-Validation-Name')
                                <th scope="col">{{__('messages.অ্যাকশন')}}</th>
                            @endcan
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($spontaneousTrimLists as $key=> $spontaneousTrimItem)
                            <tr>
                                <th scope="row">{{$loop->iteration }}</th>
                                <td class="">
                                    {{$spontaneousTrimItem->bangla}}
                                </td>
                                <td class="">
                                    {{$spontaneousTrimItem->transcription}}
                                </td>
                                @if(isset($spontaneousTrimItem))
                                    @php
                                        $audio = explode('/', $spontaneousTrimItem->audio);
                                        $uniqueCode=substr(end($audio), 0, -4);
                                        $uniqueCode= str_replace('.', '', $uniqueCode);
                                    @endphp
                                    <td class="align-middle text-start ss " style="width: 13rem" >
                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{ $spontaneousTrimItem??'' }})"></button>
                                        <div id="waveform{{$uniqueCode??''}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode??''}}" value="Play"/>
                                            <span id="total-time{{$uniqueCode}}" class="time{{$uniqueCode??''}}"></span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$spontaneousTrimItem->audio}}" onclick="dowonloadFile()">
                                                {{__('ডাউনলোড')}}
                                            </button>

                                        </div>
                                    </td>
                                @endif
                                <td class="">
                                    {{$spontaneousTrimItem->start_time}}
                                </td>
                                <td class="" id="validationStatus{{@$spontaneousTrimItem->id}}">
                                    @if(isset($spontaneousTrimItem->validation_status))
                                        @if($spontaneousTrimItem->validation_status==1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.সঠিক')}}</span>
                                        @else
                                            <span class="badge rounded-pill bg-warning">{{__('messages.সঠিক না')}}</span>
                                        @endif
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                @if(isset($spontaneousTrimItem))
                                    @if($spontaneousTrimItem->status == 0)
                                        <td class="">
                                            <i class="fa fa-times text-danger"></i>
                                        </td>
                                    @elseif($spontaneousTrimItem->status == 2)
                                        <td class="">
                                            <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                        </td>
                                    @elseif($spontaneousTrimItem->status == 1)
                                        <td class="">
                                            <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                        </td>
                                    @elseif($spontaneousTrimItem->status == 3)
                                        <td class="">
                                            <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                        </td>
                                    @endif

                                @else
                                    <td>
                                        <i class="fa fa-times text-danger"></i>
                                    </td>
                                @endif
                                @can('Approval-List')
                                    <td>
                                        <div class="d-grid gap-2 d-md-flex justify-content-start">
                                            @if(isset($spontaneousTrimItem))
                                                @if($spontaneousTrimItem->status===1)
                                                    @can('Spontaneous-Edit')
                                                        <a class="btn btn-info btn-sm" href="{{route('admin.data_collections.spont.trim.edit', $firstItem->id)}}?audio_trim_id={{$spontaneousTrimItem->id}}&page={{$loop->iteration}}">
                                                            <i class="text-white fas fa-edit"></i>
                                                        </a>
                                                    @endcan
                                                @endif
                                            @endif

                                            @if(isset($spontaneousTrimItem))
                                                @if(Auth::user()->hasRole(['Validator', 'Data Collector']))
                                                    @if($spontaneousTrimItem->validation_status === null && $spontaneousTrimItem->status== 1)
                                                        @can('Validation-Button')

                                                                <a href="javascript:void(0)" onclick="validatorAgree({{$spontaneousTrimItem->id}})" id="agree{{$spontaneousTrimItem->id}}" type="button" class="btn btn-purple btn-sm">
                                                                    {{__('একমত')}}
                                                                </a>
                                                            <form action="{{route('admin.validation.spontaneous.word.store')}}" method="post">
                                                                @csrf
                                                                <input  id="collectorID" type="hidden" name="collector_id" value="{{ $collectorID }}">
                                                                <input  id="audio_trim_id" type="hidden" name="audio_trim_id" value="{{$spontaneousTrimItem->id}}">
                                                                <input class="form-check-input " id="NotAgree" type="hidden" name="validation_status" value="0">
                                                                <button class="btn btn-purple btn-sm edit-btn text-white" id="disagree{{$spontaneousTrimItem->id}}" type="button" value="{{$spontaneousTrimItem->id}}">
                                                                    {{__('messages.একমত নই')}}
                                                                </button>
                                                            </form>
                                                        @endcan
                                                    @endif
                                                @endif
                                                @if(isset($spontaneousTrimItem))
                                                    @if($spontaneousTrimItem->validation_status!=NULL)
                                                        @if($spontaneousTrimItem->status===1)
                                                            @can('Data Collection Approve')
                                                                <form action="{{route('admin.approved.spontaneous.word.store')}}" method="post">
                                                                    @csrf
                                                                    <input  id="audio_trim_id" type="hidden" name="audio_trim_id" value="{{$spontaneousTrimItem->id}}">
                                                                    <input  id="Agree" type="hidden" name="validation_status" value="1">
                                                                    <button class="btn btn-success btn-sm text-white">
                                                                        {{__('messages.অনুমোদন')}}
                                                                    </button>
                                                                </form>
                                                                <form action="{{route('admin.validation.spontaneous.word.store')}}" method="post">
                                                                    @csrf
                                                                    <input  id="audio_trim_id" type="hidden" name="audio_trim_id" value="{{$spontaneousTrimItem->id}}">
                                                                    <input class="form-check-input " id="NotAgree" type="hidden" name="validation_status" value="0">
                                                                    <button class="btn btn-danger btn-sm edit-btn text-white" type="button" value="{{$spontaneousTrimItem->id}}">
                                                                        {{__('messages.রিভার্ট')}}
                                                                    </button>
                                                                </form>
                                                            @endcan
                                                        @endif
                                                    @endif
                                                @endif
                                            @endif

                                        </div>
                                    </td>
                                @endcan
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @include('admin.data_collection.revert')
@endsection

@section('language-filter-js')
    <script>

        function validatorAgree(id){
            console.log(id);
            $.ajax({
                url: "{{route('admin.validation.spontaneous.word.store')}}",
                type: "POST",
                data: {
                    audio_trim_id: id,
                    validation_status: 1,
                    _token: "{{ csrf_token() }}",
                },
                success: function (response) {
                    console.log(response);
                    toastr.success(response.msg);
                    $('#agree'+id).hide();
                    $('#disagree'+id).hide();
                    $('#validationStatus'+id).html('<span class="badge rounded-pill bg-success">{{__('সঠিক')}}</span>');
                },
                error: function (response) {
                    console.log(response);
                }
            });
        }



        $(document).ready(function (){
            $(document).on('click', '.edit-btn', function (){
                var trimID = $(this).val();
                var ID = $('#parent_audio').val();
                var Type = $('#audioType').val();
                var collectorID = $('#collectorID').val();

                $('#trimEditForm').modal('show');

                $.ajax({
                    type: "GET",
                    url: "/admin/revert/"+trimID,
                    dataType: 'json',
                    data: {ID:ID, Type:Type, collectorID:collectorID},
                    success:function (response){
                        console.log(response)
                        $('#trimID').val(trimID);
                        $('#ID').val(ID);
                        $('#audio_type').val(Type);
                        $('#collector_id').val(collectorID);

                    }
                })
            })
        })


        $("#revert-message").on('click', function (event){
            event.preventDefault();
            var x = document.getElementById("form-comment");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        })


        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }
    </script>

@endsection


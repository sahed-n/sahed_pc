@extends('layouts.app')

@section('title', 'ভাষা অনুসারে অর্পিত দায়িত্ব')

@section('content')
    <div class="container-fluid px-0 ">
        <div class="card mb-3 min-vh-100">
            <div class="card-header"><a class="btn btn-sm bg-success" href="{{route('admin.dashboard')}}">{{__('ড্যাশবোর্ড ফিরে যান')}}</a></div>
            <div class="card-body">
                @if(Auth::user()->hasRole(['Linguist']))
                    <div class="card mb-3">
                        <div class="card-header">
                            <ul class="nav nav-pills card-header-pills justify-content-between">
                                <li class="nav-item">{{__('ভাষা অনুসারে অর্পিত দায়িত্ব')}}</li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @foreach($taskAssignByLinguists as $linguistTaskAssign)
                                    <div class="col-xl-2">
                                        @php
                                            $total=0;
                                        @endphp
                                        @foreach($linguistTaskAssign->directedTasks as $t)
                                            @php
                                                $num = $t->topic->directeds_count;
                                                $total = $num + $total;
                                            @endphp
                                        @endforeach
                                        @php
                                            $totalWord=0;
                                        @endphp
                                        @foreach($linguistTaskAssign->wordTasks as $tw)
                                            @php
                                                $num = $tw->topicWord->words_count;
                                                $totalWord = $num + $totalWord;
                                            @endphp
                                        @endforeach

                                        <div class="card text-white @if($linguistTaskAssign->collections->isEmpty()) bg-danger @elseif(count($linguistTaskAssign->collections) == $total+$linguistTaskAssign->spontaneous_tasks_count ) bg-success @else bg-primary-new @endif mb-3">
                                            <div class="card-body" >
                                                <h5 class="card-title text-center" style="font-size: 1rem;">{{$linguistTaskAssign->language->name}}</h5>
                                                <h6 class="card-subtitle text-center mb-2" style="font-size: 0.8rem;">({{$linguistTaskAssign->district->name}})</h6>
                                                <h6 class="card-subtitle text-center mb-2" style="font-size: 0.7rem;">({{$linguistTaskAssign->collector->name}})</h6>
                                                <p class="card-text text-center mb-0 custom-hover">
                                                    <a class="text-white text-decoration-none" style="font-size: .9rem;" href="{{route('admin.directed.language.tasks.list', $linguistTaskAssign->id)}}">
                                                        {{__('messages.নির্দেশিত')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($linguistTaskAssign->directed_tasks_count)}})
                                                        @else
                                                            ({{$linguistTaskAssign->directed_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                                <p class="card-text text-center mb-0 custom-hover" id="scrollToDiv">
                                                    <a class="text-white text-decoration-none" style="font-size: .9rem;" href="{{route('admin.spontaneous.language.tasks.list', $linguistTaskAssign->id)}}">
                                                        {{__('messages.স্বতঃস্ফূর্ত')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($linguistTaskAssign->spontaneous_tasks_count)}})
                                                        @else
                                                            ({{$linguistTaskAssign->spontaneous_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                                <p class="card-text text-center custom-hover">
                                                    <a class="text-white text-decoration-none" style="font-size: .9rem;" href="{{route('admin.word.language.tasks.list', $linguistTaskAssign->id)}}">
                                                        {{__('শব্দ ও ব্যাকরণ')}}
                                                        @if(app()->getLocale() == 'bn')
                                                            ({{Converter::en2bn($linguistTaskAssign->word_tasks_count)}})
                                                        @else
                                                            ({{$linguistTaskAssign->word_tasks_count}})
                                                        @endif
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

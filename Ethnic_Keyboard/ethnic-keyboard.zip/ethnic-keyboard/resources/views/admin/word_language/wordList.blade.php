@extends('layouts.app')

@section('title', '')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.word.language.tasks.list', $wordTaskByTopic->task_assign_id)}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">{{__('শব্দ ও ব্যাকরণ')}}</li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="Language">
                            {{$wordTaskByTopic->taskAssign->language->name}}
                        </li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="District">
                            {{$wordTaskByTopic->taskAssign->district->name}}
                        </li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="topic">
                            {{$wordTaskByTopic->topicWord->name}}
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col" style="width: 14rem;">{{__('messages.বাক্য')}}</th>
                            <th scope="col">{{__('messages.অনুবাদ')}}</th>
                            <th scope="col">{{__('messages.অডিও')}}</th>
                            <th scope="col">{{__('messages.উচ্চারণ')}}</th>
                            <th scope="col">{{__('messages.যাচাইকৃত')}}</th>
                            <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                            @can('Audio-Validation-Name')
                                <th scope="col" style="width: 10rem">{{__('messages.অ্যাকশন')}}</th>
                            @endcan
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($wordCollections as $key=> $wordCollection)
                            @php
                                $taskAssignID =$wordTaskByTopic->task_assign_id;
                                $districtID =$wordTaskByTopic->taskAssign->district->id;
                                $topicID =$wordTaskByTopic->topic_word_id;

                                $dataCollection =  \App\Models\DataCollection::where('task_assign_id', $taskAssignID)
                                    ->where('district_id', $districtID )
                                    ->where('type_id', 0)
                                    ->with(['dcWord.dcWordCollection'=>function ($query) {
                                        $query->select('id', 'word_id', 'd_c_word_id', 'audio','status',
                                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                                    }])
                                    ->WhereHas('dcWord',function($q)use($topicID){
                                        $q->where('topic_word_id', $topicID);
                                    })
                                    ->whereHas('dcWord.dcWordCollection', function ($q1) use ($wordCollection){
                                        $q1->where('word_id', $wordCollection->id);
                                    })
                                    ->first();
                                    // echo $dataCollection;
                            @endphp
                            <tr>
                                <th scope="row">
                                    @if(app()->getLocale() == 'bn')
                                        ({{Converter::en2bn($loop->iteration)}})
                                @else
                                    {{$loop->iteration}}
                                @endif
                                <td class="">
                                    @if(isset($dataCollection->dcWord->dcWordCollection->bangla))
                                        {{$dataCollection->dcWord->dcWordCollection->bangla}}
                                    @else
                                        {{$wordCollection->sentence}}
                                    @endif
                                </td>
                                <td class="">
                                    @if(isset($dataCollection->dcWord->dcWordCollection->english))
                                        {{$dataCollection->dcWord->dcWordCollection->english}}
                                    @else
                                        {{$wordCollection->english}}
                                    @endif
                                </td>

                                <td class="">
                                    @if(isset($dataCollection))
                                        @php
                                            if($dataCollection->dcWord->dcWordCollection->audio != null){
                                                $audio = explode('/', $dataCollection->dcWord->dcWordCollection->audio);
                                                $uniqueCode=substr(end($audio), 0, -4);
                                                $uniqueCode= str_replace('.', '', $uniqueCode);
                                            }
                                        @endphp

                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{$dataCollection->dcWord->dcWordCollection}})"></button>
                                        <div id="waveform{{$uniqueCode}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcWord->dcWordCollection->audio}}" onclick="dowonloadFile()" >
                                                {{__('ডাউনলোড')}}
                                            </button>

                                        </div>
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td class="">
                                    @if(isset($dataCollection->dcWord->dcWordCollection->transcription))
                                        {{$dataCollection->dcWord->dcWordCollection->transcription}}
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td class="" id="validationStatus{{@$dataCollection->dcWord->dcWordCollection->id}}">
                                    @if(isset($dataCollection->dcWord->dcWordCollection->validation_status))
                                        @if($dataCollection->dcWord->dcWordCollection->validation_status==1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.সঠিক')}}</span>
                                        @else

                                            <span class="badge rounded-pill bg-warning">{{__('messages.সঠিক না')}}</span>
                                        @endif
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td id="approvedStatus{{@$dataCollection->dcWord->dcWordCollection->id}}">
                                    @if(isset($dataCollection))
                                        @if($dataCollection->dcWord->dcWordCollection->status === null)
                                            <i class="fa fa-times text-danger"></i>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 2)
                                            <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 0)
                                            <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                        @elseif($dataCollection->dcWord->dcWordCollection->status == 1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                        @endif
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                @can('Approval-List')
                                    <td>
                                        <div class="d-grid gap-2 d-md-flex justify-content-start">
                                            @if(isset($dataCollection))
                                                @if(($dataCollection->dcWord->dcWordCollection->status!=1) && ($dataCollection->dcWord->dcWordCollection->status!=2))
                                                    @can('Directed-Edit')
                                                        <a class="btn btn-info btn-sm" href="{{route('admin.data_collections.word.edit', ['task_assign_id'=>$dataCollection->task_assign_id, 'topic_word_id'=>$dataCollection->dcWord->topic_word_id])}}?page={{$loop->iteration}}">
                                                            <i class="text-white fas fa-edit"></i>
                                                        </a>
                                                    @endcan
                                                @endif
                                            @endif

                                            @can('Validation-Button')
                                                @if(isset($dataCollection))
                                                    @if(Auth::user()->hasRole(['Validator', 'Data Collector']))
                                                        @if($dataCollection->dcWord->dcWordCollection->validation_status===NULL && $dataCollection->dcWord->dcWordCollection->status===0)
                                                            <a href="javascript:void(0)" onclick="validatorAgree({{$dataCollection->dcWord->dcWordCollection->id}})" id="agree{{$dataCollection->dcWord->dcWordCollection->id}}" type="button" class="btn btn-purple btn-sm">
                                                                {{__('একমত')}}
                                                            </a>
                                                            <input  id="collectorID" type="hidden" name="collector_id" value="{{ $collectorID }}">
                                                            <button class="btn btn-purple btn-sm edit-btn text-white" id="disagree{{$dataCollection->dcWord->dcWordCollection->id}}" type="button" value="{{$dataCollection->dcWord->dcWordCollection->id}}">
                                                                {{__('messages.একমত নই')}}
                                                            </button>

                                                        @endif
                                                    @endif
                                                @endif
                                            @endcan

                                            @if(isset($dataCollection))
                                                @if($dataCollection->dcWord->dcWordCollection->validation_status!==NULL)
                                                    @if(($dataCollection->dcWord->dcWordCollection->status!=1) && ($dataCollection->dcWord->dcWordCollection->status!=2))
                                                        @can('Data Collection Approve')
                                                            <a class="btn btn-purple btn-sm" href="javascript:void(0)" onclick="LinguistApproved({{$dataCollection->dcWord->dcWordCollection->id}})" id="approved{{$dataCollection->dcWord->dcWordCollection->id}}" {{--href="{{route('admin.word.sendToApprove', $dataCollection->dcWord->dcWordCollection->id)}}"--}}>
                                                                {{__('অনুমোদন')}}
                                                            </a>
                                                        @endcan
                                                    @endif
                                                @endif
                                            @endif

                                            <div class="row col-md-6 col-sm-12" id="form-comment" style="display: none;">
                                                <form action="" method="post">
                                                    <div class="row mb-3">
                                                        <label for="">{{__('messages.মেসেজ')}} <span class="text-danger">*</span></label>
                                                        <div class="input-group ">
                                                            <textarea name="message" class="form-control" id="comment" cols="30" rows="3" required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 text-end mb-3">
                                                            <button class="btn btn-success text-white" type="submit">
                                                                <svg class="icon  text-white">
                                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-send')}}"></use>
                                                                </svg>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                @endcan
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @include('admin.data_approval.word_revert_modal')
@endsection
@section('language-filter-js')
    <script>
        function validatorAgree(id){
            console.log(id);
            $.ajax({
                url: "{{route('admin.validation.word.topic.store')}}",
                type: "POST",
                data: {
                    d_c_word_collection_id: id,
                    validation_status: 1,
                    _token: "{{ csrf_token() }}",
                },
                success: function (response) {
                    console.log(response);
                    toastr.success(response.msg);
                    $('#agree'+id).hide();
                    $('#disagree'+id).hide();
                    $('#validationStatus'+id).html('<span class="badge rounded-pill bg-success">{{__('সঠিক')}}</span>');
                },
                error: function (response) {
                    console.log(response);
                }
            });
        }
        function LinguistApproved(id){
            console.log(id);
            $.ajax({
                url: "{{route('admin.approved.word')}}",
                type: "POST",
                data: {
                    d_c_word_collection_id: id,
                    _token: "{{ csrf_token() }}",
                },
                success: function (response) {
                    console.log(response);
                    toastr.success(response.msg);
                    $('#approved'+id).hide();
                    $('#approvedStatus'+id).html('<span class="badge rounded-pill bg-success">{{__('অনুমোদিত')}}</span>');
                },
                error: function (response) {
                    console.log(response);
                }
            });
        }

        //revert data
        $(document).ready(function (){
            $(document).on('click', '.edit-btn', function (){
                var dcWordCollectionID = $(this).val();
                var collectorID = $('#collectorID').val();
                $('#wordEditForm').modal('show');

                $.ajax({
                    type: "GET",
                    url: "/admin/validator/word/revert/"+dcWordCollectionID,
                    dataType: 'json',
                    data: {dcWordCollectionID:dcWordCollectionID,collectorID:collectorID},
                    success:function (response){
                        console.log(response)
                        $('#dcWordCollectionID').val(dcWordCollectionID);
                        $('#collector_id').val(collectorID);
                    }
                })
            })
        })


        $("#revert-message").on('click', function (event){
            event.preventDefault();
            var x = document.getElementById("form-comment");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        })

        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }

    </script>

@endsection


<div class="modal-header">
    <h5 class="modal-title">{{__('গাইড')}}</h5>
    <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="row">

        <div class="col-md-4 col-sm-12">
            <div class="card align-items-center">
                <img class="rounded" src="{{asset($guide->avatar)??''}}" width="200" height="200" alt="">
            </div>
        </div>
        <div class="col-md-8 col-sm-12">
            <div class="card">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    <tr>
                        <th>{{ __('নাম') }}</th>
                        <td>{{ $guide->name?? ''}}</td>
                    </tr>

                    <tr>
                        <th>{{ __('রোল') }}</th>
                        <td>
                            @forelse ($guide->getRoleNames() as $role)
                                <span class="small">{{ $role }}</span>
                            @empty
                                <span class="small">Guide</span>
                            @endforelse
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('এনআইডি') }}</th>
                        <td>
                            {{ $guide->nid??''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('মোবাইল') }}</th>
                        <td>{{ $guide->phone?? ''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('ইমেইল') }}</th>
                        <td>
                            {{$guide->email ?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('যোগদানের তারিখ') }}</th>
                        <td>
                            {{$guide->join_date?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('সর্বোচ্চ শিক্ষা') }}</th>
                        <td>
                            {{$guide->education?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('বায়োগ্রাফি') }}</th>
                        <td>
                            {{$guide->short_bio?? ''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('ঠিকানা') }}</th>
                        <td>
                            {{$guide->address?? ''}}
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button class="btn btn-danger btn-sm text-white" type="button" data-coreui-dismiss="modal">{{__('বন্ধ করুন')}}</button>
</div>


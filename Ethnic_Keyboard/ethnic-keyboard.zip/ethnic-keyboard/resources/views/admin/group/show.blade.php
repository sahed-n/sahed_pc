<div class="modal-header">
    <h5 class="modal-title">{{__('গ্রুপ')}}</h5>
    <button class="btn-close" type="button" data-coreui-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="row">

        {{--<div class="col-md-4 col-sm-12">
            <div class="card align-items-center">
                <img class="rounded" src="{{asset($group->avatar)??''}}" width="200" height="200" alt="">
            </div>
        </div>--}}
        <div class="col-md-12 col-sm-12">
            <div class="card">
                <table class="table table-bordered table-hover table-striped table-responsive">
                    <tbody>
                    <tr>
                        <th>{{ __('নাম') }}</th>
                        <td>{{ $group->name?? ''}}</td>
                    </tr>

                    <tr>
                        <th>{{ __('ডাটা কালেক্টর') }}</th>
                        <td>
                            @foreach( $group->collectors as $collector)
                                <span class="badge badge-sm  bg-info-new small ">{{$collector->name}}</span>
                            @endforeach
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('ম্যানেজার') }}</th>
                        <td>
                            {{ $group->manager->name??''}}
                        </td>
                    </tr>
                    <tr>
                        <th>{{ __('সুপারভাইজর') }}</th>
                        <td>{{ $group->supervisor->name?? ''}}</td>
                    </tr>
                    <tr>
                        <th>{{ __('গাইড') }}</th>
                        <td>
                            {{$group->guide->name ?? ''}}
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button class="btn btn-danger btn-sm text-white" type="button" data-coreui-dismiss="modal">{{__('বন্ধ করুন')}}</button>
</div>

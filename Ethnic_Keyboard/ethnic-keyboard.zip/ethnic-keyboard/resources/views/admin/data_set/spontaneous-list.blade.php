@extends('layouts.app')

@section('title', __('স্বতঃস্ফূর্ত টপিকের তালিকা'))

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item"><a href="{{route('admin.data-sets.spontaneous')}}">{{__('স্বতঃস্ফূর্ত টপিকের তালিকা')}}</a></li>/
                    </ul>
                </ul>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="spontaneous">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 7rem;">{{__('messages.ক্রমিক নং')}}</th>
                            <th scope="col">{{__('টপিক')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($spontaneousTopics as $key=>$spontaneousTopic)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{$spontaneousTopic->word}}</td>
                            </tr>
                        @empty
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>
        $(document).ready(function() {
            $('#spontaneous').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'print'
                ],
                language: {
                    buttons: {
                        print: 'PDF',
                        autoPrint: false
                    }
                },
            } );
        } );

    </script>
@endsection


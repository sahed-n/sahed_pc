@extends('layouts.app')

@section('title', __('নির্দেশিত বাক্যের তালিকা'))

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <ul class="nav nav-pills card-header-pills me-2">
                        <li class="nav-item"><a href="{{route('admin.data-sets.directed')}}">{{__('নির্দেশিত বাক্যের তালিকা')}}</a></li>/
                    </ul>
                </ul>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="directedSentence">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 7rem;">{{__('messages.ক্রমিক নং')}}</th>
                            <th scope="col">{{__('messages.বিষয়')}}</th>
                            <th scope="col">{{__('messages.বাংলা বাক্য')}}</th>
                            <th scope="col">{{__('অনুবাদ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($directedTopicsBySentences as $key=>$directedTopicsBySentence)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{$directedTopicsBySentence->topics->name}}</td>
                                <td>{{$directedTopicsBySentence->sentence}}</td>
                                <td>{{$directedTopicsBySentence->english}}</td>
                            </tr>
                        @empty
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>
        $(document).ready(function() {
            $('#directedSentence').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'excel', 'print'
                ],
                language: {
                    buttons: {
                        print: 'PDF',
                        autoPrint: false
                    }
                },
            } );
        } );

    </script>
@endsection



@extends('layouts.app')

@section('title', '')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <nav aria-label="breadcrumb" role="navigation">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item" data-toggle="tooltip" data-placement="top" title="Back">
                            <a class="btn btn-sm btn-success" href="{{route('admin.directed.language.tasks.list', $directedTaskByTopic->task_assign_id)}}">
                                <i class="fas fa-arrow-left text-white"></i>
                            </a>
                        </li>
                        <li class="breadcrumb-item">{{__('messages.নির্দেশিত')}}</li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="Language">
                            {{$directedTaskByTopic->taskAssign->language->name}}
                        </li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="District">
                            {{$directedTaskByTopic->taskAssign->district->name}}
                        </li>
                        <li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="topic">
                            {{$directedTaskByTopic->topic->name}}
                        </li>
                        {{--<li class="breadcrumb-item"  data-toggle="tooltip" data-placement="top" title="Back">
                            {{$directedTaskByTopic->topic->name}}
                        </li>--}}
                    </ol>
                </nav>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-dataTable">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col" style="width: 3rem;">#</th>
                            <th scope="col" style="width: 12rem;">{{__('messages.বাক্য')}}</th>
                            <th scope="col" style="width: 12rem;">{{__('messages.অনুবাদ')}}</th>
                            <th scope="col" style="width: 11rem;">{{__('messages.অডিও')}}</th>
                            <th scope="col">{{__('messages.উচ্চারণ')}}</th>
                            <th scope="col">{{__('messages.যাচাইকৃত')}}</th>
                            <th scope="col">{{__('messages.স্ট্যাটাস')}}</th>
                            @can('Audio-Validation-Name')
                                <th scope="col" style="width: 9rem">{{__('messages.অ্যাকশন')}}</th>
                            @endcan
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($directedSentences as $key=> $directedSentence)
                            @php
                                $taskAssignID =$directedTaskByTopic->task_assign_id;
                                $districtID =$directedTaskByTopic->taskAssign->district->id;
                                $topicID =$directedTaskByTopic->topic_id;

                                $dataCollection =  \App\Models\DataCollection::where('task_assign_id', $taskAssignID)
                                    ->where('district_id', $districtID )
                                    ->where('type_id', 1)
                                    ->with(['dcDirected.dcSentence'=>function ($query) {
                                        $query->select('id', 'directed_id', 'd_c_directed_id', 'audio','status',
                                        'validation_status', 'english', 'transcription', 'bangla', 'approved_by', 'approved_date');
                                    }])
                                    ->WhereHas('dcDirected',function($q)use($topicID){
                                        $q->where('topic_id', $topicID);
                                    })
                                    ->whereHas('dcDirected.dcSentence', function ($q1) use ($directedSentence){
                                        $q1->where('directed_id', $directedSentence->id);
                                    })
                                    ->first();
                                    // echo $dataCollection;

                            @endphp
                            <tr>
                                <th scope="row">
                                    @if(app()->getLocale() == 'bn')
                                        ({{Converter::en2bn($loop->iteration)}})
                                @else
                                    {{ $loop->iteration }}
                                @endif
                                <td class="" style="font-size: .95rem; line-height: 1.1rem">
                                    @if(isset($dataCollection->dcDirected->dcSentence->bangla))
                                        {{$dataCollection->dcDirected->dcSentence->bangla}}
                                    @else
                                        {{$directedSentence->sentence}}
                                    @endif
                                </td>
                                <td class="" style="font-size: .95rem; line-height: 1.1rem">
                                    @if(isset($dataCollection->dcDirected->dcSentence->english))
                                        {{$dataCollection->dcDirected->dcSentence->english}}
                                    @else
                                        {{$directedSentence->english}}
                                    @endif
                                </td>

                                <td class="">
                                    @if(isset($dataCollection))
                                        @php
                                            if($dataCollection->dcDirected->dcSentence->audio != null){
                                                $audio = explode('/', $dataCollection->dcDirected->dcSentence->audio);
                                                $uniqueCode=substr(end($audio), 0, -4);
                                                $uniqueCode= str_replace('.', '', $uniqueCode);
                                            }
                                        @endphp

                                        <button style="display: none;" class="myLink" onclick="waveSurferView({{$dataCollection->dcDirected->dcSentence}})"></button>
                                        <div id="waveform{{$uniqueCode}}"></div>
                                        <div id="waveform-time-indicator" class="justify-content-between">
                                            <input type="button" id="play-pause{{$uniqueCode}}" value="Play"/>
                                            <span id="total-time" class="time{{$uniqueCode}}">00:00:00</span>
                                            <button class="btn btn-light btn-sm mb-1" value="{{$dataCollection->dcDirected->dcSentence->audio}}" onclick="dowonloadFile()">
                                                {{__('ডাউনলোড')}}
                                            </button>
                                        </div>
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td class="">
                                    @if(isset($dataCollection->dcDirected->dcSentence->transcription))
                                        {{$dataCollection->dcDirected->dcSentence->transcription}}
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td class=""  id="validationStatus{{@$dataCollection->dcDirected->dcSentence->id}}">
                                    @if(isset($dataCollection->dcDirected->dcSentence->validation_status))
                                        @if($dataCollection->dcDirected->dcSentence->validation_status==1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.সঠিক')}}</span>
                                        @else
                                            <span class="badge rounded-pill bg-warning">{{__('messages.সঠিক না')}}</span>
                                        @endif
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>
                                <td id="approvedStatus{{@$dataCollection->dcDirected->dcSentence->id}}">
                                    @if(isset($dataCollection))
                                        @if($dataCollection->dcDirected->dcSentence->status === null)
                                            <i class="fa fa-times text-danger"></i>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 2)
                                            <span class="badge rounded-pill bg-danger">{{__('messages.সংশোধন')}}</span>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 0)
                                            <span class="badge rounded-pill bg-warning">{{__('messages.বিচারাধীন')}}</span>
                                        @elseif($dataCollection->dcDirected->dcSentence->status == 1)
                                            <span class="badge rounded-pill bg-success">{{__('messages.অনুমোদিত')}}</span>
                                        @endif
                                    @else
                                        <i class="fa fa-times text-danger"></i>
                                    @endif
                                </td>

                                @can('Approval-List')
                                    <td>
                                        <div class="d-grid gap-2 d-md-flex justify-content-start">
                                            @if(isset($dataCollection))
                                                @if(($dataCollection->dcDirected->dcSentence->status!=1) && ($dataCollection->dcDirected->dcSentence->status!=2))
                                                    @can('Directed-Edit')
                                                        <a class="btn btn-info btn-sm" href="{{route('admin.data_collections.directed.edit', ['task_assign_id'=>$dataCollection->task_assign_id, 'topic_id'=>$dataCollection->dcDirected->topic_id])}}?page={{$loop->iteration}}">
                                                            <i class="text-white fas fa-edit"></i>
                                                        </a>
                                                    @endcan
                                                @endif
                                            @endif
                                            @if(isset($dataCollection))
                                                @if(Auth::user()->hasRole(['Validator', 'Data Collector']))
                                                    @if($dataCollection->dcDirected->dcSentence->validation_status=== NULL && $dataCollection->dcDirected->dcSentence->status === 0)
                                                        @can('Validation-Button')
                                                            <a href="javascript:void(0)" onclick="validatorAgree({{$dataCollection->dcDirected->dcSentence->id}})" id="agree{{$dataCollection->dcDirected->dcSentence->id}}" type="button" class="btn btn-purple btn-sm">
                                                                {{__('একমত')}}
                                                            </a>

                                                            <input  id="collectorID" type="hidden" name="collector_id" value="{{ $collectorID }}">
                                                            <button class="btn btn-purple btn-sm edit-btn text-white" id="disagree{{$dataCollection->dcDirected->dcSentence->id}}" type="button" value="{{$dataCollection->dcDirected->dcSentence->id}}">
                                                                {{__('messages.একমত নই')}}
                                                            </button>
                                                        @endcan
                                                    @endif
                                                @endif
                                            @endif

                                            {{--@endif--}}
                                            @if(isset($dataCollection))
                                                @if($dataCollection->dcDirected->dcSentence->validation_status!==NULL)
                                                    @if(($dataCollection->dcDirected->dcSentence->status!=1) && ($dataCollection->dcDirected->dcSentence->status!=2))
                                                        @can('Data Collection Approve')
                                                            <a class="btn btn-purple btn-sm" href="javascript:void(0)" onclick="LinguistApproved({{$dataCollection->dcDirected->dcSentence->id}})" id="approved{{$dataCollection->dcDirected->dcSentence->id}}">
                                                                {{__('অনুমোদন')}}
                                                            </a>
                                                        @endcan
                                                    @endif
                                                @endif
                                            @endif

                                            <div class="row col-md-6 col-sm-12" id="form-comment" style="display: none;">
                                                <form action="" method="post">
                                                    <div class="row mb-3">
                                                        <label for="">{{__('messages.মেসেজ')}} <span class="text-danger">*</span></label>
                                                        <div class="input-group ">
                                                            <textarea name="message" class="form-control" id="comment" cols="30" rows="3" required></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 text-end mb-3">
                                                            <button class="btn btn-success text-white" type="submit">
                                                                <svg class="icon  text-white">
                                                                    <use xlink:href="{{asset('assets/coreui/vendors/@coreui/icons/svg/free.svg#cil-send')}}"></use>
                                                                </svg>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                @endcan
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @include('admin.data_approval.directed_revert')
@endsection
@section('language-filter-js')
    <script>

        function validatorAgree(id){
            console.log(id);
            $.ajax({
                url: "{{route('admin.validation.directed.topic.store')}}",
                type: "POST",
                data: {
                    d_c_directed_sentence_id: id,
                    validation_status: 1,
                    _token: "{{ csrf_token() }}",
                },
                success: function (response) {
                    console.log(response);
                    toastr.success(response.msg);
                    $('#agree'+id).hide();
                    $('#disagree'+id).hide();
                    $('#validationStatus'+id).html('<span class="badge rounded-pill bg-success">{{__('সঠিক')}}</span>');
                },
                error: function (response) {
                    console.log(response);
                }
            });
        }

        function LinguistApproved(id){
            console.log(id);
            $.ajax({
                url: "{{route('admin.approved.directed-collections')}}",
                type: "POST",
                data: {
                    d_c_directed_sentence_id: id,
                    _token: "{{ csrf_token() }}",
                },
                success: function (response) {
                    console.log(response);
                    toastr.success(response.msg);
                    $('#approved'+id).hide();
                    $('#approvedStatus'+id).html('<span class="badge rounded-pill bg-success">{{__('অনুমোদিত')}}</span>');
                },
                error: function (response) {
                    console.log(response);
                }
            });
        }

        //revert data
        $(document).ready(function (){
            $(document).on('click', '.edit-btn', function (){
                var dcDirectedSentenceID = $(this).val();
                var collectorID = $('#collectorID').val();
                $('#trimEditForm').modal('show');

                $.ajax({
                    type: "GET",
                    url: "/admin/validator/revert/"+dcDirectedSentenceID,
                    dataType: 'json',
                    data: {dcDirectedSentenceID:dcDirectedSentenceID,collectorID:collectorID},
                    success:function (response){
                        console.log(response)
                        $('#dcDirectedSentenceID').val(dcDirectedSentenceID);
                        $('#collector_id').val(collectorID);
                    }
                })
            })
        })


        $("#revert-message").on('click', function (event){
            event.preventDefault();
            var x = document.getElementById("form-comment");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        })


        function dowonloadFile() {
            var path = $(event.target).val();
            let filename = path.replace(/^.*[\\\/]/, '');
            console.log(filename);

            var baseUrl = window.location.origin+'/';
            let audioPath = baseUrl + path;
            var link = document.createElement("a");
            link.download = filename;
            link.href = audioPath;
            link.click();
        }

    </script>

@endsection


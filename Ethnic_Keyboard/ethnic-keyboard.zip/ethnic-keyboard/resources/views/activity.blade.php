@extends('layouts.app')

@section('title', 'অ্যাক্টিভিটি লগ তালিকা')

@section('content')
    <div class="container-fluid px-0">
        <div class="card mb-3">
            <div class="card-header">
                <ul class="nav nav-pills card-header-pills justify-content-between">
                    <li class="nav-item">{{__('messages.অ্যাক্টিভিটি লগ')}}</li>
                </ul>

            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" id="ethnic-activity">
                        <thead class="table-dark">
                        <tr>
                            <th scope="col">{{__('ক্রমিক নং')}}</th>
                            <th scope="col">{{__('বর্ণনা')}}</th>
                            <th scope="col">{{__('অ্যাড্রেস')}}</th>
                            <th scope="col">{{__('ডাটা আইডি')}}</th>
                            <th scope="col">{{__('ইউজার')}}</th>
                            <th scope="col">{{__('তারিখ')}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('language-filter-js')
    <script>
        // alertify delete
        $('.show_confirm').click(function(event) {
            var form =  $(this).closest("form");
            event.preventDefault();
            alertify.confirm('Whoops!', 'Are you sure you want to Delete?',
                function(){
                    form.submit();
                    // alertify.success('Ok')
                },
                function(){
                    // alertify.error('Cancel')
                });
        });

        $(document).ready(function() {
            $('#ethnic-activity').DataTable({
                processing: true,
                serverSide: true,
                ajax: '{{ route('admin.activity.log') }}',
                columns: [
                    { data: 'DT_RowIndex', name: 'DT_RowIndex' },
                    { data: 'description', name: 'description' },
                    { data: 'subject_type', name: 'subject_type' },
                    { data: 'subject_id', name: 'subject_id' },
                    { data: 'causer.name', name: 'causer.name' },
                    { data: 'created_at', name: 'created_at' },
                ],
                // number of records per page
                "pageLength": 15,
            });
        });

    </script>
@endsection

